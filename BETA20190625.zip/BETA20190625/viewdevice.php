<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>  
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/viewdevice.css">
</head>

<body>
<div class="container">
   
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO SET/GET DEVICE INFORMATION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<div class="lineBorder"> <!-- Start of Borderline for Device Details -->
<div class="ticket">
<?php
$device_id=checkGet  ('device_id');
if(!$device_id){  //device is not set
  redirect('devicemanagement.php');
}

?>

<div id="device_info_container">
  <fieldset id="device_details">
    <div class="card">
      <center>
        <br>
        <legend class='headerStyle'><?php echo 'Device '.$device_id?></legend></center>
        <div class="card-body">
          <?php
            $deviceDetails = retrieveDetails($device_id);
          ?>  
          <form id="editDeviceDetails" method="post" action="updatedevice.php">
          <?php createHiddenInput('device_id',$device_id);?>
          <div class="form-group">
              <label>Device Type</label>
              <span id="device_details" name="device_details" class="form-control"><?php echo $deviceDetails['device_type'];?></span>
              <?php
                  /*$valueArray = retrieveOptions('device_type',true);
                  outputSelect('device_type',$deviceDetails['device_type'],$valueArray,true);*/
                ?>                          
          </div>
          <div class="form-group">
              <label>Device Owner</label>
              <?php
                echo "<input type='text' class='form-control' name='owner' id='owner' placeholder='Owner' required value=".$deviceDetails['owner']." required>";
              ?>
          </div>
          <div class="form-group">
              <label>Office</label>
              <?php
                $valueArray = retrieveOptions('office',true);
                outputSelect('office',$deviceDetails['office'],$valueArray,true);
              ?>
          </div>
          <input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Update Details">
          </form>
        </div>
    </div>
  </fieldset>
  <br>
  <fieldset id="device_parts">
    <div class="card">

      <?php outputTitle("Device Parts");?>

      <div class="card-header cardStyleHeader"></div>
        <div class="card-body">
          <li href="#showParts" class="list-group-item styleList" data-toggle="collapse"><span>Show</span> Parts List</li>
          <div id="showParts" class="collapse">
            <ul class="list-group">
                <?php
                  if($items = retrieveParts($device_id)){
                    printArrayWithX($items,'Part');
                  }
                  else{
                    echo "<li class='list-group-item d-flex justify-content-between align-items-center'>Nothing to display</li>";
                  }        
                ?>
            </ul>
          </div>

          <br>
            <li>Add New Part
              <form action="newpartspec.php" method="post"><!--form to add new spec to device-->
                <div class="form-group">
                  <?php createHiddenInput('device_id',$device_id);?>
                  <?php createHiddenInput('trail',basename($_SERVER['PHP_SELF']));
                    echo "<script>console.log(document.getElementsByName('trail')[0].name+':'+document.getElementsByName('trail')[0].value);</script>";
                  ?>
                  <br>
                    <input class="form-control" type="text" id="new_part" name="new_value" placeholder="New Part..." required>
                  <br>        
                    <input type="text" class="form-control" name="new_detail" placeholder="New Details..." required>
                  <br>
                    <input class="btn btn-default buttonStyle"  type="submit" name="Submit" value="Add Part">
                </div>
              </form>
            </li>         
      </div>
    </div>
  </fieldset>
  <br>
  <fieldset id="device_specs">
    <div class="card">

      <?php outputTitle("Device Specifications");?>

      <div class="card-header cardStyleHeader"></div>
        <div class="card-body">
          <ul class="list-group">
            <li href="#showSpec" class="list-group-item styleList" data-toggle="collapse"><span>Show</span> Specifications List</li>
          <div id="showSpec" class="collapse">
          <?php
            if($items = retrieveSpecs($device_id)){
              printArrayWithX($items,'Spec');
            }
            else{
              echo "<li class='list-group-item d-flex justify-content-between align-items-center'>Nothing to display</li>";
            }            
          ?>
          </ul>
          <br>
          <form action="newpartspec.php" method="post"><!--form to add new spec to device-->
            <div class="form-group">
              <?php createHiddenInput('device_id',$device_id);?>
              <?php createHiddenInput('trail',getUrl('BASE'));?>
              <input type="text" class="form-control" id="new_spec" name="new_value" placeholder="New Specification..." required>
              <br>
              <input type="text" name="new_detail" class="form-control" placeholder="New Details...">
              <br>
              <input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Add Specification" required>
            </div>
          </form>
        </div>
    </div>
  </fieldset>
</div>

</div>
</div> <!-- End of Borderline for Device Details -->
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF FORM USED TO SET/GET DEVICE INFORMATION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

</div>

<!--MODAL USED TO CONFIRM DELETION OF PART OR SPEC-->
<div class="modal fade" id="deletePartSpec">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Confirm Deletion</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
      <!-- Modal body -->
      <form method="post" action="deletepartspec.php">
        <div class="modal-body">
          <p>Are you sure you want to delete [<span id="entityString"></span>]?</p>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
          <?php createHiddenInput('device_id',$device_id);?>
          <input type="hidden" name="type" id="type">
          <input type="hidden" name="item" id="item">
          <input type="hidden" name="detail" id="detail">
          <?php createHiddenInput('trail',getUrl('BASE'));?>
          <input type="submit" class="btn btn-primary mr-auto" name="Submit" style="width: 100%;" value="Yes">
          <button class="btn btn-danger" data-dismiss="modal" style="width: 100%;">No</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!--END OF MODAL USED TO CONFIRM DELETION OF PART OR SPEC-->


<br>
<br>
<br>
<br>

</body>
</html>

<!--css-->
<style>
 
body{
    background-color: #384048;
  }
</style>

<script>

function setModalValues(type, part, detail){
  entityString = document.getElementById('entityString');
  entityString.innerHTML = type+": "+part+": "+detail;
  document.getElementById('type').value=type;
  document.getElementById('item').value=part;
  document.getElementById('detail').value=detail;
}
</script>