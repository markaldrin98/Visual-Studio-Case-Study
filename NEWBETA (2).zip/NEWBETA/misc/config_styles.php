<?php
?>
<style>

.checked .navbar a {
  color: white !important;
}

.checked .navbar-custom {
    background-color: #505050;
    box-shadow: 0 4px 2px -2px #505050;
}
.checked .field input:valid + label::before  {
background: #303030;
color: white;
}



.checked .field input:focus + label::before {
  background: #303030;
  color: white;
}

.checked .field select:valid + label::before {
background: #303030;
color: white;
}

.checked .field select:focus + label::before {
background: #303030;
color: white;
}

.checked .field textarea:valid + label::before {
background: #303030;
color: white;
}

.checked .field textarea:focus + label::before {
background: #303030;
color: white;
}
.checked .field label::before {
  color: white;
}

.checked .field label::before {
  color: white;
}

  </style>
