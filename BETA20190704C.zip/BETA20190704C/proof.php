<?php include 'misc/config.php';?>
<div style="color:white;">

<script>
function hideTables(){
  console.log("Hiding tables");
  tableElements = document.getElementsByClassName('fieldDiv');
  for(counter=0;counter<tableElements.length;counter++){
    tableElements[counter].style.display='none';
  }
}

function showTable(tableSelect){
  hideTables();
  document.getElementById(tableSelect.value).style.display='block';
}
</script>
<?php
        /*$description=checkPost('new_description')?:null;
        if(is_null($description))print("IS NULL");*/

$ticket_id = '190509-002';//should be extracted from the value of the current element in the loop (e.g. $res['ticket_id'])

echo "<br><br><br><br><br><br><br><br>";

$isAssessed = (string)(1<2);
print("Is assessed: ".$isAssessed);
$isAssessed = true;
print("<br>Is assessed: ".$isAssessed);

retrieveHistory('190610-002-A');
echo "<br>";
  //ucwords(str_replace('_',' ',$fieldArray[$i]))
  global $conn;

echo "<br><br>";
$sampleQuery = "SELECT * FROM TICKETS WHERE FALSE";
if($sampleResult=mysqli_query($conn,$sampleQuery)){
  echo "Empty query is TRUTHY<br>";
  if($count=mysqli_num_rows($sampleResult)){
    echo "Empty query row count is TRUTHY";
  }
  else echo "Empty query row count is FALSY";
}
else{
  echo "Empty query is FALSY";
}
echo "";
$username = "ririjoy";
$username1 = "ririri";
$name = "Rizza Joy Batuyong";
$name1 = "Riri Joy Batuyong";

if(nameIsAvailable($name)){
  print("Username $name is available");
}
else{
  print("Username $name is not available");
}

if(nameIsAvailable($name1)){
  print("Username $name1 is available");
}
else{
  print("Username $name1 is not available");
}

print("<br><br>");
print_r(retrieveEmployees('admin',true));
  if(retrieveEmployees('admin',true)){
    echo "ret returning true";
  }
  else{
    echo "ret returning false";
  }

  echo "<br><br>";

    $valueArray = retrieveEmployees('admin',true);
    outputFullSelect("adminSelect","",$valueArray,false,'-select an admin-',false);//($nameString,$storedValue,$valueArray,$isRequired,$nullString,$othersToggle)

    $tableName="admin";
    foreach($valueArray as $name => $username){
      $activeTableName=$tableName.$username;
      $name=strtoupper($name);
      echo "<table name='$activeTableName'>";
      echo "<tr style='text-align:center;'><td colspan='100%'>ADMIN TECHNICAL ASSISTANCE - $name</td></tr>";
      outputHeadRow("Sample Left Element");
      echo "</table>";
    }
  ?>

  
?>

</div>
<script>  
hideTables();

</script>