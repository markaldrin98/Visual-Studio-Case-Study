<html>
<head>    
    <title>Index - Programmed by Villanueva, Jeremy</title>
</head>
 
<body>
	<?php
	include("config.php");
	$searchstr="";
	if(isset($_GET['searchstr'])) {
		$searchstr=$_GET['searchstr'];
		echo $searchstr;
		$result = mysqli_query($conn, "SELECT * FROM student_info WHERE lname LIKE '%$searchstr%' OR fname LIKE '%$searchstr%' OR mname LIKE '%$searchstr%' OR snumber LIKE '%$searchstr%' OR email LIKE '%$searchstr%'");	
	}
	else{
		$result = mysqli_query($conn, "SELECT * FROM student_info ORDER BY id DESC");		
	}
	?>

    <form style="margin-left:20px;margin-top:40px;" method="get" action="addrecord.html"><input type="submit" value="Add New Record" name="addnew"></form>
    <form method="get" action="faceplate.php">
    <input type="text" name="searchstr" id="searchstr" style="margin-left:20px;"><input type="submit" value="Search" name="Search">
    </form>
    <form style="margin-left:20px" method="get" action="faceplate.php"><input type="submit" value="Refresh" name="Refresh"></form>
 
    <table width='80%' border=0 style="margin:20px;">
        <tr bgcolor='#CCCCCC'>
            <td>Last Name</td>
            <td>First Name</td>
            <td>Middle Name</td>
            <td>Student Number</td>
            <td>Email</td>
        </tr>
        <?php 
        while($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
            echo "<td>".$res['lname']."</td>";
            echo "<td>".$res['fname']."</td>";
            echo "<td>".$res['mname']."</td>";    
            echo "<td>".$res['snumber']."</td>";  
            echo "<td>".$res['email']."</td>";  
            echo "<td><a href=\"updaterecord.php?id=$res[id]\">Update</a> | <a href=\"deleterecord.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";        
        }
        ?>
    </table>

</body>
</html>