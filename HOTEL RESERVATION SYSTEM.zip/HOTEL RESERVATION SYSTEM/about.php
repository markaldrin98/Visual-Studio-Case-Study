<?php include "header.php";?>
<div id="cover">
<div id="content">
<?php global $msg; echo $msg;?>
<br/><h3>Welcome, About page.</h3><br/>
<p> FM INTERNATIONAL HOTEL RESERVATION SYSYEM:</p>

<img src="images/default-FM-International.jpg"
align="RIGHT">

<br><br><b><br><br><br><br><h2>FM International hotel <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Close to Center of Debre Markos Town .<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;P.O. Box: 	
Debre Markos, Ethiopia<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phone: 	
(+251) 58-771-3227<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Fax: 	(+251) 91-835-3704 <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Number of Rooms: 30
Room Rate Starting from: 170 Birr.
</h2>
</p>
<p>&nbsp;&nbsp;</p>
<div>
<?php include "footer.php";?>
</div>

</div>
</div>

