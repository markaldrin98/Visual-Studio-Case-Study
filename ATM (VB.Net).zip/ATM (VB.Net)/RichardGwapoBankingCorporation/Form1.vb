﻿Public Class Form1

    Private Sub timer1_Tick(sender As System.Object, e As System.EventArgs) Handles timer1.Tick

        Label1.Text = DateTime.Now.ToString("MMMM") & vbNewLine & DateTime.Now.Day.ToString() & vbNewLine &
               DateTime.Now.Year.ToString() & vbNewLine & DateTime.Now.ToLongTimeString()

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        Me.Hide()
        Form2.Show()

    End Sub

    Private Sub Form1_FormClosed(sender As System.Object, e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed

        Application.Exit()

    End Sub

   
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class
