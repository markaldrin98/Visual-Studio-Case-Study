<!DOCTYPE html>
<html>
<head>
	<title>Purchase Journal Window</title> <!-- Title of your web page -->
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- To make your web page responsive -->
	
	<!-- These tags are support for Bootstrap's CSS and Javscript from Bootstrap.-->

	<!-- Latest compiled and minified CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">

	<!-- jQuery library -->
	<script src="js/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

	<!-- Link for Bootstrap Icons -->
	<link rel="stylesheet" href="css/all.css">
	<script src="js/all.js"></script>

	<!-- Link to style web page (CSS Link) -->
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head>

<body>

<div class="container"> 
  <br> <!-- To make one row space -->
	  <div class="btn-group"> <!-- To create an inline button group -->
		  <button type="button" class="btn btn-outline-primary"><i class="fa fa-file"></i> New Order</button>&nbsp;
		  <button type="button" class="btn btn-outline-primary"><i class="fa fa-save"></i> Save Order</button>&nbsp;
		  <button type="button" class="btn btn-outline-primary"><i class="fa fa-history"></i> History</button>&nbsp;
		  <button type="button" class="btn btn-outline-primary"><i class="fa fa-search"></i> Search Batch</button>&nbsp;
		  <button type="button" class="btn btn-outline-primary"><i class="fa fa-window-close"></i> Close Win</button>
	  </div>
 </div>


</body>
</html>