<?php 

include('connection.php');




?>


<?php 
if(isset($_POST['login'])){
    $count = 0;
    $username = $_POST['username'];
    $password = $_POST['password'];
    $res = mysqli_query($db, "SELECT * FROM tbl_admin_credentials WHERE username=$username && password=$password");  
    if($mysqli_num_rows($res) > 0){
    //    window.location.href="";
    }

    }
?>

<html>
<head>
    <title>Facility Reservation System</title>
</head>
<body>
<!--<div class="container-fluid">
    <h2 class="text-center p-4">Facility Reservation System</h2>    
    <div class="row">
     <div class="col-sm-6">
           <img src="img/imus_bg.png" style="width: 100%;">
        </div>
        <div class="col-sm-6">
            <form action="" method="post" class="p-4">
                <div class="row justify-content-center">
                <div class="col-sm-8">
                    <div class="form-group">
                        <label for="usr">Username:</label>
                        <input type="text" name="username" class="form-control form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="usr">Password:</label>
                        <input type="password" name="password" class="form-control form-control" required>
                    </div> 
                    <div class="form-group">
                        <input type="submit" class="btn btn-block" style="background-color: #ffad33;" value="Login" name="login">
                    </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
-->
<div class="container">
    
    <h2 class="text-center p-4">Facility Reservation System</h2>
    <div class="row justify-content-center">
        <div class="col-lg-4 bg-light mt-2 px-0" style="background: white !important; border: solid 1px #d8dee2 !important; border-radius: 10px; margin: 15px;">   
        <form action="" method="post" class="p-4">

        <div class="form-group">
            <label for="usr">Username:</label>
            <input type="text" name="username" class="form-control form-control" required>
        </div>
        <div class="form-group">
            <label for="usr">Password:</label>
            <input type="password" name="password" class="form-control form-control" required>
        </div>
   

        <div class="form-group">
            <span><input type="submit" class="btn btn-block" style="background-color: #ffad33;" value="Login" name="login"></span>
        </div>
        </form>
    </div>
</div>

</div>

</div>


</body>
</html>