<?php 
error_reporting(0);
include "admin_auth.php";
session_start();
include "admin_header.php";?>
<div id="cover">
<div id="content">
<h4>Hellow,&nbsp;<?php echo $_SESSION['SESS_NAME'] ;?><br /></h4>
<br/><h3><h2>Customer Registration List
deactive when customer finish thier reserve/booking </h2>:</h3>
  <div id="login">
  
<?php
include'connection.php';
	
?>


<h3>Login users:</h3>
<?php
include'connection.php';
	$member=mysql_query("select * from login");
	if(mysql_num_rows($member)==0)
	{
		echo '<font color="red">No results found</font>';
	}
	else
	{
		echo '<table><tr bgcolor="#FF6600">
<td width="100px">ID</td>		
<td width="100px">USERNAME</td>
<td width="100px">RANK</td>
<td width="100px">STATUS</td>
<td width="100px">ACTION</td>
<td width="100px">DEACTIVATE/ACTIVATE</td>
</tr>';
 while($mb=mysql_fetch_object($member))
		{	
			$id=$mb->login_id;
			$name=$mb->username;
			$pos=$mb->rank;
			$about=$mb->status;
		
			echo '<tr bgcolor="#BBBEFF">';
	echo '<td>'.$id.'</td>';		
	echo '<td>'.$name.'</td>';
	echo '<td>'.$pos.'</td>';
	echo '<td>'.$about.'</td>';
	echo "<td><a href=delete.php?delete=".$name.">Delete</a></td>";
	echo "<td><a href=deactivate.php?deactivate=".$id.">Deactivate</a>/&nbsp;
			  <a href=activate.php?activate=".$id.">Activate</a></td></tr>";
		}
		echo'</table>';
	}
?>

        </div>
        
<?php include "footer.php";?>
</div>
</div>

