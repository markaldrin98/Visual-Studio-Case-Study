<?php if(session_status()!=PHP_SESSION_ACTIVE) session_start();
include 'config_php_functions.php';
include 'config_scripts.php';

   global $conn;


   $servername = "localhost";
   $username = "root";
   $password = "";
   $dbname = "testticketdatabase"; //change this -> temporarily changed--------------------------------------------------------
   $conn = mysqli_connect($servername, $username, $password, $dbname);

/*if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true){
  //redirect('login.php?op=login');
}
else{  //this function forces login
  redirect('login.php');
}*/
    $tab1 = '';
    $tab2 = '';
    $tab3 = '';
    $tab4 = '';
    $tab5 = ''; //variables that toggle which tabs are visible on the nav bar
    $tab6 = '';
    $space = '';
?>
<?php 
  // filters out nav tabs based on authority of logged-in user
  if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && isset($_SESSION['userType']) && $_SESSION['userType']=='admin'){
  }
  else if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && isset($_SESSION['userType']) && $_SESSION['userType']=='tech'){
    $tab3 = 'display:none;';
  }
  else{
    $icon = 'display: none;';
    $menutab = 'display: none;';
    $tab0 = 'display:none;';
    $tab1 = 'display:none;';
    $tab2 = 'display:none;';
    $tab3 = 'display:none;';
    $tab4 = 'display:none;';
    $tab5 = 'display:none;';
    $tab6 = 'display:none;';
    $space = 'display:none;';
    $navigation = 'display:none;';

  }
?>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">IT Ticketing System</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">      
        
        
      </ul>
      <ul class="nav navbar-nav navbar-right">

        <li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
                 <?php //sets right end of nav bar (changes elements depending on whether or not there is a user logged in)
        if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true){  
           echo '<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> Welcome, '.$_SESSION["client_name"].' <span class="glyphicon glyphicon-triangle-bottom"></span></a>
              <ul class="dropdown-menu" >
            <li><a style="<?php echo $tab0;?>" href="createticket.php"><span class="glyphicon glyphicon-file"></span> Create Ticket</a></li>
            <li><a style="<?php echo $tab1;?>" href="outstanding.php"><span class="glyphicon glyphicon-list"></span> Outstanding Tickets</a></li>
            <li><a style="<?php echo $tab2;?>" href="activeticket.php"><span class="glyphicon glyphicon-check"></span> Active Ticket</a></li>
            <li><a style="<?php echo $tab3;?>" href="inventory.php"><span class="glyphicon glyphicon-list-alt"></span> Inventory</a></li>
            <li><a style="<?php echo $tab4;?>" href="reports.php"><span class="glyphicon glyphicon-tasks"></span> Reports</a></li>
            <li><a style="<?php echo $tab5;?>" href="changepass.php"><span class=" glyphicon glyphicon-lock"></span> Change Password</a></li>
            <li><a style="<?php echo $tab6;?>" href="logout.php"><span class=" glyphicon glyphicon-log-out"></span> Log Out</a></li>
          </ul>


           </li>'; 
       /*    echo '<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log Out</a></li>'; */
        }
        else{
         /*  echo '<a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a>'; */
           echo '<li><a data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';

        }
    ?> 
            <li style="<?php echo $navigation;?>" class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-tag"></span> Ticket Queue <span class="glyphicon glyphicon-triangle-bottom"></span></a>
                <ul class="dropdown-menu big ticketStyle">
                  <div class="tabcontent">
                      <div class="tabStatus">
                          <li><a><span style="color:orange;">Ongoing</span> </a></li>  
                      </div>
                      <div class="tabTicketID">
                          <li><a>190524-001</a></li>  
                      </div>
                    <div class="tabStatus">
                          <li><a><span style="color:#00ccff;">Pending</span></a></li>  
                      </div>
                      <div class="tabTicketID">
                          <li><a>190524-001</a></li>  
                      </div>
                      <div class="tabStatus">
                          <li><a><span style="color:orange;">Ongoing</span> </a></li>  
                      </div>
                      <div class="tabTicketID">
                          <li><a>190524-001</a></li>  
                      </div>
                      <div class="tabStatus">
                          <li><a><span style="color:#00ccff;">Pending</span></a></li>  
                      </div>
                      <div class="tabTicketID">
                          <li><a>190524-001</a></li>  
                      </div>
                      <div class="tabStatus">
                          <li><a><span style="color:orange;">Ongoing</span> </a></li>  
                      </div>
                      <div class="tabTicketID">
                          <li><a>190524-001</a></li>  
                      </div>
                      <div class="tabStatus">
                          <li><a><span style="color:#00ccff;">Pending</span></a></li>  
                      </div>
                      <div class="tabTicketID">
                          <li><a>190524-001</a></li>  
                      </div>
                      <div class="tabStatus">
                          <li><a><span style="color:orange;">Ongoing</span> </a></li>  
                      </div>
                      <div class="tabTicketID">
                          <li><a>190524-001</a></li>  
                      </div>
                      <div class="tabStatus">
                          <li><a><span style="color:yellow;">Pending</span></a></li>  
                      </div>
                      <div class="tabTicketID">
                          <li><a>190524-001</a></li>  
                      </div>
                  </div>                    
                </ul>
           </li>
      </ul>
    </div>
  </div>
</nav>
<!-- Modal for Login -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header bgOrange">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title titleCenter">Log In</h4>
      </div>
      <div class="modal-body">
        <form class='login100-form validate-form' action='checkcredentials.php' method='post'>
            <div class='field'>
              <input type='text' required autocomplete='off' id='username' required name='username' class='form-control' autofocus>
              <label for='username' title='Username' data-title='Username'></label>
            </div>        
            <div class='field'>
              <input type='Password' id='password' required name='password' class='form-control'>
              <label for='password' title='Password' data-title='Password'></label>
            </div>
            <div class='container-login100-form-btn'>
              <div class='wrap-login100-form-btn'>             
                <input type='submit' value='Log In' name='Submit' id='Submit' class='login100-form-btn'>
              </div>    
            </div>
        </form>
      </div>  
    </div>
  </div>
</div>

<!--
  <li><a><span style="color:#00ff00;">Ongoing:</span> | 190524-001 </a></li>                  
                  <li><a><span style="color:yellow;">Pending:</span> | 190524-001 </a></li>
                -->


<!--
<section class="navigation">
  <div class="nav-container"> 
    <div class="topnav" id="myTopnav">
      <div class="dropdowns">
        <button class="dropbtn" onclick="myFunctionDD()">IT Ticketing System
          <i style='<?php echo $icon;?>' class="fa fa-caret-down"></i>
        </button>

        <div class="dropdowns-content" id="myDropdown">
              <a style='<?php echo $tab0;?>' href="index.php"><span class="glyphicon glyphicon-file"></span> Create Tickets</a>
              <a style='<?php echo $tab1;?>' href="outstanding.php"><span class="glyphicon glyphicon-list"></span> Outstanding Tickets</a>
              <a style='<?php echo $tab2;?>' href="activeticket.php"><span class="glyphicon glyphicon-check"></span> Active Tickets</a>
              <a style='<?php echo $tab3;?>' href="inventory.php"><span class="glyphicon glyphicon-home"></span> Inventory</a>
              <a style='<?php echo $tab4;?>' href="reports.php"><span class=" glyphicon glyphicon-list-alt"></span> Reports</a>
              <a style='<?php echo $tab5;?>' href="changepass.php"><span class=" glyphicon glyphicon-lock"></span> Change Pass</a>
              
        </div>
      </div>
      
        <div class="left">
          <a href="#contact">Contact</a>
        </div>
      
        <div class="right">
        </div>
    </div>
-->

<head>
  <link rel="stylesheet" type="text/css" href="css/dropdown.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />

</head>
<!--
<script>
    function myFunctionDD() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {
  var myDropdown = document.getElementById("myDropdown");
    if (myDropdown.classList.contains('show')) {
      myDropdown.classList.remove('show');
    }
  }
}

</script>
-->