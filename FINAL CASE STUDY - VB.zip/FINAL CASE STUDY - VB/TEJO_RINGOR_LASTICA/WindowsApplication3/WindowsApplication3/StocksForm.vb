﻿Imports System.Data.OleDb
Public Class StocksForm
    Dim conn As OleDb.OleDbConnection
    Dim da As OleDb.OleDbDataAdapter
    Dim dt As DataTable
    Dim cmd As OleDbCommand
    Dim dbdata As OleDbDataReader
    Dim index As Integer


    ReadOnly CONNECTION_STRING As String = "Provider=microsoft.Jet.oledb.4.0; Data Source=" & _
                                    Application.StartupPath.Replace("\bin\Debug", String.Empty) & _
                                    "\Database2.mdb;"
    Private Sub StocksForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database2DataSet4.Table1' table. You can move, or remove it, as needed.
        'TODO: This line of code loads data into the 'Database2DataSet3.Table1' table. You can move, or remove it, as needed.
        Me.Table1TableAdapter.Fill(Me.Database2DataSet3.Table1)

        Dim conn As New OleDbConnection(CONNECTION_STRING)
        conn.Open()
        Dim com As String = "Select * from Table1 order by ID asc"
        Dim da As New OleDbDataAdapter(com, conn)
        Dim ds As New DataSet()
        
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.Columns(0).Width = 200
        DataGridView1.Columns(1).Width = 200
        DataGridView1.Columns(2).Width = 280
        DataGridView1.Columns(3).Width = 200
        Me.WindowState = FormWindowState.Maximized


    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        TransactionForm.Show()
        Me.Hide()


    End Sub

    
    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        index = e.RowIndex
        If (e.RowIndex = -1) Then
            Return
        End If
        Dim selectedRow As DataGridViewRow

        selectedRow = DataGridView1.Rows(index)

        TextBox8.Text = selectedRow.Cells(0).Value.ToString()
        TextBox1.Text = selectedRow.Cells(1).Value.ToString()
        TextBox2.Text = selectedRow.Cells(2).Value.ToString()
        TextBox3.Text = selectedRow.Cells(3).Value.ToString()

    End Sub
    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        MsgBox("The Item is Updated. The Stocks of " & TextBox2.Text & " is now " & TextBox3.Text & ".")

        updatebutton()
        TextBox8.Text = ""
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""

        Dim conn As New OleDbConnection(CONNECTION_STRING)
        conn.Open()
        Dim com As String = "Select * from Table1 order by ID asc"
        Dim da As New OleDbDataAdapter(com, conn)
        Dim ds As New DataSet()

        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)

    End Sub
    Private Sub updatebutton()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        conn.Open()
        cmd = New OleDbCommand
        cmd.Connection = conn

        cmd.CommandText = "UPDATE [Table1] SET [Stocks] = '" & TextBox3.Text & "' WHERE [Food_Type] ='" & TextBox1.Text & "'and [Food_Name]= '" & TextBox2.Text & "'"

        cmd.ExecuteNonQuery()

        conn.Close()

    End Sub



  
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        StocksPrintForm.Show()

        
    End Sub

End Class