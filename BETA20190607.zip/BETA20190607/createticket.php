<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>  
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/createticket.css">
  <link rel="stylesheet" type="text/css" href="css/darkmode.css">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
</head>
<body>
<div class="container">
<form class="login100-form validate-form" action='sendticket.php' method='post'>
    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100">
                <div class="form-wrapper" id="wrapper">
                    <span class="login100-form-title p-b-48">
                  <div class="containerimg">
                    <center>
                        <img src="img/taoanguna.png" style="width: 50%;"> 
                    </center> 
                  </div>
                    </span>
                    <span class="login100-form-title p-b-48">
                    Create Ticket
                    </span>     
        <div class="form-group field">
            <label for='office' title='Office' data-title='Office'>Office</label>
            <?php
              $valueArray = retrieveOptions('office',true);
              outputSelect('office','',$valueArray,true);
            ?>
        </div>
        <div class="form-group field">
          <label>Employee Type </label>
          <br>  
         <div class="btn-group btn-group-toggle" data-toggle="buttons" style="width: 100% !important;">
          <label for='regular'  class="btn btn-outline-primary">
              <input type="radio" class="custom-control-input" required onchange="checkEmployeeType(this)" id="regular" name="employeetype" value="regular"/>
              Regular</label>
              <label for='irregular' class="btn btn-outline-primary">
              <input type="radio" class="custom-control-input" required onchange="checkEmployeeType(this)" id="irregular" name="employeetype" value="irregular"/>
              JO</label>
          </div>
        </div>
        <div class="form-group field" id="employeenumber_select">
            <label for='employeenumber'  title='Enter your Employee Number' data-title='Employee Number'>Employee Number</label>
            <input type="text" required autocomplete="off" id='employeenumber' class="form-control " name="employeenumber"/>
              <!--onkeypress="return isNumberKey(event)"<< add this to above input to restrict to numbers only-->
        </div>
        <div class="form-group field">
            <label for='employeename' title='Name' data-title='Name'>Employee Name</label>
            <input type="text" class="form-control" required autocomplete="off" id='employeename' required name='employeename' name="employeename">
        </div>        
        <div class="form-group field" id="concernDiv">
            <label for='concernDiv' title="Concern" data-title="Concern">Concern</label>
            <?php
              $valueArray = retrieveOptions('concern',true);
              outputSpecialSelect('concern','',$valueArray,false,'updateDetailsBox(this.options[this.selectedIndex].getAttribute("data-option-description"))');
            ?>
            <br>
            <textarea class="form-control" id='concern_details' name='concern_details' onkeyup="textAreaAdjust(this)" required name='concern_details'></textarea>
            <!--<label id='concernDetailsLabel' for='concern_details' title="Describe your tech-related issue here" data-title="Concern Details">
            </label>-->
        </div>
  
                  <div class="container-login100-form-btn">
            <div class="wrap-login100-form-btn">
              <div class="login100-form-bgbtn"></div>
                     <input type='submit' class="login100-form-btn" value='<?php if(!isset($_SESSION['userType'])) echo "Send"; else echo "Send";?> Ticket' name='Submit' class="form-submit" 
                     value="Send Ticket"/>
            </div>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
</body>

<script>

var employeeNumberStorage = "";

function isNumberKey(evt){//checks whether the key pressed is a number
  var charCode = (evt.which) ? evt.which : event.keyCode
  if (charCode > 31 && (charCode < 48 || charCode > 57))
      return false;
  return true;
}
function textAreaAdjust(o) {
  o.style.height = "1px";
  o.style.height = (25+o.scrollHeight)+"px";
}

function updateDetailsBox(placeHolderFragment){
  console.log("select value changed");
  document.getElementById("concern_details").placeholder="Please describe your issue related to "+placeHolderFragment+".";
  textAreaAdjust(document.getElementById("concern_details"));
  //document.getElementById("concernDetailsLabel").title="Please describe your issue related to "+placeHolderFragment+".";
}

function checkEmployeeType(element){
  if(element.value == "regular"){
    console.log("Regular selected");
    document.getElementById("employeenumber").value=employeeNumberStorage;
    document.getElementById("employeenumber").required=true;
    document.getElementById("employeenumber").disabled=false;
    employeenumber_select.style = "display: block;";
  }
  else{
    console.log("JO selected");
    employeeNumberStorage=document.getElementById("employeenumber").value;
    document.getElementById("employeenumber").value="";
    employeenumber_select.style = "display: none;";
  }
}

</script>
</html>