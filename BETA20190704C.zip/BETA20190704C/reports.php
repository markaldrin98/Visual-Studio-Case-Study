<?php include 'misc/config.php';?>
<div style="color:white;margin-top:70px; max-width: 1300px;" class="container">

	<select id="reportSelect" onchange='showTable(this)' style='color: black;'>
		<option value="" selected>-select a report to display-</option>
		<option value="admin">Admin Technical Assistance</option>
		<option value="techservice">Technician Service Record</option>
		<option value="servicelog">Service Rendered Log</option>
		<option value="concernlog">Concern Log</option>
		<option value="officelog">Office Log</option>
		<option value="changelogs">Changelogs</option>
	</select>

	<div id="admin" class="reportDiv">
		<br>
	<?php
		$valueArray = retrieveEmployees('admin',true);
		outputFullSelect("adminSelect","",$valueArray,false,'-select an admin-',false);//($nameString,$storedValue,$valueArray,$isRequired,$nullString,$othersToggle)

		$tableName="admin";
		$lefthandFields=retrieveOptionsNum("participation",false);
		foreach($valueArray as $name => $username){
			$activeTableName=$tableName.$username;
			$name=strtoupper($name);
			echo "<table name='$activeTableName'>";
			echo "<tr style='text-align:center; font-weight: bold;'><td colspan='100%'>ADMIN TECHNICAL ASSISTANCE - $name</td></tr>";
			outputHeadRow("Sample Left Element");

			foreach($lefthandFields as $field){
				$fieldDisplay = formatString($field);
				    echo "<tr>";
				    echo "<td>$fieldDisplay</td>";
				    for($month=1; $month<=12; ++$month){
				        echo "<td>"."asdjk".'</td>';
				        if($month==7) echo "<td>asdasdas/td>";
				        else if($month==12) echo "<td>2ND SEM</td>";
				    }
				    echo "</tr>";
			}

			echo "</table>";
		}
	?>
	<!--
		<td>JAN</td>
		<td>FEB</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>


	-->

	<table name="Admin Technical Assistance"><!--construct logic | should use retrieveOptions('participation') and then iterate through each item to query counts for each month-->
		<tr style='text-align:left;'><td colspan='100%'>ADMIN TECHNICAL ASSISTANCE - RUSSEL DAYRIT</td></tr>
		<tr style='text-align:right;'>
			<td style='text-align:left;'><b>Participation</b></td><td>JAN</td><td>FEB</td><td>MAR</td><td>APR</td>
		</tr>
		<tr style='text-align:right;'>
			<td style='text-align:left;'>Performed</td><td>4</td><td>44</td><td>22</td><td>42</td>
		</tr>
	</table>
	</div>

	<div id="techservice" class="reportDiv">
	<table name="Technician Service Record"><!--construct logic | should use retrieveOptions('participation') and then iterate through each item to query counts for each month-->
		<tr style='text-align:left;'><td colspan="100%">TECHNICIAN SERVICE RECORD - ROY MANUEL</td></tr>
		<tr style='text-align:right;'>
			<td style='text-align:left;'><b>Participation</b></td><td>JAN</td><td>FEB</td><td>MAR</td><td>APR</td>
		</tr>
		<tr style='text-align:right;'>
			<td style='text-align:left;'>Performed</td><td>4</td><td>44</td><td>22</td><td>42</td>
		</tr>
	</table>
	</div>

</div>
<link rel="stylesheet" type="text/css" href="css/reports.css">
<script>  
	function hideTables(){
	  console.log("Hiding tables");
	  tableElements = document.getElementsByClassName('reportDiv');
	  for(counter=0;counter<tableElements.length;counter++){
	    tableElements[counter].style.display='none';
	  }
	}

	function showTable(tableSelect){
	  hideTables();
	  document.getElementById(tableSelect.value).style.display='block';
	}

	hideTables();
</script>

<div class="">