
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~HTML FOR ADMIN MODAL~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~CURRENTLY UNUSED~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<div class="container">
<?php
    echo '<div id="'.$adminModalId.'" class="modal fade" role="dialog" data-backdrop="static">';
?>

<div class="modal-dialog">
  <!-- Modal content -->
  <div class="modal-content" style="color:black;">
    <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <center>
          <h4 class="modal-title">Records</h4></center>
        </div>
    <div class="modal-body">
    <!--<p>~Modal content here~</p>-->
            <div id="formContainer">
            <form name="modalForm" id="modalForm" method="post" action="updatetickets.php">
              <div class="form-group">
                  <label>Date/Time Created:</label>
                  <span id="date_created" name="date_created" class="form-control"></span>
              </div>
              <div class="form-group">
                  <label>Date/Time Accepted:</label>
                  <span id="date_accepted" name="date_accepted" class="form-control"></span>
              </div>
              <div class="form-group">
                  <label>Date/Time Assessed:</label>
                  <span id="date_assessed" name="date_assessed" class="form-control"></span>
              </div>
              <div class="form-group">
                  <label>Date/Time Fulfilled:</label>
                  <span id="date_fulfilled" name="date_fulfilled" class="form-control"></span>
              </div>
              <div class="form-group">
                  <label>Ticket ID:</label>
                  <span id="ticket_id_display" name="ticket_id_display" class="form-control"></span>
                  <input type="hidden" name="ticket_id" id="ticket_id" class="form-control"> 
              </div>
              <div class="form-group">
                  <label>Office:</label>
                  <?php
                    $valueArray = retrieveOptions('office',true);
                    outputSelect('office','',$valueArray,false);
                  ?>
              </div>
              <div class="form-group">
                  <label>Client Name:</label>
                  <!--<input type="text" class="form-control" id="client_name" name="client_name">-->
                  <span id="client_name" name="client_name" class="form-control"></span>
              </div>
              <div class="form-group">
                  <label>Employee Number:</label>
                  <!--<input type="text" class="form-control" id="employee_number" name="employee_number">-->
                  <span id="employee_number" name="employee_number" class="form-control"></span>
              </div>
              <div class="form-group">
                  <label>Concern:</label>
                  <span id="concern" name="concern" class="form-control"></span>
              </div>
              <div class="form-group">
                  <label>Assessment:</label>
                  <?php
                    $valueArray = retrieveOptions('assessment',true);
                    outputSelect('assessment','',$valueArray,false);
                  ?>
              </div>
              <div class="form-group">
                  <label>Job Description:</label>
                  <?php
                    $valueArray = retrieveOptions('job_description',true);
                    outputSelect('job_description','',$valueArray,false);
                  ?>
              </div>
              <div class="form-group">
                  <label>Job Details:</label>
                  <textarea id="job_details" name="job_details" class="form-control"></textarea>
              </div>
              <div class="form-group">
                  <label>Participation:</label>
                  <?php
                    $valueArray = retrieveOptions('participation',true);
                    outputSelect('participation','',$valueArray,false);
                  ?>
              </div>
              <div class="form-group">
                  <label>Approval Status:</label>
                  <?php
                    outputSelect('approval_status','',array("Approved" => "","Not Approved" => ""),false);
                  ?>
              </div>
              <div class="form-group">
                  <label>Respondent:</label>
                  <?php
                    retrieveTechs(true);
                  ?>
              </div>
              <div class="form-group">
                  <label>Status:</label>
                  <?php
                    $valueArray = retrieveOptions('status',true);
                    outputSelect('job_status','',$valueArray,false);
                  ?>
              </div>
              <div class="form-group">
                  <label>Remarks:</label>
                  <div id="chatlog" name="chatlog">
                  </div>

                  <!--CODE BLOCK FOR REMARKS/CHAT LOG-->
                  <div class="form-group">
                        <div class="container clearfix">
                            <div class='limiter'>
                                <div class='container-login100'>
                                    <div class='wrap-login100'>
                                        <div class='form-wrapper'>
                                            <span class='login100-form-title p-b-48'>Chat Log</span>    
                                                <div class="chat">   
                                                    <div class="chat-history">
                                                        <ul class="chat-ul">
                                                        </ul>
                                                    </div> <!-- end chat-history -->
                                                </div> <!-- end chat -->
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="remarks" name="remarks" placeholder="Type a message...">
                                                <span class="input-group-btn">
                                                    <input type="submit" id="Submit" class="btn btn-default" name="Submit" value="Ready Message">
                                                </span>
                                            </div><!-- /input-group -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                  </div>
              </div>

<!--
                                    <li class="clearfix">
                                        <div class="message">Par
                                            <div class="message-details">
                                                <p>August 10, 2019, My name</p>
                                            </div> 
                                        </div>
                                    </li>
                                    <li>
                                        <div class="message">Oy bakit par
                                            <div class="message-details">
                                                <p>August 11, 2019, My name</p>
                                            </div> 
                                        </div>
                                    </li>
-->

              <!--<div class="form-group">
                  <label>Time Elapsed:</label>
                  <span id="" name=""></span>
              </div>-->
              <input type="submit" value="Save Changes" name="Submit" style="width: 100%; padding: 10px; background-color: darkorange; border-color: darkorange; font-size: 18px; font-weight: bold; border-radius: 10px;">
          </form>
          </div><!--end of form container-->
  </div>
</div>
</div>
</div>  
<!--~~~~~~~~~~~~~~~~~~~~~~~~~END OF HTML FOR ADMIN MODAL~~~~~~~~~~~~~~~~~~~~~~~~~-->


<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~HTML FOR TECH MODAL~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<div class="container">
<?php
    echo '<div id="'.$techModalId.'" class="modal fade" role="dialog" data-backdrop="static">'
?>
<div class="modal-dialog">
  <!-- Modal content -->
  <div class="modal-content" style="color:black;">
    <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <center>
          <h4 class="modal-title">
                  Ticket <span id="tech_ticket_id_display" name="ticket_id_display"</span></h4></center>
        </div>
    <div class="modal-body">
    <!--<button onclick="closeTechModal()">&times;</button>-->
    <!--<p>~Modal content here~</p>-->
            <div id="formContainer">
            <form name="techForm" id="techForm" method="post" action="acceptticket.php">
              <div class="form-group" style="display:none;">
                  <label>Date/Time Created:</label>
                  <span id="tech_date_created" name="date_created" class="form-control"></span>
              </div>
              <div class="form-group" style="display:none;">
                  <label>Ticket ID:</label>
                  <span id="tech_ticket_id_display" name="ticket_id_display" class="form-control"></span>
                  <input type="hidden" name="ticket_id" id="tech_ticket_id" class="form-control">
              </div>
              <div class="form-group">
                  <label>Office:</label>
                  <span id="tech_office" name="tech_office" class="form-control"></span>
              </div>
              <div class="form-group">
                  <label>Client Name:</label>
                  <!--<input type="text" class="form-control" id="client_name" name="client_name">-->
                  <span id="tech_client_name" name="client_name" class="form-control"></span>
              </div>
              <div class="form-group">
                  <label>Concern:</label>
                  <span id="tech_concern" name="concern" class="form-control"></span>
              </div>
              <div class="form-group">
                  <label>Concern Details:</label>
                  <span id="tech_concern_details" name="concern_details" class="form-control"></span>
              </div>
              <input type="submit" value="Accept Ticket" name="Submit">
          </form>
              <button data-dismiss="modal">Return to List</button>
          </div><!--end of form container-->
  </div>
</div>
</div>
</div>
<!--~~~~~~~~~~~~~~~~~~~~~~~~~END OF HTML FOR TECH MODAL~~~~~~~~~~~~~~~~~~~~~~~~~-->

<script>
  
//--------------------------------------------FUNCTION PREPARES TECH MODAL-------------------------------------------//


function prepareTechModal(rowClicked){
        console.log("prepareModal called - tech");
        document.getElementById("tech_date_created").innerHTML=rowClicked.cells[0].innerHTML;
        document.getElementById("tech_ticket_id_display").innerHTML=rowClicked.cells[1].innerHTML;   //sets display value for ticket_id
        document.getElementById("tech_ticket_id").value=rowClicked.cells[1].innerHTML;               //sets ticket_value to be passed through post later
        document.getElementById("tech_office").innerHTML=rowClicked.cells[2].innerHTML;
        document.getElementById("tech_client_name").innerHTML=rowClicked.cells[3].innerHTML;
        document.getElementById("tech_concern").innerHTML=rowClicked.cells[4].innerHTML;
console.log(document.getElementById("myModal"));
        //openTechModal();
}
//-------------------------------------END OF FUNCTION THAT PREPARES TECH MODAL--------------------------------------//


//-------------------------------------------FUNCTION PREPARES ADMIN MODAL--------------------------------------------//
//currently not in use
function prepareModal(rowClicked){
        console.log("prepareModal called - admin");
        document.getElementById("date_created").innerHTML=rowClicked.cells[0].innerHTML;
        document.getElementById("date_accepted").innerHTML=rowClicked.cells[1].innerHTML;
        document.getElementById("date_assessed").innerHTML=rowClicked.cells[2].innerHTML;
        document.getElementById("date_fulfilled").innerHTML=rowClicked.cells[3].innerHTML;

        document.getElementById("ticket_id_display").innerHTML=rowClicked.cells[4].innerHTML;   //sets display value for ticket_id
        document.getElementById("ticket_id").value=rowClicked.cells[4].innerHTML;               //sets ticket_value to be passed through post later

        document.getElementById("office").value=rowClicked.cells[5].innerHTML;
        document.getElementById("client_name").innerHTML=rowClicked.cells[6].innerHTML;
        document.getElementById("employee_number").innerHTML=rowClicked.cells[7].innerHTML;
        document.getElementById("concern").innerHTML=rowClicked.cells[8].innerHTML;
        document.getElementById("assessment").value=rowClicked.cells[10].innerHTML;
        document.getElementById("job_description").value=rowClicked.cells[11].innerHTML;
        document.getElementById("job_details").innerHTML=rowClicked.cells[12].innerHTML;
        document.getElementById("participation").value=rowClicked.cells[13].innerHTML;
        document.getElementById("approval_status").value=rowClicked.cells[14].innerHTML;
        document.getElementById("respondent").value=rowClicked.cells[15].innerHTML;
        document.getElementById("job_status").value=rowClicked.cells[16].innerHTML;
        //openModal();
}
//-------------------------------------END OF FUNCTION THAT PREPARES ADMIN MODAL--------------------------------------//

  
//----------------------------MODAL SCRIPTS--------------------------------//
/*
var modal = document.getElementById("myModal");
var techModal = document.getElementById("techModal");
// Get the <span> element that closes the modal - currently unused
var span = document.getElementsByClassName("closeModal")[0];

function openModal() {//opens admin modal
  modal.style.display = "block";
  console.log("openModal called");
}

function openTechModal() {//opens tech modal
  document.getElementById("techModal").style.display = "block";
  console.log("openTechModal called");
}

function closeModal() {
  modal.style.display = "none";
  console.log("closeModal called");
}

function closeTechModal() {
  document.getElementById("techModal").style.display = "none";
  console.log("closeChatlog called");
}

// When the user clicks on <span> (x), close the modal
//span.onclick = closeModal();

//function to close modal when user clicks outside of it - disabled for now

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
*/


//--------------------------END OF MODAL SCRIPTS---------------------------//
</script>