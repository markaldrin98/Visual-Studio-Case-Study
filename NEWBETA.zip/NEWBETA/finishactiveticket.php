<?php
include_once("misc/config.php");  
echo "<br><br><br><br><br><br><br><br>";  
$ticketID = $_POST["ticket_id"];

$assignCheck = false;   //gate variable
$ticketCheck = false;   //gate variable

if(isset($_POST['Submit']) && $_POST['Submit']!=''){//if clause checks to make sure user arrived on this page through the intended channel
//below code block updates ticket currently assigned to the tech in the 'tech_credentials' table
    $queryString = 'UPDATE tech_credentials SET current_ticket = NULL WHERE employee_name="'.$_SESSION["client_name"].'"';  
                   if (mysqli_query($conn, $queryString)) { //query passes, gate is cleared
                        echo "<script>console.log('"."Check 1 clear"."')</script>";
                        $assignCheck = true;
                    } 
                    else {    //report sql error
                        echo '<script>console.log("Check 1 - '.mysqli_error($conn).'");</script>';
                    }
    //end of code block

    //below code block sets date_completed in the 'tickets' table
    $queryString = 'UPDATE tickets SET date_fulfilled=now() WHERE ticket_id='.$ticketID;  
                   if (mysqli_query($conn, $queryString)) { //query passes, gate is cleared
                        echo "<script>console.log('"."Check 2 clear"."')</script>";
                        $ticketCheck = true;
                    } 
                    else {    //report sql error
                        echo '<script>console.log("Check 2 - '.mysqli_error($conn).'");</script>';
                        echo "<script>console.log('".$queryString."')</script>";
                    }
    //end of code block

    if($assignCheck && $ticketCheck){   //checks gate variables - if both gate variables return true, then both queries were successful and the page should redirect
        echo "<script>console.log('"."Redirecting to outstanding"."')</script>";
        redirect('outstanding.php');
    }
    else{   //else do nothing
        echo "<script>console.log('"."Doing nothing"."')</script>";
    }
}//end of if clause
else{//user /did not/ arrive on this page through the intended channel, redirect to ticket creation
    redirect("index.html");
}

    

?>

