<html>
<head>    
    <title>Update Record</title>
</head>
<body>

<?php
include_once("config.php");


if(isset($_POST['Update'])) {   
	$id = $_POST['id']; 
	$lname = $_POST['lname'];
	$fname = $_POST['fname'];
	$mname = $_POST['mname'];
	$snumber = $_POST['snumber'];
	$email =  $_POST['email'];
        
    if(empty($lname) || empty($fname) || empty($mname) || empty($snumber) || empty($email)) {                
        if(empty($lname)) {
            echo "<font color='red'>No last name given!</font><br/>";
        }
        
        if(empty($fname)) {
            echo "<font color='red'>No first name given!</font><br/>";
        }
        
        if(empty($mname)) {
            echo "<font color='red'>No middle name given!</font><br/>";
        }

        if(empty($snumber)) {
            echo "<font color='red'>No student number given!</font><br/>";
        }

        if(empty($email)) {
            echo "<font color='red'>No email given!</font><br/>";
        }
        //echo "<br/><a href='javascript:self.history.back();'>Back</a>";
    } else { 
        $result = mysqli_query($conn, "UPDATE student_info SET lname='$lname', fname='$fname', mname='$mname', snumber='$snumber',email='$email' WHERE id=$id");
        dtconsole("UPDATE student_info SET lname='".$lname."', fname='".$fname."', mname='".$mname."', snumber='".$snumber."',email='".$email."') WHERE id=".$id);
        echo "<font color='green'>Data updated successfully.";
        echo "<br/><a href='faceplate.php'>Index</a>";
        header("Location: faceplate.php");
    }
}
?>

<?php
$id = $_GET['id']; 
$result = mysqli_query($conn, "SELECT * FROM student_info WHERE id='$id'"); 

while($res = mysqli_fetch_array($result))
{
	dtconsole($res);
	$lname = $res['lname'];
	$fname = $res['fname'];
	$mname = $res['mname'];
	$snumber = $res['snumber'];
	$email =  $res['email'];
}

?>
    <form style="margin-left:20px;margin-top:40px;" method="get" action="faceplate.php"><input type="submit" value="Return to Index" name="returntoindex"></form>
    <br/><br/>
    
    <form method="post" action="updaterecord.php?id=$id">
        <table border="0">
            <tr> 
                <td>Last Name</td>
                <td><input type="text" name="lname" value="<?php echo $lname;?>"></td>
            </tr>
            <tr> 
                <td>First Name</td>
                <td><input type="text" name="fname" value="<?php echo $fname;?>"></td>
            </tr>
            <tr> 
                <td>Middle Name</td>
                <td><input type="text" name="mname" value="<?php echo $mname;?>"></td>
            </tr>
            <tr> 
                <td>Student Number</td>
                <td><input type="text" name="snumber" value="<?php echo $snumber;?>"></td>
            </tr>
            <tr> 
                <td>Email</td>
                <td><input type="text" name="email" value="<?php echo $email;?>"></td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="Update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>

