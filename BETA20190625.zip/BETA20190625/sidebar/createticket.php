<body onload="myFunction()">
<img src="img/taoanguna.png" id="loader">
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>  
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/createticket.css">
  <link rel="stylesheet" type="text/css" href="css/darkmode.css">
  <link rel="stylesheet" type="text/css" href="css/fontStyle.css">
</head>
  <div class="container" style="max-width: 600px; margin-top: 80px;" >
  <div class="lineBorder">
    <!--START OF MODULE FOR TICKET DISPLAY (ADMIN DISPLAY)-->
<form class="login100-form validate-form" action='sendticket.php' method='post'>
<center>
  <img src="img/taoanguna.png" width="40%">
  <br><br>
  <h2>Create Ticket</h2>
</center>
<br>
    <div class="form-group">
      <label for='office' title='Office' data-title='Office'>Office</label>
        <?php
          $valueArray = retrieveOptions('office',true);
          outputSelect('office','',$valueArray,true);
        ?>
    </div>
    <div class="form-group">
      <label>Employee Type </label>
        <br>  
          <div class="btn-group btn-group-toggle" data-toggle="buttons" style="width: 100% !important;">
              <label for='regular'  class="btn btn-outline-primary active">
                  <input type="radio" class="custom-control-input" required onchange="checkEmployeeType(this)" id="regular" name="employeetype" value="regular" checked/>Regular
              </label>
              <label for='irregular' class="btn btn-outline-primary">
                <input type="radio" class="custom-control-input" required onchange="checkEmployeeType(this)" id="irregular" name="employeetype" value="irregular"/>JO
              </label>
          </div>
    </div>
    <div class="form-group" id="employeenumber_select">
      <label for='employeenumber'  title='Enter your Employee Number' data-title='Employee Number'>Employee Number</label>
          <input type="text" required autocomplete="off" id='employeenumber' class="form-control" name="employeenumber"  onkeypress="return isNumberKey(event)"/>
              <!--onkeypress="return isNumberKey(event)"<< add this to above input to restrict to numbers only-->
    </div>
    <div class="form-group">
      <label for='employeename' title='Name' data-title='Name'>Employee Name</label>
      <input type="text" class="form-control" required autocomplete="off" id='employeename' required name='employeename' name="employeename">
    </div>        
    <div class="form-group" id="concernDiv">
      <label for='concernDiv' title="Concern" data-title="Concern">Concern</label>
          <?php
            $valueArray = retrieveOptions('concern',true);
            outputSpecialSelect('concern','',$valueArray,false,'updateDetailsBox(this.options[this.selectedIndex].getAttribute("data-option-description"))');
          ?>
          <br>
      <textarea class="form-control" id='concern_details' name='concern_details' onkeyup="textAreaAdjust(this)" required name='concern_details'></textarea>
        <!--<label id='concernDetailsLabel' for='concern_details' title="Describe your tech-related issue here" data-title="Concern Details">
            </label>-->
    </div>
        <input type='submit' class="btn btn-default sendTicketBtn" value='<?php if(!isset($_SESSION['userType'])) echo "Send"; else echo "Send";?> Ticket' name='Submit' class="form-submit" value="Send Ticket"/>
  </form>
</div>
</div>
</div>
</body>

<script>

var employeeNumberStorage = "";

function isNumberKey(evt){//checks whether the key pressed is a number
  var charCode = (evt.which) ? evt.which : event.keyCode
  if (charCode > 31 && (charCode < 48 || charCode > 57))
      return false;
  return true;
}
function textAreaAdjust(o) {
  o.style.height = "1px";
  o.style.height = (25+o.scrollHeight)+"px";
}

function updateDetailsBox(placeHolderFragment){
  console.log("select value changed");
  document.getElementById("concern_details").placeholder="Please describe your issue related to "+placeHolderFragment+".";
  textAreaAdjust(document.getElementById("concern_details"));
  //document.getElementById("concernDetailsLabel").title="Please describe your issue related to "+placeHolderFragment+".";
}

function checkEmployeeType(element){
  if(element.value == "regular"){
    console.log("Regular selected");
    document.getElementById("employeenumber").value=employeeNumberStorage;
    document.getElementById("employeenumber").required=true;
    document.getElementById("employeenumber").disabled=false;
    employeenumber_select.style = "display: block;";
  }
  else{
    console.log("JO selected");
    employeeNumberStorage=document.getElementById("employeenumber").value;
    document.getElementById("employeenumber").value="";
    employeenumber_select.style = "display: none;";
  }
}
function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 1500);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>
</html>