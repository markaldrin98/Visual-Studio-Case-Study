﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class Form3
    Private Sub Form3_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim rptDoc As ReportDocument

        rptDoc = New CrystalReport1
        Dim Report1 As New CrystalReport1

        CrystalReportViewer1.ReportSource = rptDoc
        CrystalReportViewer1.Refresh()

        Report1.SetParameterValue("Money2", OrderForm.TextBox1.Text)
        Report1.SetParameterValue("TotalAmount", OrderForm.TextBox4.Text)
        Report1.SetParameterValue("Change1", OrderForm.TextBox6.Text)
        Report1.SetParameterValue("Date", OrderForm.Label13.Text)
        Report1.SetParameterValue("Time", OrderForm.Label14.Text)
        Report1.SetParameterValue("TypeOfOrder", OrderForm.ComboBox3.Text)
        Report1.SetParameterValue("Vat", OrderForm.TextBox9.Text)
        Report1.SetParameterValue("TotalItems", OrderForm.TextBox11.Text)
        Report1.SetParameterValue("TransactionID", OrderForm.TextBox8.Text)
        Report1.SetParameterValue("Customer", OrderForm.TextBox7.Text)



        CrystalReportViewer1.ReportSource = Report1
        CrystalReportViewer1.ParameterFieldInfo = Report1.ParameterFields

        Me.WindowState = FormWindowState.Maximized
       
    End Sub

    Private Sub CrystalReportViewer1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrystalReportViewer1.Load

    End Sub
End Class