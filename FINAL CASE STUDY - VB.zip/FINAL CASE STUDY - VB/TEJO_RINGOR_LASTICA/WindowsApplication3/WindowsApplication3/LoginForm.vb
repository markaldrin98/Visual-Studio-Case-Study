﻿Public Class LoginForm
    Dim attempt As Integer = 1
    Dim settings As New My.MySettings()

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim username, password As String
        username = TextBox8.Text
        password = TextBox1.Text



        If username = "admin" And password = "admin" Then
            MessageBox.Show("Login Successful!", "System Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.Hide()
            TransactionForm.Show()
        ElseIf attempt = 3 Then
            MessageBox.Show("Maximum number of Attempts (3). The Program will now close. ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Close()
        Else
            MessageBox.Show("Incorrect Username or Password. Please re-enter. You currently have reached attempt " & attempt & " of 3. "" ", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            attempt = attempt + 1
            TextBox8.Text = ""
            TextBox1.Text = ""
            TextBox8.Focus()

        End If

       

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            TextBox1.PasswordChar = ""

        Else
            TextBox1.PasswordChar = "*"

        End If
    End Sub

    Private Sub LoginForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox8.Select()

    End Sub

    Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged
    End Sub

    Private Sub TextBox8_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.Enter
        If (TextBox8.Text = "Password") Then
            TextBox8.Text = ""
        End If

    End Sub

    Private Sub TextBox8_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.Leave
        If (TextBox8.Text = "Password") Then
            TextBox8.Text = ""
        End If

    End Sub
End Class