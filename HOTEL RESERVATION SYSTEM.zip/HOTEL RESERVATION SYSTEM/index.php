

<?php include "header.php";
session_start();
?>

<div id="cover">
<div id="content">
<?php global $msg; echo $msg;?>
<br/><h3>Welcome,</h3><br/>

<?php include "demo1.html";?>
<br>
<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Classic rooms at the debremarkos fm international hotel are unusually spacious, 
<br>
luxuriously furnished and tastefully decorated. Each room offers a comfortable environment <br>
for work or relaxation and features the following facilities and services:<br>

    Luxury Collection King size bed<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Individually controlled air-conditioning
    Two telephone lines<br>
    Computer data port access (The hotel has also introduced internet lease lines to make communication faster and more efficient)
    Flat Screen TV, 42 inch<br>
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Electronic mini-bar and private electronic safe
    Large and practical work desk<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Luxury Collection bathroom amenities, towels, slippers, bathrobes, hair dryer and weigh scale
    Speakers in the bathrooms<br>
    Bottled water provided daily
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Complimentary morning coffee or tea served up to 8:30 AM upon request  with wake up call
    Fruit basket delivered upon request
 
</p>
<p>&nbsp;&nbsp;</p>
    <?php include "footer.php";?>
</div>
</div>

