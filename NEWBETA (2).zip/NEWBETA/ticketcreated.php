<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
</head>
<br/>
<center>
  <div class="container">
    <div class="page-header">
    <h1>Success!</h1>
      <p>Your ticket was successfully sent to the IT Department.</p>
      <?php
        if(checkGet('ticket')!=false){
          echo "<p>Your ticket number is <".checkGet('ticket')."></p>";
        }
      ?>
      <p>Click <a href="index.php">here</a> to return to ticket creation.</p>
    </div>
</div>
</center>
<div class="row">
<center>

 </center>
</div>
</body>
</html>
