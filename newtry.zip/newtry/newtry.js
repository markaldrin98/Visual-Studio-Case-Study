


var cssProperties = anime({
  targets: '#cssProperties .el',
  duration: 5000,
  
  opacity: .5,
  backgroundColor: '#222222',
  easing: 'easeInOutQuad'

});



anime.timeline({})
  .add({
    targets: '.ml5 .line',
    opacity: [0.5, 1],
    scaleX: [0, 1],
    delay: 1000,
    easing: "easeInOutQuad",
    duration: 1000

  }).add({
    targets: '.ml5 .line',
    duration: 600,
    easing: "easeInOutExpo",
    translateY: function(e, i, l) {
      var offset = -0.625 + 0.625*2*i;
      return offset + "em";
    }

  }).add({
    targets: '.ml5 .letters-left',
    opacity: [1],
    translateX: ["0.5em", 0],
    easing: "easeOutExpo",
    duration: 600,
    offset: '-=100'
  }).add({
    targets: '.ml5 .letters-right',
    opacity: [1],
    translateX: ["-0.5em", 0],
    easing: "easeOutExpo",
    duration: 600,
    offset: '-=600'
  }).add({
  //  targets: '.ml5 .line',
  //  opacity: [0],
  //  duration: 1000,
  //  easing: "linear",
 //   delay: 1000
  });
