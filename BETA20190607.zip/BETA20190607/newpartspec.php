<?php include 'misc/config.php';?>
<?php
if(checkPost('Submit')) {//checks if device_id is set
    $operation = checkPost('Submit');
    $target = '';
    $field = '';
    $device_id = checkPost('device_id');
    $value = checkPost('new_value');
    $details = checkPost('new_detail');
    $redirect = checkPost('trail');

    if($operation == 'Add Part'){
        $target = 'device_parts_table';
    }
    else if($operation == 'Add Specificaton'){
        $target = 'device_specs_table';
    }
    $insertQuery = "INSERT INTO $target VALUES('$device_id','$value','$details')";
    echo "<br><br><br><br><br>";
    if(mysqli_query($conn, $insertQuery)) {
        echo "Query successful";
        redirect($redirect);
    } 
    else{
        echo "Query failure";
    }
}
else{
    redirect('index.php');
}
                  
?>

