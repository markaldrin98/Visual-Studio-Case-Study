<?php include 'misc/config.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>IT Ticketing System</title>
</head>
<body>
<div class="container" style="margin-top: 50px;">
    <div class="card-deck">
        <div class="card mb-4">
            <div class="card-body">
                <h4 class="card-title">Tech 1</h4>
                <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-body">
                <h4 class="card-title">Tech 1</h4>
                <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
        </div>
        <div class="w-100 d-none d-sm-block d-md-none"><!-- to make card responsive on mobile devices--></div>
        <div class="w-100 d-none d-md-block d-lg-none"><!-- to make card responsive on tablet --></div>
        <div class="w-100 d-none d-lg-block d-xl-none"><!-- to make card responsive on desktop or laptop --></div>
        <div class="w-100 d-none d-xl-block"><!-- blocks the row of card --></div>
        <div class="card mb-4">
            <div class="card-body">
                <h4 class="card-title">7 Tech</h4>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-body">
                <h4 class="card-title">8 Tech</h4>
                <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
        </div>
    </div>

    <div class="card-header cardStyleHeader"></div>
          <ul class="list-group" id="try">
            <li href="#showSpec" class="list-group-item styleList" data-toggle="collapse">Show Sample Data</li>
          <div id="showSpec" class="collapse">
              <li class="list-group-item d-flex justify-content-between align-items-center">Sample List</li>
              <li class="list-group-item d-flex justify-content-between align-items-center">Sample List</li>
              <li class="list-group-item d-flex justify-content-between align-items-center">Sample List</li>
          </ul>
           <ul class="list-group" id="try">
            <li href="#showSpec" class="list-group-item styleList" data-toggle="collapse">Show Sample Data</li>
          <div id="showSpec" class="collapse">
              <li class="list-group-item d-flex justify-content-between align-items-center">Sample List</li>
              <li class="list-group-item d-flex justify-content-between align-items-center">Sample List</li>
              <li class="list-group-item d-flex justify-content-between align-items-center">Sample List</li>
          </ul>
 </div>
 <br>
</body>
</html>



<script>
    function showPass(pass_id,icon_element) {
  var x = document.getElementById(pass_id);
  var iconChange = document.getElementById("changeIcon");

  if (x.type === "try") {
    x.type = "text";
    icon_element.innerHTML = "<span>S</span>";

  } else {
    x.type = "try";
    icon_element.innerHTML = "-";
  }
}

</script>