<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/outstandingstyle.css">
  <script src="darkmode.js"></script>
  <link rel="stylesheet" type="text/css" href="css/darkmode.css">
 </head>
<body>
<div class="nav-container" style="margin-top: 80px;">    
<?php
    global $searchstr;
    global $adminModalId;
    global $techModalId;
    $searchstr='';
    if(isset($_POST['searchstr']) && $_POST['searchstr']!=''){
        $searchstr = $_POST['searchstr'];
    }

    //CODE BLOCK DETERMINES WHICH MODAL TO DESIGNATE 'myModal' AND SETS THE RELEVANT FIELDS//
    if(checkUserPrivilege()=='admin'){
        echo "<script>
            userswitch = 'admin';
        </script>";
        $adminModalId = 'myModal';
        $techModalId = 'techModal';
    }
    else if(checkUserPrivilege()=='tech'){        
        echo "<script>
            userswitch = 'tech';
        </script>";
        $adminModalId = 'adminModal';
        $techModalId = 'myModal';
    }
    toConsole($adminModalId.":".$techModalId);
?>
    <?php
        if(checkUserPrivilege()=="admin"){
            echo '
                <!--html for search bar and associated filters-->
                    <form id="searchForm" name="searchForm "method="post" action="outstanding.php"></form>
                    <!--<input form="searchForm" type="submit" name="Submit" value="Search" style="background-color: #242e39; border-color: black; color:white;">-->
                    <center>
                        <div class="input-group" style="max-width: 500px;"> 
                            <input type="text" form="searchForm" class="form-control" type="text" name="searchstr" id="searchstr" placeholder="Search..." name="search">
                                    <div class="input-group-btn">
                                        <input form="searchForm" type="submit" value="Search" id="searchButton" name="searchButton" class="btn btn-default">
                                    </div>
                        </div>
                    </center>
                <!-- end of html for search bar and associated filters-->
            ';
        echo '<div class="tabcontents" style="margin-top: 20px;">
                <div class="tabs">
                    <input form="searchForm" class="custom-control-input" type="checkbox" id="showArchived" name="showArchived" value="completed_ticket" onload="return toggleCbox(this)" onclick="toggleCbox(this)"';
                            echo checkPost('showArchived');
                            if(checkPost('showArchived')!=false){
                            echo ' checked';
            }
                echo '><label class="custom-control-label" for="showArchived">Show Archived</label></div>';
                echo '<div class="tabs">
                <input form="searchForm" class="custom-control-input" type="checkbox" id="hideIncomplete" name="hideIncomplete" value="incomplete_ticket" onload="toggleNegativeCbox(this)" onclick="toggleNegativeCbox(this)"';
            echo checkPost('hideIncomplete');
            if(checkPost('hideIncomplete')!=false){
                echo ' checked';
            }
        echo '><label class="custom-control-label" for="hideIncomplete">Hide Incomplete Tickets</label>
        </div></div>';
        }

        ?>
    <center>
<?php
    $specialMessage='';//used to output 'no tickets to display' where there are no tickets to display

  $colorSwitch=0;
?>
    
    <form method="post" id="mainForm" action="updatetickets.php"></form>
    <form method="post" id="acceptForm" action="acceptticket.php"></form>

    <!--START OF THE VERY LARGE DISPLAY TABLE-->
    <div class="table-responsive">
    <table width='100%' border=0  id="outputTable" name="outputTable">

<?php 
//code block checkes a)if user should be on this page b)what the user should see on this page
    if(checkUserPrivilege()=='admin'){     //if user is an admin, run this
        displayAdmin();
    }//end of admin check
    else if(checkUserPrivilege()=='tech'){ //if user is a tech, run this
        displayTech();
    }//end of tech check   
    else{//user is neither an admin or a tech, redirect to ticket creation  //default clause - a failsafe for when user inputs page address manually - put in one of these clauses on each sensitive page
        redirect("index.php");
    }
//end of code block


    function displayTech(){ //function to render tech's interface
        global $colorSwitch,$conn;
        $specialMessage="";
        $result='';
            $result = mysqli_query($conn, "SELECT * FROM tickets WHERE (approval_status = 'Not Approved' OR job_status != 'Completed') AND (respondent IS NULL) ORDER BY date_created DESC");
            //above query selects all tickets that are either not completed or not approved and have no tech assigned
        
        if(!$result || mysqli_num_rows($result)==0) {
            $specialMessage="No tickets to display!";
        }//checks to make sure there are tickets to be displayed
        else{

        }
        $techCheck = false;

            $gateQuery = mysqli_query($conn, "SELECT * FROM tech_credentials WHERE employee_name = '".callUser()."'");
            if(!$gateQuery || mysqli_num_rows($gateQuery)==0) {//checks to make sure tech is extant - mostly unnecessary, but may prevent errors
            }   
            else{
                while($gateRes = mysqli_fetch_array($gateQuery)){                        
                    if($gateRes['current_ticket'] != NULL || $gateRes['current_ticket'] != ""){ //checks to make sure the tech doesn't already have a ticket selected. If he does, redirect to activeticket.php
                        $message = '<div class="darkText"><p><center>Error! You must finish your current ticket before accepting a new one!</p>';
                        $message .= '<p>Click <a href="activeticket.php">here</a> to view your active ticket.</p></div></center>';
                        echo $message;
                        //echo "<script>alert('".$message."');</script>";
                        //redirect('activeticket.php');
                    }     
                    else{//if tech does not have active ticket, set techCheck to true so the tech UI displays
                        $techCheck=true;
                    }
                }
            }

        if($techCheck){//if true, display tech interface
            echo "

                <tr bgcolor='#AAAAAA' height='40'>
                    <th>Date/Time Created</th>
                    <th>Ticket ID</th>
                    <th>Office</th>
                    <th>Client Name</th>
                    <th>Concern</th>
                    <th style='display:none;'>Concern Details</th>
                </tr>
            ";
            while($res = mysqli_fetch_array($result)) {  //iterates through all tickets
                $optionString = "";

                    echo '<tr';
                        if($res['date_fulfilled'] && $res['approval_status']=='Approved'){//checks if the ticket has been completed - if so, makes the ticket invisible
                            echo ' data-completion-status="completed" class="completed_ticket pointerElements"';
                        }
                        else{
                            echo ' data-completion-status="not completed" class="incomplete_ticket pointerElements"';                            
                        }
                    //echo 'onclick="callModal('.$res["ticket_id"].')"';   
                    echo ' onclick="viewTicket(this)" id="'.$res["ticket_id"].'"';
                    echo '>';

                    echo "<td>".$res['date_created']."</td>";           //static
                    echo "<td>".$res['ticket_id']."</td>";              //displays ticket_id specified in ticket
                    echo "<td>".$res['office']."</td>";                 //displays office specified in ticket
                    echo "<td>".$res['client_name']."</td>";            //displays client_name specified in ticket
                    echo "<td>".$res['concern']."</td>";                //client concern - static
                 /*   echo "<td>".$res['concern_details']."</td>";  */      //concern details - static
                    //text display for 'concern'

                    /*if($res['respondent']==""){                       //code block displays the 'accept ticket' button - removed, function to be transferred to a modal displayed upon clicking the row (like in admin table)
                        echo '<td>
                        <input form="acceptForm" class="btn btn-default" type="submit" name="Submit" value="Accept Ticket" style="background-color: #242e39; border-color: black; color:white;">
                        <input form="acceptForm" type="hidden" name="acceptingRespondent" value="'.$_SESSION['client_name'].'"">
                        <input form="acceptForm" type="hidden" name="ticketID" value="'.$res['ticket_id'].'"">
                        </form></td>';
                    }
                    else{
                        echo "<td>".$res['respondent']."</td>"; 
                    }*/
                    
                    /*echo '<td><textarea style="color:black;resize:none;" value="'.$res["remarks"].'" name="remarksSelect'.$res["ticket_id"].'"></textarea></td>
                    ';//textarea control for 'remarks'*/
                    echo "</tr>";
            }//end of while loop

                    echo '
                    </table>  ';  //code block closes table
        }//end of techCheck if()

    }//end of displayTech function

    function displayAdmin(){    //function that displays admin interface
        global $colorSwitch,$conn;
        $specialMessage='';

        if(checkPost('searchstr')!=false){  //code block chooses what to output based on posted search box - comment this code block out if using JS search filter
            $resultString = "SELECT * FROM tickets WHERE (client_name LIKE '%".checkPost('searchstr')."%' OR job_description LIKE '%".checkPost('searchstr')."%' OR office LIKE '%".checkPost('searchstr')."%' OR concern LIKE '%".checkPost('searchstr')."%' OR ticket_id LIKE '%".checkPost('searchstr')."%') ORDER BY date_created DESC";
            //$resultString = "SELECT * FROM tickets ";
            $result = mysqli_query($conn,$resultString);
            //above query selects all tickets that are either not completed or not approved and have no tech assigned and satisfy search query
        }
        else{
            $result = mysqli_query($conn, "SELECT * FROM tickets ORDER BY date_created DESC");
            //above query selects all tickets that are either not completed or not approved
        }
        if(!$result || mysqli_num_rows($result)==0) {//checks to make sure there are tickets to be displayed
            $specialMessage="No tickets to display!";
            echo $specialMessage;
        }
        else{
        }
            //code block initializes the head row of the ticket table
            echo "
                <!--<tr bgcolor='#AAAAAA' height='70'>
                    <th colspan='4'><b>Date Log</b></th>
                    <th colspan='4'><b>Client</b></th>
                    <th colspan='4'><b>Admin</b></th>
                    <th colspan='5'><b>Tech</b></th>                    
                </tr>-->
                <tr bgcolor='#AAAAAA' height='40'>";
                    $fieldArray = retrieveFields('tickets');
                    for($i=0;$i<count($fieldArray)-1;$i++){
                        echo "<th class='headerStyle'>".$fieldArray[$i]."
                        </th>";
                    }
                echo "</tr>";  

            while($res = mysqli_fetch_array($result,MYSQLI_ASSOC)) {             //iterates through all tickets
                $optionString = "";

                    echo '<tr
                    ';
                        if($res['date_fulfilled'] && $res['approval_status']=='Approved'){//checks if the ticket has been completed - if so, makes the ticket invisible
                            echo ' data-completion-status="completed" class="completed_ticket pointerElements"';
                        }
                        else{
                            echo ' data-completion-status="not completed" class="incomplete_ticket pointerElements"';                            
                        }
                    //echo 'onclick="callModal('.$res["ticket_id"].')"';   
                    echo ' onclick="viewTicket(this)" id="'.$res["ticket_id"].'"';
                    echo '>';
                    /*for($i=0;$i<count($res);$i++){
                        echo "<td>".$res[i]."</td>";
                    }*/

                    foreach ($res as $key => $value) {
                        if ($key == 'is_archived' || $key == 'remarks'){
                            if($key=='remarks'){
                                echo "<td style='display:none;'>".prepareChatlog($value)."</td>";
                            }
                            else{
                                echo "<td style='display:none;'>".$value."</td>";
                            }        
                        }
                        else{                   
                            //echo "<td style='display:none;'>".$value."</td>";
                            echo "<td style=''>".$value."</td>";
                        }
                    }
                    echo "</tr>";

            }//end of while loop
            echo '
                    </table> 
                    </div>   
                        <center>
                            <!--<input form="mainForm" class="btn btn-default" type="submit" name="Submit" value="Save Changes" 
                            style="background-color: #242e39; border-color: black; color:white; padding: 15px; width: 20%;">-->';
                            //code block closes table

    }//end of displayAdmin function
        
        ?>
            
        <br><br><br><br>
    <!--</form>-->
    <!--<input form="mainForm" class="btn btn-default" type="submit" name="Submit" value="Save">-->
</div>
</body>
<script>

var grandTable = document.getElementById('outputTable');

//------------------FUNCTION CHECKS WHICH CELLS UNDER TIME_ELAPSED COLUMN SHOULD BE UPDATED------------//
//currently not supported
function updateTimers(){    
    for (var i = 0, row; row = grandTable.rows[i]; i++) {   //iterates through the rows of grandTable/outputTable        
       //rows would be accessed using the "row" variable assigned in the for loop
            //function here to check whether date_accepted is set - index 1
        if((row.cells[1].innerHTML != "") && (row.cells[2].innerHTML == "")){   //date_accepted is set, date_fulfilled is not
            //console.log(row.cells[14]);
            toTick = row.cells[14].getElementsByTagName('span');
            clockTick(toTick[0],toTick[1],toTick[2]);
        }
    }
}
//------------END OF FUNCTION THAT CHECKS WHICH CELLS UNDER TIME_ELAPSED COLUMN SHOULD BE UPDATED------------//

//----------------------------------FUNCTION UPDATES TIME VALUES IN THE TIME_ELAPSED COLUMN------------------------------//
//currently not used
function clockTick(hourSpan, minuteSpan, secondSpan){ 
    var hours = parseInt(hourSpan.innerHTML);
    var minutes = parseInt(minuteSpan.innerHTML);
    var seconds = parseInt(secondSpan.innerHTML);

    seconds++;
    if(seconds==60){
      minutes++;
      seconds=0;
    }
    if(minutes==60){
      hours++;
      minutes=0;
    }
    hourSpan.innerHTML=hours.pad(2);
    minuteSpan.innerHTML=minutes.pad(2);
    secondSpan.innerHTML=seconds.pad(2);
}
//---------------------------END OF FUNCTION THAT UPDATES TIME VALUES IN THE TIME_ELAPSED COLUMN---------------------------//

function persistentClock(){ //calls the clock update function every second
setInterval(updateTimers, 1000);
}

//persistentClock(); //initializes timer scripts

window.onload=pageLoads();

function pageLoads(){//called onload to trigger checkbox functions
    if(document.getElementById('showArchived')){
        toggleCbox(document.getElementById('showArchived'));        
    }
    if(document.getElementById('hideIncomplete')){
        toggleNegativeCbox(document.getElementById('hideIncomplete'));
    }
}

function testFunction(rowClicked){//test function-remove upon completion
    console.log(rowClicked.id);
    alert(rowClicked.id);
}

function setValue(elementId,setValue){//function to set .value of a control
    element = document.getElementById(elementId);
    element.value = setValue;
}

function setInner(elementId,setValue){//function to set innerHTML of an element
    element = document.getElementById(elementId);
    element.innerHTML = setValue;
}

function viewTicket(rowElement){
    window.location.href = "viewticket.php?ticket_id="+rowElement.id;
}
</script>
</html>