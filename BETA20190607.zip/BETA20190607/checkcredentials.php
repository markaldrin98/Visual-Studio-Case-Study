<?php include 'misc/config.php';?>
<?php
    $presentCheck = false; 
if(isset($_POST["username"]) && !empty($_POST["username"])) {
            $userIn=$_POST['username'];
            $passIn=$_POST['password']; 
                            //echo $passIn.$userIn;
            $result = mysqli_query($conn, "SELECT * FROM tech_credentials");  
                if(mysqli_num_rows($result)!=0) {     //checks if credentials table is not empty      
                    while($res = mysqli_fetch_array($result)){
                            //iterating through credentials
                        if($userIn == $res['username'] && $passIn == $res['password']){
                            $_SESSION['loggedin'] = true;
                            $_SESSION['username'] = $userIn;
                            $_SESSION['userType'] = $res['user_type'];
                            $_SESSION['client_name'] = $res['employee_name'];
                            $presentCheck = true;
                           //log in successful;
                        }
                    }
                    if($presentCheck){  //user found, redirect to ticket creation
                        redirect('createticket.php');
                    }
                }

                if(!$presentCheck){     //user not found
                    redirect('login.php?attempt=failed');
                }  
}
else{   //no username entered, return to login page
   redirect('login.php');
} 
?>

