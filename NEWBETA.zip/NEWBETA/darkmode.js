function myFunction(){
		
var bgBox=document.getElementById("bg");

  // Get checkbox
 var checkboxContainer = document.getElementById("myContainer");
  // Get checkbox
  var formCheckbox = document.querySelector(".myCheckbox");

if (formCheckbox.checked == true){ 
    checkboxContainer.classList.add('checked');
    bgBox.style="background-color:#10171e;";
  }

else{
    bgBox.style="background-color:white;";
    checkboxContainer.classList.remove("checked");
  }
}
