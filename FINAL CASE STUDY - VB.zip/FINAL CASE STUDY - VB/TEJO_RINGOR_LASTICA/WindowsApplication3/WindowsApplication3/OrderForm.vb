﻿Imports System.Data.OleDb
Public Class OrderForm
    Dim conn As OleDb.OleDbConnection
    Dim da As OleDb.OleDbDataAdapter
    Dim dt As DataTable
    Dim cmd As OleDbCommand
    Dim index As Integer
    Dim prevValue As Single = 0
    Dim currentStocks As Integer
    Dim dbdata As OleDbDataReader
    Dim provider As String
    Dim datafile As String
    Dim connstring As String
    Dim myConnection As OleDbConnection = New OleDbConnection
    
    ReadOnly CONNECTION_STRING As String = "Provider=microsoft.Jet.oledb.4.0; Data Source=" & _
                                    Application.StartupPath.Replace("\bin\Debug", String.Empty) & _
                                    "\Database2.mdb;"



    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database2DataSet11.FoodTable' table. You can move, or remove it, as needed.
       
        Me.FoodTableTableAdapter.Fill(Me.Database2DataSet11.FoodTable)
        DataGridView1.Columns.Add("Food Type", "Food Type")
        DataGridView1.Columns.Add("Food Name", "Food Name")
        DataGridView1.Columns.Add("Quantity", "Quantity")
        DataGridView1.Columns.Add("Price", "Price")
        DataGridView1.Columns.Add("Amount", "Amount")

        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView1.Columns(0).Width = 160
        DataGridView1.Columns(1).Width = 210
        Timer1.Enabled = True

        TextBox7.Select()
        
        transactID()
        Me.WindowState = FormWindowState.Maximized
  
    End Sub
    Private Sub transactID()
        Dim cmmd As OleDb.OleDbCommand
        Dim CN As New OleDb.OleDbConnection(CONNECTION_STRING)

        CN.Open()
        cmmd = New OleDb.OleDbCommand("select * from OrderDatabase", CN)
        cmmd.Connection = CN
        Dim maxid As Object
        Dim strid As String
        Dim intid As Integer

        cmmd.CommandText = "Select Max(ID) as MaxID from OrderDatabase"

        maxid = cmmd.ExecuteScalar

        If maxid Is DBNull.Value Then
            intid = 1
        Else
            strid = CType(maxid, String)
            intid = CType(maxid, String)
            intid = intid + 1
        End If
        TextBox8.Text = "1000" & intid
        CN.Close()

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim dt As New DataTable

        dt.Columns.Add("Food Type")
        dt.Columns.Add("Food Name")
        dt.Columns.Add("Quantity")
        dt.Columns.Add("Price")
        dt.Columns.Add("Amount")



        Form3.Show()

        For Each dr As DataGridViewRow In DataGridView1.Rows
            dt.Rows.Add(dr.Cells("Food Type").Value, dr.Cells("Food Name").Value, dr.Cells("Quantity").Value, dr.Cells("Price").Value, dr.Cells("Amount").Value)
        Next

        Dim rptDoc As CrystalDecisions.CrystalReports.Engine.ReportDocument

        rptDoc = New CrystalReport1
        rptDoc.SetDataSource(dt)

        Form3.CrystalReportViewer1.ReportSource = rptDoc


    End Sub



    Public Sub saveOrder()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        conn.Open()
        cmd = New OleDbCommand
        cmd.Connection = conn
        cmd.CommandText = "INSERT INTO [OrderDatabase]([TransactionID], [CustomersName], [TotalAmount], [TotalItems], [TypeOfOrder], [VatAmount], [Money], [Change], [Date], [Time]) VALUES('testTransactID', '" & TextBox7.Text & "', '" & TextBox4.Text & "', '" & TextBox11.Text & "','" & ComboBox3.Text & "','" & TextBox9.Text & "', '" & TextBox1.Text & "', '" & TextBox6.Text & "', '" & Label13.Text & "', '" & Label14.Text & "')"

        cmd.ExecuteNonQuery()
        conn.Close()
    End Sub


    Private Sub Button4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim sum As Integer
        Dim count As Integer

        If TextBox7.Text = "" Then
            MessageBox.Show("Please Enter your Customer's Name")
        ElseIf ComboBox1.Text = "" Then
            MessageBox.Show("Please Choose your Category")
        ElseIf ComboBox2.Text = "" Then
            MessageBox.Show("Please Choose your Food Name")
        ElseIf NumericUpDown1.Value = 0 Then
            MessageBox.Show("Please Enter your Quantity")
        Else

            MsgBox("You added " & NumericUpDown1.Value & " " & ComboBox2.Text & " at your order.")
            updatebutton()
            Me.DataGridView1.Rows.Add(ComboBox1.SelectedItem, ComboBox2.SelectedItem, NumericUpDown1.Value, TextBox2.Text, TextBox3.Text)



            ' TextBox4.Text = Val(TextBox3.Text) + Val(TextBox4.Text)
            ' TextBox11.Text = Val(NumericUpDown1.Value) + Val(TextBox11.Text)
            ' TextBox9.Text = Val(TextBox4.Text) * Val(0.12)
            For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
                sum = sum + DataGridView1.Rows(i).Cells(2).Value
            Next
            TextBox11.Text = sum.ToString()

            For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
                count = count + DataGridView1.Rows(i).Cells(4).Value
            Next
            TextBox4.Text = count.ToString()

            TextBox9.Text = Val(TextBox4.Text) * Val(0.12)

        End If

    End Sub
    Public Sub updatebutton()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        conn.Open()
        cmd = New OleDbCommand
        cmd.Connection = conn
      
        cmd.CommandText = "UPDATE [Table1] SET [Stocks] = '" & TextBox5.Text & "' WHERE [Food_Type] ='" & ComboBox1.Text & "'and [Food_Name]= '" & ComboBox2.Text & "'"

        cmd.ExecuteNonQuery()
        conn.Close()
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If NumericUpDown1.Value = "" Or TextBox3.Text = "" Then
            MessageBox.Show("PLEASE ENTER COMPLETE DATA....", "DATA ENTRY", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            Button2.Enabled = False
            NumericUpDown1.Enabled = True
            TextBox2.Enabled = True
            TextBox3.Enabled = True
            ComboBox1.Enabled = True
            ComboBox2.Enabled = True

        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub

    Private Sub Table1BindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Table1BindingNavigatorSaveItem.Click
        Me.Validate()
        Me.Table1BindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database2DataSet)
    End Sub

    Private Sub Button2_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        ComboBox1.Enabled = True
        ComboBox2.Enabled = True
        NumericUpDown1.Enabled = True
        TextBox2.Enabled = True
        TextBox3.Enabled = True
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        NumericUpDown1.Value = 0
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox5.Text = ""
        PictureBox8.Image = Nothing
        Table1BindingSource.AddNew()
        NumericUpDown1.Maximum = 100

        
    End Sub

    Private Sub NumericUpDown1_ValueChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged
        QtyChanged()
        QtyChanged()
        If TextBox5.Text = 0 Then
            NumericUpDown1.Maximum = NumericUpDown1.Value.ToString
            Return
        End If
        If NumericUpDown1.Maximum = NumericUpDown1.Value.ToString Then
            TextBox5.Text = 0
            Return
        End If

    End Sub
    Private Sub NumericUpDown1_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles NumericUpDown1.KeyUp
        QtyChanged()
    End Sub

    Private Sub QtyChanged()
        TextBox3.Text = Val(TextBox2.Text) * Val(NumericUpDown1.Value)
        TextBox5.Text = currentStocks - Val(NumericUpDown1.Value)
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        End
    End Sub

    '  Private Sub Button5_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

    'If MessageBox.Show("Are you sure you want to delete this item?", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = Windows.Forms.DialogResult.Yes Then


    'Dim Amount As Integer
    'Dim Items As Integer
    '    index = DataGridView1.CurrentCell.RowIndex()
    '     DataGridView1.Rows.RemoveAt(index)
    '      For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
    '           Amount = Amount + DataGridView1.Rows(i).Cells(4).Value
    '            TextBox4.Text = Amount.ToString()

    '    Next

    '        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
    '           Items = Items + DataGridView1.Rows(i).Cells(2).Value
    '          TextBox11.Text = Items.ToString()
    '         TextBox9.Text = Val(TextBox4.Text) * Val(0.12)

    '      Next
    '   End If

    'End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Table1BindingSource.MovePrevious()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click



        If MessageBox.Show("Are you sure that is all your Order?", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = Windows.Forms.DialogResult.Yes Then
            PictureBox8.Image = Nothing
            ComboBox1.Enabled = False
            ComboBox2.Enabled = False
            NumericUpDown1.Value = 0
            TextBox2.Enabled = False
            TextBox3.Enabled = False
            TextBox5.Enabled = False


            TextBox4.Enabled = True
            TextBox9.Enabled = True
            TextBox11.Enabled = True
            TextBox6.Enabled = True
            TextBox1.Enabled = True
            ComboBox3.Enabled = True
            Button8.Enabled = True

            Dim conn As New OleDbConnection(CONNECTION_STRING)

            conn.Open()
            Dim cmd As New OleDbCommand
            cmd.CommandText = "select * from Table1 WHERE Food_Name='" & ComboBox2.Text & "'"

            cmd.Connection = conn
            dbdata = cmd.ExecuteReader

            While dbdata.Read

                TextBox5.Text = (dbdata("Stocks"))


            End While

            Return

        End If



    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Dim int As Double = Val(TextBox1.Text)
        Dim dt As New DataTable

        If Val(TextBox4.Text) > int Then
            MsgBox("Insuficient Money!")
            Return 'Return na if insufficient money para di n tumuloy sa codes sa baba
        ElseIf TextBox1.Text = "" Then
            MsgBox("Enter your Exact amount")
        Else
            TextBox6.Text = int - Val(TextBox4.Text)
            MsgBox("Your Change is " & TextBox6.Text)
            Form3.Show()
            saveOrder()
            updatebutton()

        End If


        dt.Columns.Add("Food Type")
        dt.Columns.Add("Food Name")
        dt.Columns.Add("Quantity")
        dt.Columns.Add("Price")
        dt.Columns.Add("Amount")
        dt.Columns.Add("Money")
        dt.Columns.Add("Change")



        For Each dr As DataGridViewRow In DataGridView1.Rows
            dt.Rows.Add(dr.Cells("Food Type").Value, dr.Cells("Food Name").Value, dr.Cells("Quantity").Value, dr.Cells("Price").Value, dr.Cells("Amount").Value)
        Next

        Dim rptDoc As CrystalDecisions.CrystalReports.Engine.ReportDocument

        rptDoc = New CrystalReport1
        rptDoc.SetDataSource(dt)

        Form3.CrystalReportViewer1.ReportSource = rptDoc


        'TextBox8.Text = Val(TextBox7.Text) + 1


        Me.Controls.Clear() 'removes all the controls on the form
        InitializeComponent() 'load all the controls again
        Form2_Load(e, e)
    End Sub

    Private Sub ComboBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboBox1.KeyPress
        e.Handled = True

    End Sub


    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

        If ComboBox1.SelectedIndex = 0 Then

            ComboBox2.Items.Clear()
            ComboBox2.Items.Add("Strawberry Shake")
            ComboBox2.Items.Add("Choco Shake")
            ComboBox2.Items.Add("Kitkat Mix-ins")
            ComboBox2.Items.Add("Strawberry Sundae")
            ComboBox2.Items.Add("Chocolate Sundae")
            ComboBox2.Items.Add("Coke Float")
            ComboBox2.Items.Add("Cone Twirl Krunchy Chocolate")
            ComboBox2.Items.Add("Cone Twirl Vanilla")

        End If

        If ComboBox1.SelectedIndex = 1 Then


            ComboBox2.Items.Clear()
            ComboBox2.Items.Add("Breakfast Joys Corned Beef")
            ComboBox2.Items.Add("Breakfast Joys Beef Tapa")
            ComboBox2.Items.Add("Breakfast Joys Breakfast Steak")
            ComboBox2.Items.Add("Breakfast Joys Hotdog")
            ComboBox2.Items.Add("Breakfast Joys Longganisa")
            ComboBox2.Items.Add("Breakfast Joys Pancakes")

        End If


        If ComboBox1.SelectedIndex = 2 Then


            ComboBox2.Items.Clear()
            ComboBox2.Items.Add("Yum with TLC Sesame Seed")
            ComboBox2.Items.Add("Cheesy Bacon Mushroom Yum")
            ComboBox2.Items.Add("Cheesy Bacon Mushroom Champ")
            ComboBox2.Items.Add("Champ Pound Beef Patty")
            ComboBox2.Items.Add("Yum with Cheese")
            ComboBox2.Items.Add("Yum")

        End If


        If ComboBox1.SelectedIndex = 3 Then

            ComboBox2.Items.Clear()
            ComboBox2.Items.Add("2 pcs Chicken")
            ComboBox2.Items.Add("1 pc Chicken")
            ComboBox2.Items.Add("Spicy Chickenjoy")
            ComboBox2.Items.Add("6 pcs Chickenjoy Bucket")
            ComboBox2.Items.Add("8 pcs Chickenjoy Bucket")

        End If

        If ComboBox1.SelectedIndex = 4 Then
            ComboBox2.Items.Clear()
            ComboBox2.Items.Add("Spaghetti")
            ComboBox2.Items.Add("Palabok Fiesta")

        End If


        If ComboBox1.SelectedIndex = 5 Then


            ComboBox2.Items.Clear()
            ComboBox2.Items.Add("Garlic Pepper Beef")
            ComboBox2.Items.Add("Ultimate Burger Steak")
            ComboBox2.Items.Add("All Day Garlic Bangus")
            ComboBox2.Items.Add("Burger Steak")
            ComboBox2.Items.Add("5 pcs Shanghai Rolls")

        End If

        If ComboBox1.SelectedIndex = 6 Then


            ComboBox2.Items.Clear()
            ComboBox2.Items.Add("Buttered Corn")
            ComboBox2.Items.Add("Peach Mango Pie")
            ComboBox2.Items.Add("Creamy Macaroni Soup")
            ComboBox2.Items.Add("Jolly Crispy Fries")

        End If

    End Sub

    Private Sub ComboBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ComboBox2.KeyPress
        e.Handled = True

    End Sub



    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        TextBox10.Text = ComboBox2.SelectedItem
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        conn.Open()
        Dim cmd As New OleDbCommand
        cmd.CommandText = "select * from Table1 WHERE Food_Name='" & ComboBox2.Text & "'"
        cmd.Connection = conn
        dbdata = cmd.ExecuteReader

        If ComboBox2.SelectedItem = "Strawberry Shake" Then
            TextBox2.Text = "42"
            PictureBox8.Image = My.Resources.CREAMYSHAKE_Strawberry_res
            QtyChanged()

            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While
        ElseIf ComboBox2.SelectedItem = "Choco Shake" Then
            TextBox2.Text = "42"
            PictureBox8.Image = My.Resources.CREAMY_SHAKE_Chocolate_res
            QtyChanged()

            While dbdata.Read

                TextBox5.Text = (dbdata("Stocks"))


            End While

        ElseIf ComboBox2.SelectedItem = "Kitkat Mix-ins" Then
            TextBox2.Text = "42"
            PictureBox8.Image = My.Resources.kisses_mixins_kitkat
            QtyChanged()

            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Strawberry Sundae" Then
            TextBox2.Text = "28"
            PictureBox8.Image = My.Resources.Strawberry_sundae_thumb
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Chocolate Sundae" Then
            TextBox2.Text = "28"
            PictureBox8.Image = My.Resources.Choco_Sundae_thumb
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Coke Float" Then
            TextBox2.Text = "27"
            PictureBox8.Image = My.Resources.coke_float_thumb
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Cone Twirl Krunchy Chocolate" Then
            TextBox2.Text = "18"
            PictureBox8.Image = My.Resources.choco_cone_twirl_image
            QtyChanged()
            TextBox10.Font = New Font("Century Gothic", 13)

            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While


        ElseIf ComboBox2.SelectedItem = "Cone Twirl Vanilla" Then
            TextBox2.Text = "13"
            PictureBox8.Image = My.Resources.vanilla_cone_twirl_image
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        End If



        If ComboBox2.SelectedItem = "Breakfast Joys Corned Beef" Then
            TextBox2.Text = "90"
            PictureBox8.Image = My.Resources._1CornedBeef
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Breakfast Joys Beef Tapa" Then
            TextBox2.Text = "90"
            PictureBox8.Image = My.Resources._2BeefTapa
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Breakfast Joys Breakfast Steak" Then
            TextBox2.Text = "60"
            PictureBox8.Image = My.Resources._3BreakfastSteak
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While


        ElseIf ComboBox2.SelectedItem = "Breakfast Joys Hotdog" Then
            TextBox2.Text = "60"
            PictureBox8.Image = My.Resources._4Hotdog
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While


        ElseIf ComboBox2.SelectedItem = "Breakfast Joys Longganisa" Then
            TextBox2.Text = "90"
            PictureBox8.Image = My.Resources._5Longganisa
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While


        ElseIf ComboBox2.SelectedItem = "Breakfast Joys Pancakes" Then
            TextBox2.Text = "48"
            PictureBox8.Image = My.Resources._6Pancakes
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While


        End If


        If ComboBox2.SelectedItem = "Yum with TLC Sesame Seed" Then
            TextBox2.Text = "62"
            PictureBox8.Image = My.Resources._1YumwithTLCSesameSeed
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Cheesy Bacon Mushroom Yum" Then
            TextBox2.Text = "72"
            PictureBox8.Image = My.Resources._2CheesyBaconMushroomYum
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Cheesy Bacon Mushroom Champ" Then
            TextBox2.Text = "138"
            PictureBox8.Image = My.Resources._3CheesyBaconMushroomChamp
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While
            TextBox5.Font = New Font("Century Gothic", 13)

        ElseIf ComboBox2.SelectedItem = "Champ Pound Beef Patty" Then
            TextBox2.Text = "128"
            PictureBox8.Image = My.Resources._4ChampPoundBeefPatty
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Yum with Cheese" Then
            TextBox2.Text = "40"
            PictureBox8.Image = My.Resources._5YumwithCheese
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Yum" Then
            TextBox2.Text = "30"
            PictureBox8.Image = My.Resources._6Yum
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        End If


        If ComboBox2.SelectedItem = "2 pcs Chicken" Then
            TextBox2.Text = "142"
            PictureBox8.Image = My.Resources._1twopcsChicken
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While


        ElseIf ComboBox2.SelectedItem = "1 pc Chicken" Then
            TextBox2.Text = "82"
            PictureBox8.Image = My.Resources._2onepcChickenjoy
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While


        ElseIf ComboBox2.SelectedItem = "Spicy Chickenjoy" Then
            TextBox2.Text = "82"
            PictureBox8.Image = My.Resources._3spicychickenjoy
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While


        ElseIf ComboBox2.SelectedItem = "6 pcs Chickenjoy Bucket" Then
            TextBox2.Text = "355"
            PictureBox8.Image = My.Resources._4ChickenjoyBucket
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While


        ElseIf ComboBox2.SelectedItem = "8 pcs Chickenjoy Bucket" Then
            TextBox2.Text = "469"
            PictureBox8.Image = My.Resources._4ChickenjoyBucket
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While


        End If

        If ComboBox2.SelectedItem = "Spaghetti" Then
            TextBox2.Text = "50"
            PictureBox8.Image = My.Resources.spaghetti_image
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Palabok Fiesta" Then
            TextBox2.Text = "85"
            PictureBox8.Image = My.Resources.palabok_image
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        End If


        If ComboBox2.SelectedItem = "Garlic Pepper Beef" Then
            TextBox2.Text = "55"
            PictureBox8.Image = My.Resources._1Garlic_Pepper_Beef
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Ultimate Burger Steak" Then
            TextBox2.Text = "125"
            PictureBox8.Image = My.Resources._2UltimateBurgerSteak
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "All Day Garlic Bangus" Then
            TextBox2.Text = "55"
            PictureBox8.Image = My.Resources._3AllDayGarlicBangus
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Burger Steak" Then
            TextBox2.Text = "50"
            PictureBox8.Image = My.Resources._4BurgerSteak
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "5 pcs Shanghai Rolls" Then
            TextBox2.Text = "50"
            PictureBox8.Image = My.Resources._5fivepcsShanghaiRolls
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        End If


        If ComboBox2.SelectedItem = "Buttered Corn" Then
            TextBox2.Text = "29"
            PictureBox8.Image = My.Resources._1ButteredCorn
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Peach Mango Pie" Then
            TextBox2.Text = "27"
            PictureBox8.Image = My.Resources._2PeachMangoPIe
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Creamy Macaroni Soup" Then
            TextBox2.Text = "39"
            PictureBox8.Image = My.Resources.macaroni_soup_image
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While

        ElseIf ComboBox2.SelectedItem = "Jolly Crispy Fries" Then
            TextBox2.Text = "32"
            PictureBox8.Image = My.Resources._4JollyCrispyFries
            QtyChanged()
            While dbdata.Read
                TextBox5.Text = (dbdata("Stocks"))
            End While


        End If
        dbdata.Close()

        currentStocks = Val(TextBox5.Text)

    End Sub



    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label13.Text = Date.Now.ToString("MMMM dd, yyyy")
        Label14.Text = Date.Now.ToString("hh:mm:ss: tt")

    End Sub

    Private Sub Button1_Click_3(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TransactionForm.Show()
        Me.Hide()
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        NumericUpDown1.Value = 0
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox5.Text = ""
        TextBox7.Text = ""

        TextBox4.Text = ""
        TextBox9.Text = ""
        TextBox11.Text = ""
        TextBox6.Text = ""
        TextBox1.Text = ""
        ComboBox3.Text = ""
        PictureBox8.Image = Nothing

    End Sub


    ' Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
    '    If MessageBox.Show("Do you want to cancel your order?", "System Ask", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = Windows.Forms.DialogResult.Yes Then

    'TextBox2.Text = ""
    ' ComboBox1.Text = ""
    '  ComboBox2.Text = ""
    '   NumericUpDown1.Value = 0
    '    TextBox3.Text = ""
    '     TextBox5.Text = ""
    '      TextBox4.Text = ""
    '       PictureBox8.Image = Nothing
    '        Me.DataGridView1.Rows.Clear()

    '   TextBox2.Text = ""
    '    TextBox1.Text = ""
    '     TextBox6.Text = ""
    '      TextBox11.Text = ""
    '       TextBox9.Text = ""
    '        ComboBox3.Text = ""


    '   End If


    'End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        index = e.RowIndex
        If (e.RowIndex = -1) Then
            Return
        End If
        Dim selectedRow As DataGridViewRow

        selectedRow = DataGridView1.Rows(index)

        ComboBox1.Text = selectedRow.Cells(0).Value.ToString()
        ComboBox2.Text = selectedRow.Cells(1).Value.ToString()
        NumericUpDown1.Value = selectedRow.Cells(2).Value.ToString()
        TextBox2.Text = selectedRow.Cells(3).Value.ToString()
        TextBox3.Text = selectedRow.Cells(4).Value.ToString()

    End Sub

    Private Sub TextBox5_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox5.KeyPress
        e.Handled = True

    End Sub

    Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox5.TextChanged
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        TextBox5.Text += Val(NumericUpDown1.Value)
        TextBox5.Text = Val(TextBox5.Text) + Val(NumericUpDown1.Value) - 2
        updatebutton()
    End Sub

    Private Sub TextBox7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress
        e.Handled = True
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub Label10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label10.Click

    End Sub

    Private Sub Label12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label12.Click

    End Sub

    Private Sub Label11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label11.Click

    End Sub

    Private Sub Label16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label16.Click

    End Sub

    Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged

    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress

    End Sub

    Private Sub TextBox2_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox2.KeyUp

    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label15.Click

    End Sub

    Private Sub PictureBox5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox5.Click

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub TextBox10_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox10.KeyDown

    End Sub

    Private Sub TextBox10_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox10.KeyPress
        e.Handled = True

    End Sub

    Private Sub TextBox10_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox10.TextChanged

    End Sub

    Private Sub PictureBox8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox8.Click

    End Sub

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim sum As Integer
        Dim count As Integer

        DataGridView1(DataGridView1.Columns(2).Index, DataGridView1.CurrentCell.RowIndex).Value = NumericUpDown1.Value
        DataGridView1(DataGridView1.Columns(4).Index, DataGridView1.CurrentCell.RowIndex).Value = TextBox3.Text

        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(2).Value
        Next
        TextBox11.Text = sum.ToString()

        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            count = count + DataGridView1.Rows(i).Cells(4).Value
        Next
        TextBox4.Text = count.ToString()

        TextBox9.Text = Val(TextBox4.Text) * Val(0.12)

    End Sub
End Class



