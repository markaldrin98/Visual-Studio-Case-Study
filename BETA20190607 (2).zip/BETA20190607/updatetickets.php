<?php
include_once("misc/config.php");  
echo "<br><br><br><br><br><br><br><br>";  
    if(checkPost("ticket_id")!=false){//checks to see if 'ticket_id' has been posted - if it is not set, then the user accessed this page through unintended channels
    }
    else{
        redirect('index.php');//and should thus be redirected back to the index
    }
    global $conn;
    $qString ='SELECT * FROM tickets WHERE ticket_id="'.checkPost("ticket_id").'"';//retrieves ticket with the same id as the id posted
    $result = mysqli_query($conn,$qString);
    $res = mysqli_fetch_array($result);

        $queryString = "UPDATE tickets SET ticket_id='".checkPost("ticket_id")."'";
        $fieldArray = retrieveFields('tickets');
        for($counter=0;$counter<count($fieldArray);$counter++){
            if(checkPost($fieldArray[$counter])!=false){
                toConsole($fieldArray[$counter]);
                toConsole(checkPost($fieldArray[$counter]));
                if(checkPost($fieldArray[$counter])!=$res[$fieldArray[$counter]]){
                    if($fieldArray[$counter]=='remarks'){//checks to see if program's currently iterating through the 'remarks' colum
                        $oldRemark = mysqli_real_escape_string ($conn,$res['remarks']);//escapes stored chat log
                        $currentUser = mysqli_real_escape_string ($conn,callUser());
                        $newRemark = checkPost($fieldArray[$counter]);//formats new remark
                        $newRemark = mysqli_real_escape_string ($conn,$newRemark);//escapes new remark

                        if($oldRemark==''){//code block determines if chat log is empty - if it is, insert a new remark - if it isn't, add new remark to old remark string
                            $queryString.=", ".$fieldArray[$counter]."= CONCAT('".$currentUser."<',now(),'>:".$newRemark."-:-"."')";
                        }
                        else{
                            $queryString.=", ".$fieldArray[$counter]."= CONCAT('".$oldRemark."','".$currentUser."<',now(),'>:".$newRemark."-:-"."')";                
                        }
                    }
                    else{                        
                        $queryString.=", ".$fieldArray[$counter]."='".escapeString(checkPost($fieldArray[$counter]))."'";
                    }
                //log change here
                }
            }
        }
        $queryString.= " WHERE ticket_id='".checkPost("ticket_id")."'";
        if(mysqli_query($conn,$queryString)){//ticket updated, return to outstanding.php
            toConsole("Update success!");
            var_dump($queryString);
            redirect('outstanding.php');
        }
        else{
            toConsole("Update failure!");
            var_dump($queryString);
            checkSQLError();
        }
        /*  OLD CODE BLOCK FOR UPDATING VALUES IN 'tickets'
            while($res = mysqli_fetch_array($result)){ //iterates through all tickets that are either not approved or not completed
                if(isset($_POST["officeSelect".$res['ticket_id']])){//for changing the value of the office field   
                    $stringIQ = 'office';
                    $outStatus = $_POST['officeSelect'.$res['ticket_id']];
                    prepareUpdate($res['ticket_id'], $stringIQ, $res[$stringIQ], $outStatus);     
                }
                //made below function easier to modify
                if(isset($_POST["client_nameSelect".$res['ticket_id']])){//for changing the value of the client_name field   
                    $stringIQ = 'client_name';
                    $outStatus = $_POST['client_nameSelect'.$res['ticket_id']];
                    prepareUpdate($res['ticket_id'], $stringIQ, $res[$stringIQ], $outStatus);     
                }

                if(isset($_POST["employee_numberSelect".$res['ticket_id']])){//for changing the value of the employee_number field   
                    $stringIQ = 'employee_number';
                    $outStatus = $_POST['employee_numberSelect'.$res['ticket_id']];
                    prepareUpdate($res['ticket_id'], $stringIQ, $res[$stringIQ], $outStatus);     
                }

                if(isset($_POST["job_descriptionSelect".$res['ticket_id']])){//for changing the value of the job_description field   
                    $stringIQ = 'job_description';
                    $outStatus = $_POST['job_descriptionSelect'.$res['ticket_id']];
                    prepareUpdate($res['ticket_id'], $stringIQ, $res[$stringIQ], $outStatus);                 
                }

                if(isset($_POST["participationSelect".$res['ticket_id']])){//for changing the value of the participation field   
                    $stringIQ = 'participation';
                    $outStatus = $_POST['participationSelect'.$res['ticket_id']];
                    prepareUpdate($res['ticket_id'], $stringIQ, $res[$stringIQ], $outStatus);     
                }

                if(isset($_POST["approval_statusSelect".$res['ticket_id']])){//for changing the value of the approval_status field   
                    $stringIQ = 'approval_status';
                    $outStatus = $_POST['approval_statusSelect'.$res['ticket_id']];
                    prepareUpdate($res['ticket_id'], $stringIQ, $res[$stringIQ], $outStatus);     
                }

                if(isset($_POST["respondentSelect".$res['ticket_id']])){//for changing the value of the respondent field   
                    $stringIQ = 'respondent';
                    $outStatus = $_POST['respondentSelect'.$res['ticket_id']];
                    prepareUpdate($res['ticket_id'], $stringIQ, $res[$stringIQ], $outStatus);     
                }

                if(isset($_POST["jobStatusSelect".$res['ticket_id']])){//for changing the value of the job_status field   
                    $stringIQ = 'job_status';
                    $outStatus = $_POST['jobStatusSelect'.$res['ticket_id']];
                    prepareUpdate($res['ticket_id'], $stringIQ, $res[$stringIQ], $outStatus);     
                }

                if(isset($_POST["remarksSelect".$res['ticket_id']])){//for changing the value of the remarks field   
                    $stringIQ = 'remarks';
                    $outStatus = htmlspecialchars($_POST['remarksSelect'.$res['ticket_id']]);
                    prepareUpdate($res['ticket_id'], $stringIQ, $res[$stringIQ], $outStatus);     
                }
                
            }
                */
    //redirect('outstanding.php');

?>

