﻿Imports System.Data.OleDb

Public Class Form4

    Dim conn As OleDbConnection
    Dim cmd As OleDbCommand
    Dim reader As OleDbDataReader
    Public bal As Double

    Private Sub Form4_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" &
               Application.StartupPath & "\dbCustomerAcct.mdb")

        conn.Open()
        cmd = New OleDbCommand()
        cmd.Connection = conn
        cmd.CommandText = "Select * From tblCustomerInfo where pinnum = '" & Form2.pinnum & "'"

        reader = cmd.ExecuteReader()

        While (reader.Read())
            Label3.Text = reader("acctnum").ToString()
            Label5.Text = reader("custname").ToString()
            Label7.Text = reader("balance").ToString()

        End While

        bal = Double.Parse(Label7.Text)
        Label7.Text = bal.ToString("0,0.00")
        conn.Close()
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        Me.Close()
        Form3.Show()

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        Me.Close()
        Form8.Show()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Me.Close()
        Form1.Show()
    End Sub
End Class