<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>  
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/viewdevice.css">
</head>

<body style="color:black">
<div class="container">
   
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO SET/GET DEVICE INFORMATION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<div class="lineBorder"> <!-- Start of Borderline for Device Details -->
<div class="ticket">
<?php
$device_id=checkGet  ('device_id');
if(!$device_id){  //device is not set
  redirect('devicemanagement.php');
}

?>

<div id="device_info_container">
  <fieldset id="device_details">
    <div class="card">
      <center>
        <br>
        <legend class='headerStyle'><?php echo 'Device '.$device_id?></legend></center>
        <div class="card-body">
          <?php
            $deviceDetails = retrieveDetails($device_id);
          ?>  
          <form id="editDeviceDetails" method="post" action="updatedevice.php">
          <?php createHiddenInput('device_id',$device_id);?>
          <div class="form-group">
              <label>Device Type</label>
              <span id="device_details" name="device_details" class="form-control"><?php echo $deviceDetails['device_type'];?></span>
              <?php
                  /*$valueArray = retrieveOptions('device_type',true);
                  outputSelect('device_type',$deviceDetails['device_type'],$valueArray,true);*/
                ?>                          
          </div>
          <div class="form-group">
              <label>Device Owner</label>
              <?php
                echo "<input type='text' class='form-control' name='owner' id='owner' placeholder='Owner' required value=".$deviceDetails['owner']." required>";
              ?>
          </div>
          <div class="form-group">
              <label>Office</label>
              <?php
                $valueArray = retrieveOptions('office',true);
                outputSelect('office',$deviceDetails['office'],$valueArray,true);
              ?>
          </div>
          <input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Update Details">
          </form>
        </div>
    </div>
  </fieldset>
  <br>
  <fieldset id="device_parts">
    <div class="card">
      <div class="card-header cardStyleHeader">Device Parts</div>
        <div class="card-body">
        
      <?php
        printArray(retrieveParts($device_id));
      ?>
      <li>Add New Part
        <form action="newpartspec.php" method="post"><!--form to add new spec to device-->
          <div class="form-group">
            <?php createHiddenInput('device_id',$device_id);?>
            <?php createHiddenInput('trail',basename($_SERVER['PHP_SELF']));?>
            <input class="form-control" type="text" id="new_part" name="new_value" placeholder="New Part..." required>
            <br>        
            <input type="text" class="form-control" name="new_detail" placeholder="New Details..." required>
            <br>
            <input class="btn btn-default buttonStyle"  type="submit" name="Submit" value="Add Part">
          </div>
        </form>
      </li>
      
      </div>
    </div>
  </fieldset>
  
  <fieldset id="device_specs">
    <div class="card">
      <div class="card-header cardStyleHeader">Device Specifications</div>
        <div class="card-body">
          <?php
            printArray(retrieveSpecs($device_id));
          ?>
          <form action="newpartspec.php" method="post"><!--form to add new spec to device-->
            <div class="form-group">
              <?php createHiddenInput('device_id',$device_id);?>
              <?php createHiddenInput('trail',basename($_SERVER['PHP_SELF']));?>
              <input type="text" class="form-control" id="new_spec" name="new_value" placeholder="New Specification...">
              <br>
              <input type="text" name="new_detail" class="form-control" placeholder="New Details...">
              <br>
              <input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Add Specificaton">
            </div>
          </form>
        </div>
    </div>
  </fieldset>
</div>

</div>
</div> <!-- End of Borderline for Device Details -->
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF FORM USED TO SET/GET DEVICE INFORMATION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

</div>


<br>
<br>
<br>
<br>

</body>
</html>

<!--css-->
<style>
 
body{
    background-color: #384048;
  }
</style>

<script>

</script>