<?php include 'misc/config.php';?>
<?php
if(checkPost('Submit')) {//checks if device_id is set
    $operation = checkPost('Submit');
    $target = '';
    $field = '';
    $type = '';
    $device_id = checkPost('device_id');
    $value = checkPost('new_value');
    $details = checkPost('new_detail');
    $redirect = checkPost('trail');
    toConsole($redirect);
    toConsole($operation);

    if($operation == 'Add Part'){
        $target = 'device_parts_table';
        $type = 'Part'
    }
    else if($operation == 'Add Specification'){
        $target = 'device_specs_table';
        $type = 'Specification';
    }
    $insertQuery = "INSERT INTO ".$target." VALUES('$device_id','$value','$details')";
    echo $insertQuery;
    echo "<br><br><br><br><br>";
    if(mysqli_query($conn, $insertQuery)) {
        echo "Query successful";
        if($redirect){
            toConsole("Redirecting to : ".$redirect);
            $logString = "Registered new ".$type.": ".$value." - ".$details;
            logDeviceChange(callUser(),$device_id,$logString);
            redirect($redirect."?device_id=".$device_id);
        }
    } 
    else{
        echo "Query failure";
    }
}
else{
    redirect('index.php');
}
                  
?>

