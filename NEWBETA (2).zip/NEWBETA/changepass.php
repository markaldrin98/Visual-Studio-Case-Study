<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/loginstyle.css">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
</head>

  <?php

//echo $_SESSION['loggedin'];
    if(isset($_GET['op']) && $_GET['op'] == 'add'){
      echo "<h1>Registration successful! <br>Welcome, ".$_SESSION['username']."</h1>";
    }
    else if(isset($_GET['op']) && $_GET['op'] == 'login'){
      echo "<h1>Welcome, ".$_SESSION['username']."</h1>";
    }

    else{
      echo "
<form class='login100-form validate-form' action='checkcredentials.php' method='post'>
    <div class='limiter'>
        <div class='container-login100'>
            <div class='wrap-login100'>
                <div class='form-wrapper'>
                    <span class='login100-form-title p-b-48'>
                  <div class='container'>
                    <center>
                        <img src='img/taoanguna.png' style='width: 70%;'> 
                    </center> 
                  </div>
                    </span>
                    <span class='login100-form-title p-b-48'>
                    Change Password
                    </span>     
       
        <div class='field'>
            <input type='text' required autocomplete='off' id='username' required name='username' class='form-control' disabled>

            <label for='username' title='".$_SESSION['client_name']."' data-title='".$_SESSION['client_name']."'></label>
        </div>        


        <div class='field'>
            <input type='Password' id='oldpass' required name='oldpass' class='form-control'>
            <label for='oldpass' title='Enter your Old Password' data-title='Old Password'></label>
        </div>
        <div class='field'>
            <input type='Password' id='newpass' required name='newpass' class='form-control' onkeyup='check();'>
            <label for='newpass' title='Enter your New Password' data-title='New Password'></label>
        </div>
        
        <div class='field'>
            <input type='Password' id='confirmnewpass' required name='confirmnewpass' class='form-control' onkeyup='check();'>
            <label for='confirmnewpass' title='Confirm your New Password' data-title='Confirm New Password'></label>
            <span id='message'></span>
        </div>
  <div class='container-login100-form-btn'>
                      <div class='wrap-login100-form-btn'>             
                          <input type='submit' value='Update' name='Submit' id='Submit' class='login100-form-btn'>
                      </div>
                      </form>
                  <form action='index.php' method='post'>
                      <div class='wrap-login100-form-btn'>             
                          <input type='submit' value='Back' name='Submit' id='Submit' class='login100-form-btn'>
                      </div>
                  </form>
                  </div>
              
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>\
</div>

";
    }
  ?>
</div>
</center>

</body>
</html>
<script>
  var check = function() {
  if (document.getElementById('newpass').value ==
    document.getElementById('confirmnewpass').value && document.getElementById('newpass').value.length > 4) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = ' Matching';
    document.getElementById('Submit').disabled = false;
  } else {
    if(document.getElementById('newpass').value.length <= 4){
      document.getElementById('message').style.color = 'red';
      document.getElementById('message').innerHTML = ' Password must be longer than 4 characters';
    document.getElementById('Submit').disabled = true;
    }
    else{
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = ' Not Matching';
    document.getElementById('Submit').disabled = true;

    }
  }
}
</script>
