<?php

error_reporting(0);
$host="localhost";

$user="root";

$pass="";
$db = "hotel";


$con = mysql_connect($host,$user,$pass);

$db = mysql_select_db($db);


if(!$con)
{
die("Connection Error".mysql_error());

}


?>

