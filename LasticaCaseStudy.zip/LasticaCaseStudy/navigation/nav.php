<style>
	*{
		font-family: century gothic;
	}
</style>


	<li>
		<img src="logo.png" width="100%" height="100%";>
			<center style="font-size: 120%; font-weight: bold;">POINT OF SALES</center>
	</li>

	<li class="active"> 
		<img src="home.png" width="12%"> 
			<a style="display: inline; margin-left: 10%;" href="home.php"> Home </a>
 	</li>

	<li class=""> 
		<img src="customers.png" width="12%"> 	
			<a style="display: inline; margin-left: 10%;" href="customers.php"> Customers </a> 
	</li>

	<li> 
		<img src="items.png" width="12%"> 
			<a style="display: inline; margin-left: 10%;" href="items.php"> Items </a> 
	</li>

	<li> 
		<img src="dashboard.png" width="12%"> 
			<a style="display: inline; margin-left: 10%;" href="dashboard.php"> Dashboard </a> 
	</li>


<script>
	$('ul li a').click(function(){ $('li a').removeClass("active"); $(this).addClass("active"); });
</script>
