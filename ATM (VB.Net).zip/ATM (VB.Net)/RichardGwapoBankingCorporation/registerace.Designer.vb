﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class registerace
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IDLabel As System.Windows.Forms.Label
        Dim PinnumLabel As System.Windows.Forms.Label
        Dim AcctnumLabel As System.Windows.Forms.Label
        Dim CustnameLabel As System.Windows.Forms.Label
        Dim BalanceLabel As System.Windows.Forms.Label
        Me.RegisterDataSet = New RichardGwapoBankingCorporation.RegisterDataSet()
        Me.Table1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Table1TableAdapter = New RichardGwapoBankingCorporation.RegisterDataSetTableAdapters.Table1TableAdapter()
        Me.TableAdapterManager = New RichardGwapoBankingCorporation.RegisterDataSetTableAdapters.TableAdapterManager()
        Me.IDTextBox = New System.Windows.Forms.TextBox()
        Me.PinnumTextBox = New System.Windows.Forms.TextBox()
        Me.AcctnumTextBox = New System.Windows.Forms.TextBox()
        Me.CustnameTextBox = New System.Windows.Forms.TextBox()
        Me.BalanceTextBox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        IDLabel = New System.Windows.Forms.Label()
        PinnumLabel = New System.Windows.Forms.Label()
        AcctnumLabel = New System.Windows.Forms.Label()
        CustnameLabel = New System.Windows.Forms.Label()
        BalanceLabel = New System.Windows.Forms.Label()
        CType(Me.RegisterDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Table1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'RegisterDataSet
        '
        Me.RegisterDataSet.DataSetName = "RegisterDataSet"
        Me.RegisterDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Table1BindingSource
        '
        Me.Table1BindingSource.DataMember = "Table1"
        Me.Table1BindingSource.DataSource = Me.RegisterDataSet
        '
        'Table1TableAdapter
        '
        Me.Table1TableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Table1TableAdapter = Me.Table1TableAdapter
        Me.TableAdapterManager.UpdateOrder = RichardGwapoBankingCorporation.RegisterDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'IDLabel
        '
        IDLabel.AutoSize = True
        IDLabel.Location = New System.Drawing.Point(173, 155)
        IDLabel.Name = "IDLabel"
        IDLabel.Size = New System.Drawing.Size(21, 13)
        IDLabel.TabIndex = 1
        IDLabel.Text = "ID:"
        '
        'IDTextBox
        '
        Me.IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Table1BindingSource, "ID", True))
        Me.IDTextBox.Location = New System.Drawing.Point(235, 152)
        Me.IDTextBox.Name = "IDTextBox"
        Me.IDTextBox.Size = New System.Drawing.Size(100, 20)
        Me.IDTextBox.TabIndex = 2
        '
        'PinnumLabel
        '
        PinnumLabel.AutoSize = True
        PinnumLabel.Location = New System.Drawing.Point(173, 181)
        PinnumLabel.Name = "PinnumLabel"
        PinnumLabel.Size = New System.Drawing.Size(44, 13)
        PinnumLabel.TabIndex = 3
        PinnumLabel.Text = "pinnum:"
        '
        'PinnumTextBox
        '
        Me.PinnumTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Table1BindingSource, "pinnum", True))
        Me.PinnumTextBox.Location = New System.Drawing.Point(235, 178)
        Me.PinnumTextBox.Name = "PinnumTextBox"
        Me.PinnumTextBox.Size = New System.Drawing.Size(100, 20)
        Me.PinnumTextBox.TabIndex = 4
        '
        'AcctnumLabel
        '
        AcctnumLabel.AutoSize = True
        AcctnumLabel.Location = New System.Drawing.Point(173, 207)
        AcctnumLabel.Name = "AcctnumLabel"
        AcctnumLabel.Size = New System.Drawing.Size(51, 13)
        AcctnumLabel.TabIndex = 5
        AcctnumLabel.Text = "acctnum:"
        '
        'AcctnumTextBox
        '
        Me.AcctnumTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Table1BindingSource, "acctnum", True))
        Me.AcctnumTextBox.Location = New System.Drawing.Point(235, 204)
        Me.AcctnumTextBox.Name = "AcctnumTextBox"
        Me.AcctnumTextBox.Size = New System.Drawing.Size(100, 20)
        Me.AcctnumTextBox.TabIndex = 6
        '
        'CustnameLabel
        '
        CustnameLabel.AutoSize = True
        CustnameLabel.Location = New System.Drawing.Point(173, 233)
        CustnameLabel.Name = "CustnameLabel"
        CustnameLabel.Size = New System.Drawing.Size(56, 13)
        CustnameLabel.TabIndex = 7
        CustnameLabel.Text = "custname:"
        '
        'CustnameTextBox
        '
        Me.CustnameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Table1BindingSource, "custname", True))
        Me.CustnameTextBox.Location = New System.Drawing.Point(235, 230)
        Me.CustnameTextBox.Name = "CustnameTextBox"
        Me.CustnameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.CustnameTextBox.TabIndex = 8
        '
        'BalanceLabel
        '
        BalanceLabel.AutoSize = True
        BalanceLabel.Location = New System.Drawing.Point(173, 259)
        BalanceLabel.Name = "BalanceLabel"
        BalanceLabel.Size = New System.Drawing.Size(48, 13)
        BalanceLabel.TabIndex = 9
        BalanceLabel.Text = "balance:"
        '
        'BalanceTextBox
        '
        Me.BalanceTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Table1BindingSource, "balance", True))
        Me.BalanceTextBox.Location = New System.Drawing.Point(235, 256)
        Me.BalanceTextBox.Name = "BalanceTextBox"
        Me.BalanceTextBox.Size = New System.Drawing.Size(100, 20)
        Me.BalanceTextBox.TabIndex = 10
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(142, 48)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(249, 48)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'registerace
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(456, 321)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(IDLabel)
        Me.Controls.Add(Me.IDTextBox)
        Me.Controls.Add(PinnumLabel)
        Me.Controls.Add(Me.PinnumTextBox)
        Me.Controls.Add(AcctnumLabel)
        Me.Controls.Add(Me.AcctnumTextBox)
        Me.Controls.Add(CustnameLabel)
        Me.Controls.Add(Me.CustnameTextBox)
        Me.Controls.Add(BalanceLabel)
        Me.Controls.Add(Me.BalanceTextBox)
        Me.Name = "registerace"
        Me.Text = "registerace"
        CType(Me.RegisterDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Table1BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RegisterDataSet As RichardGwapoBankingCorporation.RegisterDataSet
    Friend WithEvents Table1BindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Table1TableAdapter As RichardGwapoBankingCorporation.RegisterDataSetTableAdapters.Table1TableAdapter
    Friend WithEvents TableAdapterManager As RichardGwapoBankingCorporation.RegisterDataSetTableAdapters.TableAdapterManager
    Friend WithEvents IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PinnumTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AcctnumTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CustnameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BalanceTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
