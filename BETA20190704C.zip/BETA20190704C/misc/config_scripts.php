<?php

?>
<script>
function isNumberKey(evt){//checks whether the key pressed is a number - returns true if it is, false if it isn't
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

Number.prototype.pad = function(size) { //automatically pads integers with 0s up to the tens (2) place
  var s = String(this);
  while (s.length < (size || 2)) {s = "0" + s;}
  return s;
}

//----------------------SCRIPT FOR TOGGLING CHECKBOXES--------------------//
function toggleCbox(cBox){  //script shows/hides all objects with a class value equal to the value of the checkbox
  console.log('Checkbox '+cBox+' toggled');
  var passValue = cBox.value;
  if(cBox.checked){
      showTableRowByClass(passValue);
      //console.log(cBox.checked);  
  }
  else{
      hideElementsByClass(passValue);
      //console.log(cBox.checked);
  }
}
//-----------------END OF SCRIPT FOR TOGGLING CHECKBOXES--------------------//


//-----------------------SCRIPT FOR TOGGLING NEGATIVE CHECKBOXES--------------------//
function toggleNegativeCbox(cBox){  //reverse of above function - an unchecked textbox means the elements it oversees are shown
  console.log('Checkbox '+cBox+' toggled');
  var passValue = cBox.value;
  if(!cBox.checked){
      showTableRowByClass(passValue);
      //console.log(cBox.checked);  
  }
  else{
      hideElementsByClass(passValue);
      //console.log(cBox.checked);
  }
}
//-----------------END OF SCRIPT FOR TOGGLING NEGATIVE CHECKBOXES--------------------//


//------------SCRIPT FOR HIDING ELEMENTS WITH A CLASS EQUAL TO THE PARAMETER----------//
function hideElementsByClass(colID){
  console.log(colID+' toggled');
  var hideThis = document.getElementsByClassName(colID);
  for(var counter=0;counter<hideThis.length;counter++){
    hideThis[counter].style.display='none';
  }
}
//----------END OF SCRIPT FOR HIDING ELEMENTS WITH A CLASS EQUAL TO THE PARAMETER-------//


//------------SCRIPT FOR SHOWING TABLE ROWS WITH A CLASS EQUAL TO THE PARAMETER----------//
function showTableRowByClass(colID){
  console.log(colID+' toggled');
  var showThis = document.getElementsByClassName(colID);
  for(var counter=0;counter<showThis.length;counter++){
    showThis[counter].style.display='table-row';
  }
}
//---------END OF SCRIPT FOR SHOWING TABLE ROWS WITH A CLASS EQUAL TO THE PARAMETER-------//


//-------------------SCRIPT TO SELECT A SPECIFIC OPTION FROM A DROP-DOWN------------------//
function setSelectedOption(id, valueToSelect)
{    
    var element = document.getElementById(id);
    element.value = valueToSelect;
}
//----------------END OF SCRIPT TO SELECT A SPECIFIC OPTION FROM A DROP-DOWN--------------//


/*
//-------------------JS FILTER FUNCTION FOR PURE TEXT TABLES-----------------//
var query = document.getElementById('searchstr');
var filter = query.value.toUpperCase();
var table = document.getElementById('outputTable');
var tr = table.getElementsByTagName('tr');
var td;

function filterTable(){ //(hopefully) filters table
    filter = query.value.toUpperCase();
    for (var i = 1; i < tr.length; i++) {//loops through each row
        //td = tr[i].getElementsByTagName("td");
        var rowToggle = false;
        for (var j = 0; j<tr[i].cells.length; j++){//loops through each cell in each row     
            txtValue = tr[i].cells[j].innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {//if cell contains value similar to seach query
                //console.log("found "+filter);
                tr[i].style.display = "table-row";
                rowToggle = true;
                    //code block to check values
                    console.log(txtValue);
                    console.log(filter);
                    console.log(txtValue.toUpperCase().indexOf(filter));
                    //end of code block to check values
            } 
            else {//query not in cell
                if(!rowToggle){
                    tr[i].style.display = "none";
                } 
                //console.log("did not find "+filter);
            }
        }
        console.log("row: "+rowToggle);
    }
}//--------------END OF JS FILTER FUNCTION FOR PURE TEXT TABLES-------------//*/


</script>