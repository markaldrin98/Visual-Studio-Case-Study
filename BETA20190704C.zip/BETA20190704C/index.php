<body onload="loadingScreen()">
<img src="img/taoanguna.png" id="loader">
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>IT Ticketing System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Bootstrap core CSS -->
  <link href="bootstrap/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/createticket.css">
  <!-- Custom styles for this template -->
</head>

<body id="page-top">
  <!-- Header -->
  <header class="masthead">
    <div class="container">
      <div class="intro-text">
        <div class="intro-lead-in">Welcome to the ITDO Ticketing Portal!</div>
        <div class="intro-heading text-uppercase">It's Nice To Meet You!</div>
        <a href="createticket.php" class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#services">Create A Ticket</a>
      </div>
    </div>
  </header>
</div>
</body>

</html>
<script>

window.onload=loadingScreen();
</script>