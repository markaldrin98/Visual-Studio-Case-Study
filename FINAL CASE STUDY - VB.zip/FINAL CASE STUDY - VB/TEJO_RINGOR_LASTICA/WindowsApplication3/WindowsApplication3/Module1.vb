﻿Imports System.Data.OleDb
Module Module1
    Public acsonn As New OleDb.OleDbConnection
    Public acsdr As OleDbDataReader
    Public strsql As String

    Sub connect()
        acsonn.ConnectionString = "Provider=Microsoft.jet.ace.oledb.12.0; data source=|datadirectory"
        acsonn.Open()
    End Sub

End Module
