<?php 
error_reporting(0);
include "admin_auth.php";
session_start();
include "admin_header.php";?>
<div id="cover">
<div id="content">
<?php global $msg; echo $msg;?>
<h4>Hellow,&nbsp;<?php echo $_SESSION['SESS_NAME'] ;?><br /></h4>
  <div id="login">
        <fieldset>
            <legend><h3> well come to reservation admin page
            </h3></legend>
  <h4 style="color:#e60808;"><?php global $nam; echo $nam;?> </h4> 

  <?php global $error; echo $error;?>                  
			<!-- the login form-->
      


<body>
<?php include "demo1.html";?>

<fieldset>
</div>
</div>
</body>

<?php include "footer.php";?>
