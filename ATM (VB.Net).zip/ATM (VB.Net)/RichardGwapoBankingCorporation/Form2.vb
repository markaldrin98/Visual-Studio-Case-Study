﻿Imports System.Data.OleDb

Public Class Form2

    Dim conn As OleDbConnection
    Dim cmd As OleDbCommand
    Dim reader As OleDbDataReader
    Dim timeleft As Integer = 30
    Dim trial As Integer = 0
    Dim count As Integer = 0
    Dim countdown As Integer = 30
    Public pinnum As String = ""
    Public acctnum As String = ""
    Public acctname As String = ""
    Public balance As String = ""
    Dim ans As DialogResult

    Private Sub Form2_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" &
                Application.StartupPath & "\dbCustomerAcct.mdb")

    End Sub

    Private Sub TextBox1_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress

        If e.KeyChar = ChrW(Keys.Enter) Then

            If TextBox1.Text = "" Then

                MessageBox.Show("Enter Your Pin Number...", "PIN NUMBER", MessageBoxButtons.OK, MessageBoxIcon.Error)

            Else
                conn.Open()
                cmd = New OleDbCommand()
                cmd.Connection = conn
                cmd.CommandText = "Select * from tblCustomerInfo where pinnum = '" & TextBox1.Text & "'"

                reader = cmd.ExecuteReader()
                count = 0

                While (reader.Read())

                    count = count + 1

                    Me.Hide()
                    Form3.Show()

                    pinnum = reader("pinnum").ToString()
                    acctnum = reader("acctnum").ToString()
                    acctname = reader("custname").ToString()
                    balance = reader("balance").ToString()

                End While

                If (count > 0) Then

                    count = 0

                Else

                    trial = trial + 1
                    TextBox1.Clear()

                    If trial = 3 Then

                        ans = MessageBox.Show("Captured Card... Call 123-4567...", "PIN NUMBER", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        If ans = DialogResult.OK Then

                            trial = 0
                            TextBox1.Enabled = False
                            timer1.Enabled = True
                            Label2.Text = "Try Again After 30 Seconds . . ."

                        End If

                    Else

                        MessageBox.Show("Wrong Pin Number...", "PIN NUMBER", MessageBoxButtons.OK, MessageBoxIcon.Error)

                    End If

                End If

                conn.Close()

            End If

        Else

            If Char.IsDigit(e.KeyChar) = False And Char.IsControl(e.KeyChar) = False Then
                e.Handled = True
            End If

        End If

    End Sub

    Private Sub timer1_Tick(sender As System.Object, e As System.EventArgs) Handles timer1.Tick

        countdown = timeleft - 1
        timeleft = timeleft - 1
        Label2.Text = "Try Again After " & countdown.ToString() & " Seconds . . ."

        If countdown < 0 Then

            timer1.Enabled = False
            Label2.Text = "Press Enter To Enter Your Pin"
            TextBox1.Enabled = True
            timeleft = 30

        End If

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click


        Me.Hide()
        Form8.Show()

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class