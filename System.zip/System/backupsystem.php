<!DOCTYPE html>
<html>
<head>
	<title>Purchase Journal Window</title> <!-- Title of your web page -->
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- To make your web page responsive -->
	
	<!-- These tags are support for Bootstrap's CSS and Javscript from Bootstrap.-->

	<!-- Latest compiled and minified CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">

	<!-- jQuery library -->
	
	<!-- Latest compiled JavaScript -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  	<!-- Link for Bootstrap Icons -->
	<link rel="stylesheet" href="css/all.css">
	<script src="js/all.js"></script>

	<!-- Link to style web page (CSS Link) -->
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head>

<body>

<div class="container"> 
  <br> <!-- To make one row space -->
 	  <div class="btn-group"> <!-- To create an inline button group -->
		  <button type="button" class="btn btn-outline-dark"><i class="fa fa-file"></i> New Order</button>&nbsp;
		  <button type="button" class="btn btn-outline-dark"><i class="fa fa-save"></i> Save Order</button>&nbsp;
		  <button type="button" class="btn btn-outline-dark"><i class="fa fa-history"></i> History</button>&nbsp;
		  <button type="button" class="btn btn-outline-dark"><i class="fa fa-search"></i> Search Batch</button>&nbsp;
		  <button type="button" class="btn btn-outline-dark"><i class="fa fa-window-close"></i> Close Win</button>
	  </div>
	  <br><br>
	   <div class="card-deck">

  	<div class="card mb-6">

	  <fieldset class="scheduler-border card-body">
		  <legend class="scheduler-border">Purchase Order Information</legend>

			  <div class="input-group mb-3 input-group-sm">
				  <div class="input-group-prepend">
				    <span class="input-group-text" id="basic-addon1">P.O No/S.I No:</span>
				  </div>
  			  	  <input type="text" class="form-control" placeholder="No:">
			 </div>

			 <div class="input-group mb-3 input-group-sm">
				  <div class="input-group-prepend">
				    <span class="input-group-text" id="basic-addon1">Purchased Date:</span>
				  </div>
  			  	  <input type="date" class="form-control" placeholder="No:">
			 </div>
			 <fieldset class="scheduler-border card">
			 		<legend class="scheduler-border">Mode of Payment</legend>
			 		<form>
					  <div class="input-group mb-3">
  							<div class="custom-control custom-radio custom-control-inline">
					    		<input type="radio" class="custom-control-input" id="customRadio" name="example" value="customEx">
					    		<label class="custom-control-label" for="customRadio">COD</label>
					  		</div>

					        <div class="custom-control custom-radio custom-control-inline">
					            <input type="radio" class="custom-control-input" id="customRadio2" name="example" value="customEx">
					            <label class="custom-control-label" for="customRadio2">Terms</label>
					        </div>

  					    <div class="input-group-append input-group-sm">
						     <select class="form-control" id="exampleFormControlSelect1">
						        <option disabled selected>No. of Days</option>
						        <option>1</option>
						        <option>2</option>
						        <option>3</option>
						        <option>4</option>
						        <option>5</option>
						    </select>
						    &emsp;
	     					<div class="input-group-sm">
						    	<input type="date" class="form-control" placeholder="No:">				    
						    </div>
  						</div>
					  </div>
					</form>
			 </fieldset>
	  </fieldset>
	</div>




	  	<div class="card mb-6">

	  <fieldset class="scheduler-border card-body">
		  <legend class="scheduler-border">Supplier Information</legend>

			  <div class="input-group mb-3 input-group-sm">
				  <div class="input-group-prepend">
				    <span class="input-group-text" id="basic-addon1">Supplier No:</span>
				  </div>
  			  	  <input type="text" class="form-control" placeholder="No...">
			 </div>

			 <div class="input-group mb-3 input-group-sm">
				  <div class="input-group-prepend">
				    <span class="input-group-text" id="basic-addon1">Name:</span>
				  </div>
  			  	  <input type="text" class="form-control" placeholder="Name...">
			 </div>

			<div class="input-group mb-3 input-group-sm">
				  <div class="input-group-prepend">
				    <span class="input-group-text" id="basic-addon1">Address:</span>
				  </div>
  			  	  <input type="text" class="form-control" placeholder="Address...">
			 </div>

			<div class="input-group mb-3 input-group-sm">
				  <div class="input-group-prepend">
				    <span class="input-group-text" id="basic-addon1">Contact Number:</span>
				  </div>
  			  	  <input type="text" class="form-control" placeholder="Contact Number...">
			 </div>

			  <div class="btn-group"> <!-- To create an inline button group -->
		  <button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-upload"></i> Upload PO</button>&nbsp;
		  <button type="button" class="btn btn-outline-dark btn-sm"><i class="fa fa-compact-disc"></i> Upload From Disk</button>&nbsp;
		</div>

			
	  </fieldset>
	</div>
</div>

<br>

<div class="card-deck">
	<div class="card">
		<fieldset class="scheduler-border card-body">
		  <legend class="scheduler-border">Supplier Information</legend>
		</fieldset>
	</div>

</div>


 </div>


</body>
</html>