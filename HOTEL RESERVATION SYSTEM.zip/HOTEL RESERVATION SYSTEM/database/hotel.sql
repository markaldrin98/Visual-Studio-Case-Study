-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2015 at 06:03 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `stud_id` varchar(255) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `gender` varchar(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`stud_id`, `firstname`, `lastname`, `username`, `gender`) VALUES
('2020', 'Hamisi', 'Ally', 'ifm', 'BCS');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `login_id` int(200) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `rank` varchar(80) NOT NULL DEFAULT 'student',
  `status` varchar(10) NOT NULL DEFAULT 'ACTIVE'
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `username`, `password`, `rank`, `status`) VALUES
(33, 'serate', '25d55ad283aa400af464c76d713c07ad', 'student', 'INACTIVE'),
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'administrator', 'ACTIVE'),
(19, 'asefa', 'e10adc3949ba59abbe56e057f20f883e', 'student', 'ACTIVE'),
(20, 'wase', 'fcea920f7412b5da7be0cf42b8c93759', 'student', 'ACTIVE'),
(21, 'getalew', 'c7349dc8ac2e2b3ec64f41e51c995cc4', 'student', 'ACTIVE'),
(22, 'setotaw', '25d55ad283aa400af464c76d713c07ad', 'student', 'ACTIVE'),
(31, 'ashenafi', '25d55ad283aa400af464c76d713c07ad', 'student', 'ACTIVE'),
(24, 'desalgn', 'bf0d439b2ac9d4a36afb960083ffc6fa', 'student', 'ACTIVE'),
(25, 'asfa', '1234567', 'student', 'ACTIVE'),
(26, 'ashu', '1234567', 'student', 'ACTIVE'),
(27, 'ashumare', 'fcea920f7412b5da7be0cf42b8c93759', 'student', 'ACTIVE'),
(28, 'adam', 'fcea920f7412b5da7be0cf42b8c93759', 'student', 'ACTIVE'),
(34, 'markos', 'fcea920f7412b5da7be0cf42b8c93759', 'student', 'ACTIVE'),
(35, 'asfg', '25d55ad283aa400af464c76d713c07ad', 'student', 'ACTIVE'),
(36, 'kebede', 'fcea920f7412b5da7be0cf42b8c93759', 'student', 'ACTIVE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`login_id`), ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `login_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
