<?php if(session_status()!=PHP_SESSION_ACTIVE) session_start();
include 'config_php_functions.php';
include 'config_scripts.php';

   global $conn;

   $servername = "localhost";
   $username = "root";
   $password = "";
   $dbname = "testticketdatabase"; //change this -> temporarily changed
   $conn = mysqli_connect($servername, $username, $password, $dbname);

  //----------------------FILTER TO CHECK IF USER SHOULD BE ON THIS PAGE---------------------//
    $openPages = array("index.php", "createticket.php", "sendticket.php","login.php","checkcredentials.php","proof.php");
    $currentPage = basename($_SERVER['PHP_SELF']);
    toConsole("current page: ".$currentPage);
    if(!callUser() && !in_array($currentPage, $openPages)){//executes this clause when no user is logged in and page is not 'open'
      redirect('index.php');
    }
  //-------------------END OF FILTER TO CHECK IF USER SHOULD BE ON THIS PAGE-----------------//

/*if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true){
  //redirect('login.php?op=login');
}
else{  //this function forces login
  redirect('login.php');
}*/
    $tab1 = '';
    $tab2 = '';
    $tab3 = '';
    $tab4 = '';
    $tab5 = ''; //variables that toggle which tabs are visible on the nav bar
    $tab6 = '';
    $space = '';

  // filters out nav tabs based on authority of logged-in user
  if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && isset($_SESSION['userType']) && $_SESSION['userType']=='admin'){
  }
  else if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && isset($_SESSION['userType']) && $_SESSION['userType']=='tech'){
    $tab3 = 'display:none;';
  }
  else{
    $icon = 'display: none;';
    $menutab = 'display: none;';
    $tab0 = 'display:none;';
    $tab1 = 'display:none;';
    $tab2 = 'display:none;';
    $tab3 = 'display:none;';
    $tab4 = 'display:none;';
    $tab5 = 'display:none;';
    $tab6 = 'display:none;';
    $space = 'display:none;';
    $navigation = 'display:none;';

  }
?>

-->
<div id="myContainer">
<body class="bgBox" id="bg">

<nav class="navbar navbar-expand-sm navbar-dark fixed-top navbar-custom">
  <a class="navbar-brand" href="#">ITDO Ticketing System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item"><a class="nav-link" href="index.php"><span class="oi oi-rss-alt"></span> Home</a></li>
          <?php //sets right end of nav bar (changes elements depending on whether or not there is a user logged in)
        if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true){  
           echo '
           <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" id="navbardrop" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> Welcome, '.$_SESSION["client_name"].' <span class="glyphicon glyphicon-triangle-bottom"></span></a>
                <ul class="dropdown-menu">
                  <li class="nav-item"><a class="dropdown-item" style="<?php echo $tab0;?>" href="createticket.php"><span class="glyphicon glyphicon-file"></span> Create Ticket</a></li>
                  <li class="nav-item"><a class="dropdown-item" style="<?php echo $tab1;?>" href="outstanding.php"><span class="glyphicon glyphicon-list"></span> Outstanding Tickets</a></li>
                  <li class="nav-item"><a class="dropdown-item" style="<?php echo $tab2;?>" href="activeticket.php"><span class="glyphicon glyphicon-check"></span> Active Ticket</a></li>
                  <li class="nav-item"><a class="dropdown-item" style="<?php echo $tab3;?>" href="devicemanagement.php"><span class="glyphicon glyphicon-list-alt"></span> Device Management</a></li>
                  <li class="nav-item"><a class="dropdown-item" style="<?php echo $tab4;?>" href="reports.php"><span class="glyphicon glyphicon-tasks"></span> Reports</a></li>
                  <li class="nav-item"><a class="dropdown-item" style="<?php echo $tab5;?>" href="changepass.php"> Change Password</a></li>
                  <li class="nav-item"><a class="dropdown-item" href="#">
                  <div class="custom-control custom-switch">
                    <input class="custom-control-input myCheckbox" id="switch1" type="checkbox" name="checkbox" value="value" onclick="myFunction()"> <label class="custom-control-label" for="switch1" ><span id="demo">Dark</span> Mode</label>
                    </div>
                    </a></li>
                  <li class="nav-item"><a class="dropdown-item" style="<?php echo $tab6;?>" href="logout.php"><span class=" glyphicon glyphicon-log-out"></span> Log Out</a></li>
                </ul>
           </li>'; 
       /*    echo '<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log Out</a></li>'; */
        }
        else{
         /*  echo '<a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a>'; */
           echo '
           <li class="nav-item">
              <a class="nav-link" data-toggle="modal" data-target="#loginModal" href="index.php">
                <span class="glyphicon glyphicon-home"></span>Login
              </a>
           </li>
      ';

        }
    ?> 
    <li style="<?php echo $navigation;?>" class="nav-item dropdown"><a class="nav-link dropdown-toggle" data-toggle="dropdown" id="navbardrop" href="#">Ticket Queue <span class="glyphicon glyphicon-triangle-bottom"></span></a>
                <ul class="dropdown-menu ticketStyle">
                  <div class="lineBottom">
                    <div class="textLeft">
                      <li class="nav-item">
                        <span class="dropdown-item-text" style="color: #00ccff;">Ongoing: </span>
                      </li>
                    </div>
                    <div class="textRight">  
                      <li class="nav-item">
                        <ul>
                        <?php printTickets(getTickets('Ongoing'));?>
                        <!--above function call outputs all ticket IDs tagged 'Ongoing'-->
                        </ul>
                    </div>
                  </div> 
                  <div class="lineBottom">
                    <div class="textLeft"> 
                      <li class="nav-item">
                        <span class="dropdown-item-text" style="color: orange;">Pending:</span>
                      </li>
                    </div>
                    <div class="textRight">  
                      <li class="nav-item">
                        <ul>
                        <?php printTickets(getTickets('Open'));?>
                        <!--above function call outputs all ticket IDs tagged 'Open'-->
                        </ul>
                      </li>
                    </div>
                  </div>         
              </ul>
           </li>
    </ul>
  </div>  
</nav>

<!-- Modal for Login -->
<div id="loginModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header bgOrange">
        <h4 class="modal-title centerText">Log In</h4>
      </div>
      <div class="modal-body">
        <form class='login100-form validate-form' action='checkcredentials.php' method='post'>
            <div class='field'>
              <input type='text' required autocomplete='off' id='username' required name='username' class='form-control' autofocus>
              <label for='username' title='Username' data-title='Username'></label>
            </div>        
            <div class='field'>
              <input type='Password' id='password' required name='password' class='form-control'>
              <label for='password' title='Password' data-title='Password'></label>
            </div>
            <div class='container-login100-form-btn'>
              <div class='wrap-login100-form-btn'>             
                <input type='submit' value='Log In' name='Submit' id='Submit' class='login100-form-btn'>
              </div>    
            </div>
        </form>
      </div>  
    </div>
  </div>
</div>
</body>

<head>
  <link rel="stylesheet" type="text/css" href="css/dropdown.css">
  <link rel="stylesheet" type="text/css" href="css/darkmode.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="darkmode.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />

</head>



