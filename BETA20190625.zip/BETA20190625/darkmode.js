function myFunction(){
		
var bgBox=document.getElementById("bg");

  // Get checkbox
 var checkboxContainer = document.getElementById("myContainer");
 var lightMode = document.getElementById("demo");
  // Get checkbox
  var formCheckbox = document.querySelector(".myCheckbox");
  localStorage.setItem(".myCheckbox", formCheckbox.checked);

if (formCheckbox.checked == true){ 
    checkboxContainer.classList.add('checked');
    bgBox.style="background-color:#10171e;";
    document.getElementById("demo").innerHTML = "Light";
  }

else{
    bgBox.style="background-color:white;";
    checkboxContainer.classList.remove("checked");
    document.getElementById("demo").innerHTML = "Dark";

  }
}

var formCheckbox = JSON.parse(localStorage.getItem('.myCheckbox'));
document.querySelector(".myCheckbox").checked = formCheckbox;

myFunction();