<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="images/DMU.jpg" rel="icon" type="image">
<link href="css/hotel.css" type="text/css" rel="stylesheet" />
<title>Home</title>
<script src="jscript/gen_validatorv4.js" type="text/javascript"></script>
</head>

<body>
<div id="head">
<table border="0" bgcolor="#FFFFFF"width="100%"><tr>
        <td><img src="images/logo1.jpg" height="100" width="890" alt="logo"/></td>
        <td><marquee><img src="images/GLOVE.jpg" height="100" width="890" alt="logo"/></marquee></td>
      </td>
</tr></table>
</div>
<div id="leftnavigation">&nbsp;&nbsp;&nbsp;&nbsp;<a href="adminindex.php">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="login_reg.php"> Reservation list</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="users.php">Customer List </a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="logout.php">Logout</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="adminabout.php">About Us</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="admincontact.php">Contact Us</a>
</div>

