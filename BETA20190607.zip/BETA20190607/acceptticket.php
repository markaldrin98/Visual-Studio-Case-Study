<?php
include_once("misc/config.php");  
echo "<br><br><br><br><br><br><br><br>";  
$ticketID = $_POST["ticket_id"];

$assignCheck = false;   //gate variable
$ticketCheck = false;   //gate variable
printPost();
    //below code block updates ticket currently assigned to the tech in the 'tech_credentials' table
    $queryString = 'UPDATE tech_credentials SET current_ticket = "'.$ticketID.'" WHERE employee_name="'.$_SESSION["client_name"].'"';  
                   if (mysqli_query($conn, $queryString)) { 
                        //echo "<script>console.log('"."Check 1 clear"."')</script>";
                        //echo $queryString;
                        $assignCheck = true;
                    } 
                    else {    //report sql error
                        //echo '<script>console.log("Check 1 - '.mysqli_error($conn).'");</script>';
                    }
    //end of code block

    //below code block updates which tech is assigned to the ticket represented by $ticketID in the 'tickets' table
    $queryString = 'UPDATE tickets SET date_accepted=now(), job_status = "Ongoing",respondent = "'.$_SESSION["client_name"].'" WHERE ticket_id="'.$ticketID.'"';  
                   if (mysqli_query($conn, $queryString)) { 
                        //echo "<script>console.log('"."Check 2 clear"."')</script>";
                        $ticketCheck = true;
                        //echo $queryString;
                    } 
                    else {    //report sql error
                        //echo '<script>console.log("Check 2 - '.mysqli_error($conn).'");</script>';
                        //echo "<script>console.log('".$queryString."')</script>";
                    }
    //end of code block

    if($assignCheck && $ticketCheck){   //checks gate variables - if both gate variables return true, then both queries were successful and the page should redirect
        //echo "<script>console.log('"."Redirecting to activeticket"."')</script>";
        redirect('activeticket.php');
    }
    else{   //else do nothing
        //echo "<script>console.log('"."Doing nothing"."')</script>";
    }

?>

