<?php include 'misc/config.php';?>
<div style="color:white;">
<?php

//-------------------------TEST CODE BLOCK FOR TICKET_ID GENERATION-------------------------//
/*$idQuery="SELECT MAX(RIGHT(id, 3)) AS 'maxim' FROM tickets WHERE ticket_id LIKE '".date('ymd')."-%'";
$idResult = mysqli_query($conn,$idQuery);
    if(!$idResult || mysqli_num_rows($idResult)==0) {//no appropriate records are extant
        toConsole('No records for the current day');
        $idQuery=date('ymd')."-001')";
    }
    else{
        $idRes = mysqli_fetch_array($idResult);
        toConsole('Retrieved '.$idRes["maxim"]);
        $idQuery=date('ymd')."-".sprintf('%03d',(intval($idRes['maxim'])+1));
    }*/
//-------------------------TEST CODE BLOCK FOR TICKET_ID GENERATION-------------------------//

$ticket_id = '190509-002';//should be extracted from the value of the current element in the loop (e.g. $res['ticket_id'])

echo "<br><br><br><br><br><br><br><br>";

$isAssessed = (string)(1<2);
print("Is assessed: ".$isAssessed);
$isAssessed = true;
print("<br>Is assessed: ".$isAssessed);


?>
</div>
<script>  
</script>