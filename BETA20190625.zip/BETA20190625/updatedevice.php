<?php
include_once("misc/config.php");  
echo "<br><br><br><br><br><br><br><br>";  
    if(checkPost("ticket_id")){//checks to see if 'device_id' has been posted - if it is not set, then the user accessed this page through unintended channels
    }
    else{
        redirect('index.php');//and should thus be redirected back to the index
    }
    global $conn;
    $qString ='SELECT * FROM tickets WHERE ticket_id="'.checkPost("ticket_id").'"';//retrieves ticket with the same id as the id posted
    $result = mysqli_query($conn,$qString);
    $res = mysqli_fetch_array($result);

        $queryString = "UPDATE tickets SET ticket_id='".checkPost("ticket_id")."'";
        $fieldArray = retrieveFields('device_list');//retrieves an array of all fields in device_list
        for($counter=0;$counter<count($fieldArray);$counter++){//iterates through each field
            if(checkPost($fieldArray[$counter])!=false){//current field has a posted value
                if(checkPost($fieldArray[$counter])!=$res[$fieldArray[$counter]]){//posted value is different from stored value
                    if($fieldArray[$counter]=='remarks'){//checks to see if program's currently iterating through the 'remarks' colum
                        $oldRemark = mysqli_real_escape_string ($conn,$res['remarks']);//escapes stored chat log
                        $currentUser = mysqli_real_escape_string ($conn,callUser());
                        $newRemark = checkPost($fieldArray[$counter]);//formats new remark
                        $newRemark = mysqli_real_escape_string ($conn,$newRemark);//escapes new remark

                        if($oldRemark==''){//code block determines if chat log is empty - if it is, insert a new remark - if it isn't, add new remark to old remark string
                            $queryString.=", ".$fieldArray[$counter]."= CONCAT('".$currentUser."<',now(),'>:".$newRemark."-:-"."')";
                        }
                        else{
                            $queryString.=", ".$fieldArray[$counter]."= CONCAT('".$oldRemark."','".$currentUser."<',now(),'>:".$newRemark."-:-"."')";                
                        }
                    }
                    else{                        
                        $queryString.=", ".$fieldArray[$counter]."='".escapeString(checkPost($fieldArray[$counter]))."'";
                    }
                //log change here
                }
            }
        }
        $queryString.= " WHERE ticket_id='".checkPost("ticket_id")."'";
        if(mysqli_query($conn,$queryString)){//ticket updated, return to outstanding.php
            toConsole("Update success!");
            var_dump($queryString);
            redirect('outstanding.php');
        }
        else{
            toConsole("Update failure!");
            var_dump($queryString);
            checkSQLError();
        }

?>

