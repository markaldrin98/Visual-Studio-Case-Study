<?php include 'misc/config.php';?>
<link rel="stylesheet" type="text/css" href="css/fieldmanagement.css">
<div class="container lineSpace whiteText" >
<center>
  <h3>Select a field to add a value to:</h3>
  <?php include 'fieldmanagementmodule.php';?>
</center>
</div>