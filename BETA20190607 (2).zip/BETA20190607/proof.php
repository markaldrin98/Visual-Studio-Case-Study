<?php include 'misc/config.php';?>
<?php

//-------------------------TEST CODE BLOCK FOR TICKET_ID GENERATION-------------------------//
/*$idQuery="SELECT MAX(RIGHT(id, 3)) AS 'maxim' FROM tickets WHERE ticket_id LIKE '".date('ymd')."-%'";
$idResult = mysqli_query($conn,$idQuery);
    if(!$idResult || mysqli_num_rows($idResult)==0) {//no appropriate records are extant
        toConsole('No records for the current day');
        $idQuery=date('ymd')."-001')";
    }
    else{
        $idRes = mysqli_fetch_array($idResult);
        toConsole('Retrieved '.$idRes["maxim"]);
        $idQuery=date('ymd')."-".sprintf('%03d',(intval($idRes['maxim'])+1));
    }*/
//-------------------------TEST CODE BLOCK FOR TICKET_ID GENERATION-------------------------//

$ticket_id = '190509-002';//should be extracted from the value of the current element in the loop (e.g. $res['ticket_id'])
$chatBoxQuery = "SELECT * FROM testcboxdata WHERE ticket_id='".$ticket_id."'";//sample query to select the ticket to extract [chat_log]
$chatBoxResult = mysqli_query($conn,$chatBoxQuery); //ticket table should always have a chatbox field per row so there should be no need to check if this exists
$chatBoxRes = mysqli_fetch_array($chatBoxResult);
$dummyChatlog = $chatBoxRes['chat_log'];
printTickets(getTickets('Ongoing'));
var_dump(getTickets('Ongoing'));
print checkCurrentTicket();

?>

<script>
</script>