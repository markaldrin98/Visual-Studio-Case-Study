<html>
<head>
    <title>Add New Record</title>
</head>
<body>

<?php
include_once("config.php");


if(isset($_POST['Submit'])) {    
	$lname = $_POST['lname'];
	$fname = $_POST['fname'];
	$mname = $_POST['mname'];
	$snumber = $_POST['snumber'];
	$email =  $_POST['email'];
        
    if(empty($lname) || empty($fname) || empty($mname) || empty($snumber) || empty($email)) {                
        if(empty($lname)) {
            echo "<font color='red'>No last name given!</font><br/>";
        }
        
        if(empty($fname)) {
            echo "<font color='red'>No first name given!</font><br/>";
        }
        
        if(empty($mname)) {
            echo "<font color='red'>No middle name given!</font><br/>";
        }

        if(empty($snumber)) {
            echo "<font color='red'>No student number given!</font><br/>";
        }

        if(empty($email)) {
            echo "<font color='red'>No email given!</font><br/>";
        }
        echo "<br/><a href='javascript:self.history.back();'>Back</a>";
    } else { 
        $result = mysqli_query($conn, "INSERT INTO student_info (lname, fname, mname, snumber, email) VALUES ('".$lname."', '".$fname."', '".$mname."', '".$snumber."','".$email."')");        
        echo "<font color='green'>Data added successfully.";
        echo "<br><form style='margin-left:20px;margin-top:40px;' method='get' action='faceplate.php'><input type='submit' value='Return to Index' name='returntoindex'></form>";
        echo "<br><form style='margin-left:20px;margin-top:40px;' method='get' action='insertrecord.php'><input type='submit' value='Add Another' name='addanother'></form>";
    }
}

?>
</body>
</html>

