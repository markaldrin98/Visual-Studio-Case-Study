<!-- CSS Bootstrap Tags -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

<!-- JS Bootstrap Tags -->
<script src="jquery.min.js"></script>
<script src="popper.js"></script>
<script src="bootstrap.js"></script>
<script src="bootstrap.min.js"></script>
