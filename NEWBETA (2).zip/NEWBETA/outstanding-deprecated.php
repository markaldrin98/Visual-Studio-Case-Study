<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<nav>
<ul>

</ul>
</nav>
<style>

.opa:hover {opacity: 0.7;}
.modal-{animation-duration: 0.6s;display:block;}
#centertext, th{
  text-align: center;
  padding: 20px;
  background-color: #202932;
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
  color: #fff;
  font-size: 1.6rem;
  font-family: 'Lato', sans-serif;
}
tr:nth-child(2n) td {background-color: #242e39;}
select{background-color: #202932;color:white;}
body{background-color: #384048; color:white;}
input{
    background-color:#242e39;
    border:solid 1px black;
  } 

</style>
<div class="jumbotron text-center" style="background-color: #24292e; color: white; margin-top: -20px;">
  <h1>Outstanding tickets</h1>
  <p></p> 
</div>

<?php
    
    //commenting out search functionality for now

                //------------------------FUNCTION TO OUTPUT A SELECT CONTROL------------------------
                function outputSelect($fieldString, $storedValue, $ticket_id, $arrayOptions){
                    $selectString ='<td><select style="height:20;" name="'.$fieldString.'Select'.$ticket_id.'">';//start of select
                    foreach($arrayOptions as $value){                           //loop iterating through arrayOptions
                        $selectString .='<option value="';                          //start of option
                        $selectString .=$value.'"';                             //value of option
                            if($storedValue == $value){                   //check for equality between option value and stored value
                                $selectString.="selected";}                     //if true, add 'selected' property to option
                        if($value == ""){                                       //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
                            $selectString.='>No '.$fieldString.' selected</option>';}   
                        else{
                            $selectString.='>'.$value.'</option>';}             //end of option
                    }
                    $selectString.='</select></td>';                            //end of select             
                    echo $selectString;                                         //outputs select to html
                }                
                //--------------------END OF FUNCTION TO OUTPUT A SELECT CONTROL----------------------

  $colorSwitch=0;
  /*$searchstr="";
  $sortHold="";
  if(isset($_GET['searchstr'])) {
    $searchstr=$_GET['searchstr'];
    $sortBy=$_GET['sortBy'];
    $sortHold = $sortBy;
    switch($sortBy){
        case "Client Name":
            $sortBy="client_name";
        break;
        case "Product Name":
            $sortBy="product_name";
        break;
        case "Remarks":
            $sortBy="remarks";
        break;
        case "Date of Transaction":
            $sortBy="orderDate";
        break;
        case "Paid Status":
            $sortBy="is_paid";
        break;
        case "Delivery Status":
            $sortBy="status";
        break;

    }
    //echo $searchstr;$_SESSION['loggedin']
    $result = mysqli_query($conn, "SELECT * FROM orderlist (client_name LIKE '%$searchstr%' OR product_name LIKE '%$searchstr%' OR remarks LIKE '%$searchstr%' OR is_paid LIKE '%$searchstr%' OR status LIKE '%$searchstr%') ORDER BY $sortBy DESC");  
  }
  else{*/
    //$result = mysqli_query($conn, "SELECT * FROM tickets WHERE approval_status = 'Not Approved' OR job_status != 'Completed' ORDER BY date_created AND client_name DESC");
  //} //<- add this back in for search and sort functionality
?>
    <center><div><!--
    <form method="get" action="orders.php">
    <input type="text" name="searchstr" id="searchstr" style="margin-left:20px;"><input type="submit" value="Search" name="Search">
    Sort By: <select name="sortBy" id="sortBy">
    
    <?php/*             //also an element of sort functionality
        $sortString = "";
        switch($sortHold){
            case "Client Name":
                $sortString = "
                    <option selected>Client Name</option>
                    <option>Product Name</option>
                    <option>Remarks</option>
                    <option>Date of Transaction</option>
                    <option>Paid Status</option>
                    <option>Delivery Status</option>";
            break;

            case "Product Name":
                $sortString = "
                    <option>Client Name</option>
                    <option selected>Product Name</option>
                    <option>Remarks</option>
                    <option>Date of Transaction</option>
                    <option>Paid Status</option>
                    <option>Delivery Status</option>";
            break;

            case "Remarks":
                $sortString = "
                    <option selected>Client Name</option>
                    <option>Product Name</option>
                    <option selected>Remarks</option>
                    <option>Date of Transaction</option>
                    <option>Paid Status</option>
                    <option>Delivery Status</option>";
            break;

            case "Paid Status":
                $sortString = "
                    <option>Client Name</option>
                    <option>Product Name</option>
                    <option>Remarks</option>
                    <option>Date of Transaction</option>
                    <option selected>Paid Status</option>
                    <option>Delivery Status</option>";
            break;

            case "Delivery Status":
                $sortString = "
                    <option>Client Name</option>
                    <option>Product Name</option>
                    <option>Remarks</option>
                    <option>Date of Transaction</option>
                    <option>Paid Status</option>
                    <option selected>Delivery Status</option>";
            break;

            default:

                $sortString = "
                    <option>Client Name</option>
                    <option>Product Name</option>
                    <option>Remarks</option>
                    <option>Date of Transaction</option>
                    <option>Paid Status</option>
                    <option>Delivery Status</option>";
            break;
        }
        $sortString .= "</select>";
        echo $sortString;*/ //end of additional element of sort functionality
    ?>  
    </select>
    </form>
    <form style="margin-left:20px" method="get" action="viewrecords.php"><br><input class="lightblueButton" type="submit" value="Refresh" name="Refresh"></form>-->
    </div></center>
    
    <form method="post" action="updatetickets.php">
    <table width='100%' border=0 style="margin-top:30px" id="centertext">
    <?php 

        $result = mysqli_query($conn, "SELECT * FROM tickets WHERE approval_status = 'Not Approved' OR job_status != 'Completed' ORDER BY date_created AND client_name DESC");
        if(!$result || mysqli_num_rows($result)==0) {//checks to make sure there are tickets to be displayed
        }   
        else{
            if($_SESSION['userType']=='admin'){     //code block checks whether it should output the admin interface or the tech interface
                displayAdmin();}                    //and then calls the appropriate function
            else if($_SESSION['userType']=='tech'){
                displayTech();}            
        }

    function displayTech(){ //function to render tech's interface
            //below code block creates head row of table
            global $result,$colorSwitch,$conn;

                $gateQuery = mysqli_query($conn, "SELECT * FROM tech_credentials WHERE employee_name = '".$_SESSION['client_name']."'");
                if(!$gateQuery || mysqli_num_rows($gateQuery)==0) {//checks to make sure tech is extant - mostly unnecessary, but may prevent errors
                }   
                else{
                    while($gateRes = mysqli_fetch_array($gateQuery)){                        
                        if($gateRes['current_ticket'] != NULL || $gateRes['current_ticket'] != ""){
                            $message = 'Error! You must finish your current ticket before accepting a new one!';
                            echo "<script>alert('".$message."');</script>";
                            redirect('activeticket.php');
                        }     
                    }
                }

            echo "
                <tr bgcolor='#AAAAAA' height='40'>
                    <th>Date/Time Created</th>
                    <th>Office</th>
                    <th>Client Name</th>
                    <th>Employee Number</th>
                    <th>Concern</th>
                    <th>Respondent</th>
                </tr>
            ";
            while($res = mysqli_fetch_array($result)) {  //iterates through all tickets
                $optionString = "";

                    if($colorSwitch==1){                 //code block starts row and sets alternating color
                        $colorSwitch = 0;
                        echo "<tr>";// bgcolor='#CCCCCC'>";
                    }  
                    else{
                        echo "<tr>";
                        $colorSwitch = 1;
                    }

                    echo "<td>".$res['date_created']."</td>";       //static
                    echo "<td>".$res['office']."</td>";                 //displays office specified in ticket
                    echo "<td>".$res['client_name']."</td>";            //displays client_name specified in ticket
                    echo "<td>".$res['employee_number']."</td>";        //displays employee_number specified in ticket

                    echo "<td>".$res['concern']."</td>";            //client concern - static
                    //text display for 'concern'

                    if($res['respondent']==""){
                        echo '<td><form method="post" action="acceptticket.php">
                        <input class="btn btn-default" type="submit" name="Submit" value="Accept Ticket" style="background-color: #242e39; border-color: black; color:white;">
                        <input type="hidden" name="acceptingRespondent" value="'.$_SESSION['client_name'].'"">
                        <input type="hidden" name="ticketID" value="'.$res['ticket_id'].'"">
                        </form></td>';
                    }
                    else{
                        echo "<td>".$res['respondent']."</td>"; 
                    }
                    
                    /*echo '<td><textarea style="color:black;resize:none;" value="'.$res["remarks"].'" name="remarksSelect'.$res["ticket_id"].'"></textarea></td>
                    ';//textarea control for 'remarks'*/

                    echo "<td>".$res['time_elapsed']."</td>"; //should be a consequence of date_created and current time

                    echo "</tr>";
            }//end of while loop

                    echo '
                    </table>    <br><br>';  //code block closes table

    }//end of displayTech function

    function displayAdmin(){    //function that displays admin interface
            echo "
                <tr bgcolor='#AAAAAA' height='40'>
                    <th>Date/Time Created</th>
                    <th>Date/Time Accepted</th>
                    <th>Date/Time Fulfilled</th>
                    <th>Office</th>
                    <th>Client Name</th>
                    <th>Employee Number</th>
                    <th>Concern</th>
                    <th>Job Description</th>
                    <th>Participation</th>
                    <th>Approval Status</th>
                    <th>Respondent</th>
                    <th>Status</th>
                    <th>Remarks</th>
                    <th>Time Elapsed</th> <!--still questioning the necessity of this column-->
                    <!--<th>Action</th>-->
                </tr>
            ";

            global $result,$colorSwitch;
            while($res = mysqli_fetch_array($result)) {  //iterates through all tickets
                $optionString = "";

                    if($colorSwitch==1){                 //code block starts row and sets alternating color
                        $colorSwitch = 0;
                        echo "<tr>";// bgcolor='#CCCCCC'>";
                    }  
                    else{
                        echo "<tr>";
                        $colorSwitch = 1;
                    }

                    echo "<td>".$res['date_created']."</td>";       //static
                    echo "<td>".$res['date_fulfilled']."</td>";     //semi-static (admin should be able to reopen tickets) <-consider trimming this and others from tech UI

                    //echo "<td>".$res['office']."</td>";           //editable, JS pending <- block will eventually consist of an array of selects
                    echo '<td><input type="text" name="officeSelect'.$res["ticket_id"].'" value="'.$res["office"].'"></td>';
                                //$_POST['officeSelect1'] -> IT
                    //textbox control for 'office'

                    echo '<td><input type="text" name="client_nameSelect'.$res["ticket_id"].'" value="'.$res["client_name"].'"></td>';
                    //textbox control for 'client_name'

                    echo '<td><input type="text" name="employee_numberSelect'.$res["ticket_id"].'" value="'.$res["employee_number"].'"></td>';
                    //textbox control for 'employee_number'

                    echo "<td>".$res['concern']."</td>";            //client concern - static
                    //text display for 'concern'

                    outputSelect("job_description",$res["job_description"],$res["ticket_id"],array("","Service","Connection","Setup","Training","Install"));
                    //select control for 'job_description'

                    outputSelect("participation",$res["participation"],$res["ticket_id"],array("","Supervised","Performed"));
                    //select control for 'participation'

                    $selectString ='<td><select style="height:20;" name="approval_statusSelect'.$res["ticket_id"].'">
                            <option value="Not Approved" ';
                    if($res["approval_status"] == "Not Approved"){
                        $selectString.="selected";
                    } 
                    $selectString.='>Not Approved</option>
                            <option value="Approved" ';                        
                    if($res["approval_status"] == "Approved"){
                        $selectString.="selected";
                    } 
                    $selectString.='>Approved</option>
                        </select></td>';                   
                    echo $selectString;

                    $selectString ='<td><select style="height:20;" name="respondentSelect'.$res["ticket_id"].'">';//start of select for respondent
                    $arrayOptions = array("", "tech1", "tech2", "tech3");       //initialization of array for select options
                    foreach($arrayOptions as $value){                           //loop iterating through arrayOptions
                        $selectString .='<option value="';                          //start of option1
                        $selectString .=$value.'"';                             //value of option1 - can be empty, and thus can be saved to the db as empty
                            if($res["respondent"] == $value){                   //check for equality between option value and stored value
                                $selectString.="selected";}                     //if true, add 'selected' property to option
                        if($value == ""){                                       //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
                            $selectString.='>No respondent selected</option>';}   
                        else{
                            $selectString.='>'.$value.'</option>';}             //end of option
                    }
                    $selectString.='</select></td>';                            //end of select             
                    echo $selectString;                                         //outputs select to html

                   
                    outputSelect("job_status",$res["job_status"],$res['ticket_id'],array('Open','Accepted','Completed','Escalated','Not Serviced','Next Day')); //select control for 'job_status'
                    
                    echo '<td><textarea style="color:black;resize:none;" value="'.$res["remarks"].'" name="remarksSelect'.$res["ticket_id"].'"></textarea></td>
                    ';//textarea control for 'remarks'

                    echo "<td>".$res['time_elapsed']."</td>"; //should be a consequence of date_created and current time

            }//end of while loop
                    echo '
                    </table>    <br><br>
                        <center>
                            <input class="btn btn-default" type="submit" name="Submit" value="Save Changes" 
                            style="background-color: #242e39; border-color: black; color:white; padding: 15px; width: 20%;">';
                            //code block closes table

    }//end of displayAdmin function
        
        ?>
            </center>
        <br><br><br><br>
    </form>
    <!--<input class="btn btn-default" type="submit" name="Submit" value="Save">-->
</div>]


<script>
</script>


</body>
</html>