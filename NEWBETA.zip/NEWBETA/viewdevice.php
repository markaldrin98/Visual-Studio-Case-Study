<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>  
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body style="color:white">
<div class="container">
   <br><br><br>
<?php

global $res,$ticketID;
  $device_id='';
  if(checkPost()){
    
  }
  $retrieveDeviceQueryString = "SELECT * FROM device_list WHERE device_id = '".$_SESSION['client_name']."'";
              //echo '<script>console.log("'.$retrieveTicketQueryString.'");</script>';  
  $retrieveTicket = mysqli_query($conn, $retrieveTicketQueryString);
          if(!$retrieveTicket || mysqli_num_rows($retrieveTicket)==0) {//checks to make sure the user has an active ticket - if not, true, display redirect to outstanding.php
          }   
          else{//user exists       
            $ticketCheck = true;
            while($retrieveRes=mysqli_fetch_array($retrieveTicket)){           
              $ticketID=$retrieveRes['current_ticket'];
                if($retrieveRes['current_ticket']==null || $retrieveRes['current_ticket']==''){//user has no active ticket
                  $message = "<center>You do not have an active ticket!";
                  $message .= "<br>Click <a href='outstanding.php'>here</a> to select a new ticket.</center>";
                  $displayMainTable = "display:none";
                  $displayNullMessage = "";
                }
            }
          }  
          $resultQueryString = "SELECT * FROM tickets WHERE ticket_id = '".$ticketID."' ORDER BY date_created AND client_name DESC";//query to select user's active ticket from tickets table
          $result = mysqli_query($conn, $resultQueryString);
          if(!$result || mysqli_num_rows($result)==0) {//tech's active ticket doesn't exist - remove tech's active ticket
              $queryString = 'UPDATE tech_credentials SET current_ticket = NULL WHERE employee_name="'.$_SESSION["client_name"].'"';  
              if (mysqli_query($conn, $queryString)) {
                  $message = "<center>You do not have an active ticket!";
                  $message .= "<br>Click <a href='outstanding.php'>here</a> to select a new ticket.</center>";
                  $displayMainTable = "display:none";
                  $displayNullMessage = "";
              }               
          }   
          else{//record exists
            $res=mysqli_fetch_array($result);
                        /*  Code block checks values of fields relevant to tech UI
                        echo "<script>console.log('".$resultQueryString."');</script>";
                        echo "<script>console.log('Office: ".$res['office']."');</script>";
                        echo "<script>console.log('Client Name: ".$res['client_name']."');</script>";
                        echo "<script>console.log('Employee Number: ".$res['employee_number']."');</script>";
                        echo "<script>console.log('Concern: ".$res['concern']."');</script>";
                        */
          }
?>
  <div class='ticket' style="<?php echo $displayMainTable;?>">
    <p><b>Ticket <?php echo $res['ticket_id'];?></b></p>
    <table style="color:white">

        <tr>
          <td align="right">Office: </td>
          <td align="left">
            <?php
              echo $res['office'];
            ?>
          </td>
        </tr>

        <tr>
          <td align="right">Name: </td>
          <td align="left">
            <?php
              echo $res['client_name'];
            ?>
          </td>
        </tr>

        <tr style="display:none;">
          <td align="right">Employee Number: </td>
          <td align="left">
            <?php
              echo $res['employee_number'];
            ?>
          </td>
        </tr>

        <tr>
        <td align="right">Concern: </td>
          <td align="left">
            <?php
              echo $res['concern'];
            ?>
          </td>
        </tr>

        <tr>
        <td align="right">Concern Details: </td>
          <td align="left">
            <?php
              echo $res['concern_details'];
            ?>
          </td>
        </tr>

        <tr>
            <?php
            $isAssessed = false;
            //--------------------CHANGE THIS BIT TO ALTERNATE BETWEEN QUERYING AGAINST DATE_ACCEPTED AND DATE_ASSESSED-------------------//
            if($res['date_assessed']=='' OR is_null($res['date_assessed'])){
              $queryString = "          
              SELECT TIMESTAMPDIFF(HOUR, (SELECT date_accepted FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_hours,
              TIMESTAMPDIFF(MINUTE, (SELECT date_accepted FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_minutes,
              TIMESTAMPDIFF(SECOND, (SELECT date_accepted FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_seconds
              ";          
              $timerString = "Assessment time: "; 
            }
            else if($res['date_assessed']!=''){
              $queryString = "          
              SELECT TIMESTAMPDIFF(HOUR, (SELECT date_assessed FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_hours,
              TIMESTAMPDIFF(MINUTE, (SELECT date_assessed FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_minutes,
              TIMESTAMPDIFF(SECOND, (SELECT date_assessed FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_seconds
              "; 
              $timerString = "Job time: ";     
              $isAssessed = true;            
            }
            echo '<td align="right">'.$timerString.'</td>';
            //above query retrieves time between the acceptance of the ticket and now(which retrieves server time) on load //also splits the time difference into hours, minutes, and seconds
                                if ($timeResult=mysqli_query($conn, $queryString)) { 
                                  $timeRes=mysqli_fetch_array($timeResult);
                                } 
                                else{
                                  echo mysqli_error($conn);
                                  echo $queryString;
                                }
              echo "<td>";       //echoes base value of time elapsed - updated by JS every second (see persistentClock()
                  echo "<span id='hour_display'>".sprintf('%02d',$timeRes['time_elapsed_hours'])."</span>:";//hour value returned by sql is the current number of hours from stored value to now() //the query returns whole hours, so there's no need to mod (not sure if this would still apply if hours>24)
                  echo "<span id='minute_display'>".sprintf('%02d',($timeRes['time_elapsed_minutes']%60))."</span>:";//minute value returned by sql is the total number of minutes between now() and stored value - modding by 60 drops the full hours and leaves only the minutes short of an hour
                  echo "<span id='second_display'>".sprintf('%02d',($timeRes['time_elapsed_seconds']%60))."</span>";//as above, leaves only the seconds short of a minute
              echo "</td>";
            ?>
        </tr>

    </table>
    <br>
<!--
-->

<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO ASSESS TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
  <form id='finishAssessment' action='finishassessment.php' method='post'><!--form used to finish ticket assessment-->
    <div class="form-group">
        <label>Assessment:</label>
        <?php
          $valueArray = retrieveOptions('assessment',true);
          outputSelect('assessment',$res['assessment'],$valueArray,true);
        ?>
    </div>
    <div class="form-group">
        <label>Job Description:</label>
        <?php
          $valueArray = retrieveOptions('job_description',true);
          outputSelect('job_description',$res['job_description'],$valueArray,true);
        ?>
    </div>
    <div class="form-group">
        <label>Job Details:</label>
        <textarea id="job_details" name="job_details" class="form-control" required></textarea>
    </div>
    <input class="btn btn-default" type="submit" name="Submit" value="Finish Assessment" style="background-color: #242e39; border-color: black; color:white; padding: 15px; width: 200;">
    <?php
      echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";
    ?>
  </form><!--form used to finish ticket assessment-->  
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO ASSESS TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

  <!--HAVE THIS BUTTON ALTERNATE BETWEEN "FINISH ASSESSMENT" AND "FINISH TICKET"-->
  
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO FINISH TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<form id='finishTicket' action='finishactiveticket.php' method='post'><!--form used to finish ticket-->

              <div class="form-group">
                  <label>Assessment:</label>
                  <span id="concern" name="concern" class="form-control"><?php echo $res['assessment'];?></span>
              </div>
              <div class="form-group">
                  <label>Job Description:</label>
                  <span id="concern" name="concern" class="form-control"><?php echo $res['job_description'];?></span>                          
              </div>
              <div class="form-group">
                  <label>Job Details:</label>
                  <span id="concern" name="concern" class="form-control"><?php echo $res['job_details'];?></span>
              </div>

    <input class="btn btn-default" type="submit" name="Submit" value="Finish Ticket" style="background-color: #242e39; border-color: black; color:white; padding: 15px; width: 200;">
    <?php
      echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";
    ?>
</form><!--form used to finish ticket-->
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF FORM USED TO FINISH TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO SET/GET DEVICE INFORMATION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

<?php
if($res['device_id']){  //device is set
  toConsole('device set');
  echo "<div class='container'><!--DIV WILL HOLD INFORMATION ABOUT THE CURRENTLY SET DEVICE-->";
  echo "<p style='font-size:30;'><b>No Device Set ".$res['device_id']."</b></p>";
  echo "</div>";
}
else{  //no device set
  echo "
  <div class='container' style='color:black;' id='set_new_registry_container'><!--DIV WILL HOLD INFORMATION ABOUT THE CURRENTLY SET DEVICE-->
    <p style='font-size:40; color:white;'><b>Device</b></p>
    <form id='setDeviceForm' action='setdevice.php' method='post'>
      <input type='text' name='device_id' id='device_id' placeholder='Enter device ID...' list='deviceList'>";
      retrieveDevices();//initializes combo box with list of all registered devices
  echo "<input type='submit' name='Submit' value='Set Device' id='toggleSetDevice'>
    </form>
    <form id='setDeviceForm' action='registerdevice.php' method='post'>";
    $deviceTypes = retrieveOptions('device_type',true);
    outputSelect('device_type','',$deviceTypes,true);
  echo "<input type='submit' name='Submit' value='Register New Device' id='registerNewDevice'>
    </form>
  </div>";
}
?>


<div id="device_info_container">
<fieldset id="device_parts">
  <legend style="color:white;">Device Parts</legend>
  <ul>
    <?php
      displayArrayValues(retrieveParts($res['device_id']));
    ?>
    <li>
      <form action="newpartspec.php" method="post"><!--form to add new spec to device-->
        <label>Add new part:</label>
        <input type="text" id="new_part" name="new_part" placeholder="New part...">
        <input type="text" name="new_description" placeholder="Part details...">
        <input class="btn btn-default" type="submit" name="Submit" value="Add Part">
      </form>
    </li>
  </ul>
</fieldset>

<fieldset id="device_specs">
  <legend style="color:white;">Device Specifications</legend>
  <ul>
    <?php
      displayArrayValues(retrieveSpecs($res['device_id']));
    ?>
    <li>
      <form action="newpartspec.php" method="post"><!--form to add new spec to device-->
        <label>Add new spec:</label>
        <input type="text" id="new_spec" name="new_spec" placeholder="New specification...">
        <input type="text" name="new_description" placeholder="Specification details...">
        <input class="btn btn-default" type="submit" name="Submit" value="Add Specificaton">
      </form>
    </li>
  </ul>
</fieldset>
</div>
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF FORM USED TO SET/GET DEVICE INFORMATION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->


<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MODULE SWITCHES BETWEEN TECH DISPLAY AND ADMIN DISPLAY~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<?php

if($res['device_id']){  
  echo "<script>document.getElementById('device_info_container').style.display='block';</script>";
  echo "<script>document.getElementById('set_new_registry_container').style.display='none';</script>";
}
else{
  echo "<script>document.getElementById('device_info_container').style.display='none';</script>";
  echo "<script>document.getElementById('set_new_registry_container').style.display='block';</script>";
}
if($isAssessed){//$isAssessed is /true/ when ticket has already been assessed  
    echo "<script>document.getElementById('finishAssessment').style.display='none';";///hides assessment form
    echo "document.getElementById('finishTicket').style.display='block'";//displays assessment values, button to close ticket
    echo "</script>";
}
else{
    echo "<script>document.getElementById('finishAssessment').style.display='block';";///shows assessment form
    echo "document.getElementById('finishTicket').style.display='none'";//hides assessment values, button to close ticket
    echo "</script>";
}
?>
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF MODULE THAT SWITCHES BETWEEN TECH DISPLAY AND ADMIN DISPLAY~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

</div>

    <center>
      <div style="<?php echo $displayNullMessage;?>">
      <?php
        echo $message; 
      ?>
      </div>
      <div id="testdiv"></div>
    </center>


<br>
<br>
<br>
<br>
<br>

</body>
</html>

<!--css-->
<style>
 
body{
    background-color: #384048;
  }
</style>

<script>
  var hours_disp = document.getElementById('hour_display');       //reference to the hours display span to eliminate the need to query the DOM over and over again
  var minutes_disp = document.getElementById('minute_display');   //reference to minutes display
  var seconds_disp = document.getElementById('second_display');   //reference to seconds display

  persistentClock();

  function clockTick(){ //function updates hours, minutes, seconds values
    var hours = parseInt(hours_disp.innerHTML);
    var minutes = parseInt(minutes_disp.innerHTML);
    var seconds = parseInt(seconds_disp.innerHTML);

    seconds++;
    if(seconds==60){
      minutes++;
      seconds=0;
    }
    if(minutes==60){
      hours++;
      minutes=0;
    }
    hours_disp.innerHTML=hours.pad(2);
    minutes_disp.innerHTML=minutes.pad(2);
    seconds_disp.innerHTML=seconds.pad(2);
  }

  function persistentClock(){ //calls the clock update function every second
    setInterval(clockTick, 1000);
  }

  function newInputField(){

  }

</script>