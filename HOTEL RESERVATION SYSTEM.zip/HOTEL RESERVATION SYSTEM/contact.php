<?php include "header.php";?>
<div id="cover">
<div id="content">
<?php global $msg; echo $msg;?>
<br/><h3>Welcome, debermarkos
<br/> fm international hotel</h3><br/>

<img src="images/dmmap.jpg"

align="left">
<img src="images/map.jpg" align="right">
<br><br><br><br><br><br><br><br><br><br>Close to Center of Debre Markos Town
<img src="images/image-slider-2.jpg" width="400"align="right">
<br><br><b><br><br><br><br><br><br><b><br><br><br><br><br><br><b><br><br><br><br>
<p>&nbsp;&nbsp;</p><div>
<?php include "footer.php";?>
</div>
</div>
</div>
