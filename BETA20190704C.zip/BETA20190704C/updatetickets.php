<?php
include_once("misc/config.php");  
echo "<br><br><br><br><br><br><br><br>";  
    if(checkPost("ticket_id")!=false){//checks to see if 'ticket_id' has been posted - if it is not set, then the user accessed this page through unintended channels
    }
    else{
        redirect('index.php');//and should thus be redirected back to the index
    }
    global $conn;
    $ticket_id=checkPost("ticket_id");
    $qString ='SELECT * FROM tickets WHERE ticket_id="'.checkPost("ticket_id").'"';//retrieves ticket with the same id as the id posted
    $result = mysqli_query($conn,$qString);
    $res = mysqli_fetch_array($result);

        $queryString = "UPDATE tickets SET ticket_id='".checkPost("ticket_id")."'";//initializes update query
        $fieldArray = retrieveFields('tickets');//retrieves a list of the fields in the 'tickets' table
        for($counter=0;$counter<count($fieldArray);$counter++){//iterates through each field of the 'tickets' table
            if(checkPost($fieldArray[$counter])!=false){//checks if given current field has a posted value - if it does have a posted value, run this clause
                toConsole($fieldArray[$counter]);//throws values to console for debugging
                toConsole(checkPost($fieldArray[$counter]));//throws values to console for debugging
                if(checkPost($fieldArray[$counter])!=$res[$fieldArray[$counter]]){//checks to make sure posted value has a value that's different from the stored value - this clause should only run if the two values are not equal
                    if($fieldArray[$counter]=='remarks'){//checks to see if program's currently iterating through the 'remarks' column
                        $oldRemark = mysqli_real_escape_string ($conn,$res['remarks']);//escapes stored chat log
                        $currentUser = mysqli_real_escape_string ($conn,callUser());
                        $newRemark = checkPost($fieldArray[$counter]);//formats new remark
                        $newRemark = mysqli_real_escape_string ($conn,$newRemark);//escapes new remark
                        if($oldRemark==''){//code block determines if chat log is empty - if it is, insert a new remark - if it isn't, add new remark to old remark string
                            $queryString.=", ".$fieldArray[$counter]."= CONCAT('".$currentUser."<',now(),'>:".$newRemark."-:-"."')";
                        }
                        else{
                            $queryString.=", ".$fieldArray[$counter]."= CONCAT('".$oldRemark."','".$currentUser."<',now(),'>:".$newRemark."-:-"."')";              
                        }
                    }
                    else if($fieldArray[$counter]=='respondent'){//checks to see if program's currently iterating through the 'respondent' column
                        if(checkTicketOwner($ticket_id)){
                            //redirect("outstanding.php?attempt=failed&ticket_id=$ticket_id");
                        }
                        else{
                            updateTechTicket(checkPost("respondent"),checkPost("ticket_id"));
                        }
                        $queryString.=", ".$fieldArray[$counter]."='".escapeString(checkPost($fieldArray[$counter]))."'";
                    }
                    else{//DEFAULT CLAUSE - FIELD REQUIRES NO SPECIAL LOGIC
                        $queryString.=", ".$fieldArray[$counter]."='".escapeString(checkPost($fieldArray[$counter]))."'";
                    }
                //-------------------CODE BLOCK LOGS CHANGES MADE TO TICKET------------------//   
                $oldValue = $res[$fieldArray[$counter]];
                $newValue = checkPost($fieldArray[$counter]);
                if(!$oldValue){//checks if stored value is null
                    $oldvalue = 'null';
                }
                if(!$newValue){//checks if posted value is null
                    $newValue = 'null';
                }
                $changeString = ucfirst($fieldArray[$counter])." changed from ".$oldValue." to ".$newValue;
                logChange(callUser(),$ticket_id,$changeString);
                }
                //----------------END OF CODE BLOCK LOGS CHANGE MADE TO TICKET--------------//
            }
        }
        $queryString.= " WHERE ticket_id='".checkPost("ticket_id")."'";
        print($queryString);
        if(mysqli_query($conn,$queryString)){//ticket updated, return to outstanding.php
            toConsole("Update success!");
            //var_dump($queryString);
            if($trail=checkPost('trail')){
                redirect($trail);
            }
            else{
                redirect("outstanding.php?attempt=success&ticket_id=$ticket_id&op=update");           
            }
        }
        else{
            toConsole("Update failure!");
            var_dump($queryString);
            checkSQLError();
        }

?>

