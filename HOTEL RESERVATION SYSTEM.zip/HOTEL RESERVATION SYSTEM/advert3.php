<?php include "header.php";?>
<div id="cover">
<div id="content">
<?php global $msg; echo $msg;?>
<h3>Welcome, Advertize page.</h3><br/>
<p><h3>DEBEREMARKOSE FM INTERNATIONAL HOTEL</h3></p>
<?php include "advert3.html";?>
<br>
<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Classic rooms at the debremarkos fm international hotel are unusually spacious, 
<br>
luxuriously furnished and tastefully decorated. Each room offers a comfortable environment <br>
for work or relaxation and features the following facilities and services:<br>

    Luxury Collection King size bed<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Individually controlled air-conditioning
    Two telephone lines<br>
    Computer data port access (The hotel has also introduced internet lease lines to make communication faster and more efficient)
    Flat Screen TV, 42 inch<br>
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Electronic mini-bar and private electronic safe
    Large and practical work desk<br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Luxury Collection bathroom amenities, towels, slippers, bathrobes, hair dryer and weigh scale
    Speakers in the bathrooms<br>
    Bottled water provided daily
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Complimentary morning coffee or tea served up to 8:30 AM upon request  with wake up call
    Fruit basket delivered upon request
 
</p>
<p>&nbsp;&nbsp;</p>
<div>
<?php include "footer.php";?>
</div>

</div>
</div>

