<?php 
error_reporting(0);
include "admin_auth.php";
session_start();
include "admin_header.php";?>
<div id="cover">
<div id="content">
<h4>Hellow,&nbsp;<?php echo $_SESSION['SESS_NAME'] ;?><br /></h4>
<br/><h3>Students:</h3>
  <div id="login">
<?php
include "view.php";
include'connection.php';
	
?>

<h3>Login users:</h3>

</div>
</div>
<?php include "footer.php";?>
