
<!DOCTYPE html>
<html lang="en">
<head>
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/loginstyle.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
</head>

  <?php


//------------------------------------FUNCTION CHECKS IF PARAMETER IS PRESENT IN $_GET ARRAY----------------------------------------//
function checkGet($parameterToCheck){
    if(isset($_GET[$parameterToCheck]) && $_GET[$parameterToCheck]!=''){
      //toConsole($parameterToCheck.' present: '.$_GET[$parameterToCheck]);
      return($_GET[$parameterToCheck]);       //parameter is present, return value
    }
    else{
      //toConsole($parameterToCheck.' absent');
      return(false);                           //parameter is absent, return false
    }
}
//-------------------------------END OF FUNCTION TO CHECK IF PARAMETER IS PRESENT IN $_GET ARRAY------------------------------------//

//echo $_SESSION['loggedin'];
    if(isset($_GET['op']) && $_GET['op'] == 'add'){
      echo "<h1>Registration successful! <br>Welcome, ".$_SESSION['username']."</h1>";
    }
    else if(isset($_GET['op']) && $_GET['op'] == 'login'){
      echo "<h1>Welcome, ".$_SESSION['username']."</h1>";
    }
    else{
      echo "
<form class='login100-form validate-form' action='checkcredentials.php' method='post'>
    <div class='limiter'>
        <div class='container-login100'>
            <div class='wrap-login100'>
                <div class='form-wrapper'>
                    <span class='login100-form-title p-b-48'>
                  <div class='container'>
                    <center>
                        <img src='img/taoanguna.png' style='width: 50%;'> 
                    </center> 
                  </div>
                    </span>
                    <span class='login100-form-title p-b-48'>
                    Log In
                    </span>";    
      if(checkGet('attempt')=="failed"){
        echo "<center><span style='color:red;'>Log-In attempt failed!<br>Incorrect username and/or password.</span></center><br>";
      }
      echo"  <div class='field'>
            <input type='text' required autocomplete='off' id='username' required name='username' class='form-control' autofocus>
            <label for='username' title='Username' data-title='Username'></label>
        </div>        
        <div class='field'>
            <input type='Password' id='password' required name='password' class='form-control'>
            <label for='password' title='Password' data-title='Password'></label>
        </div>
  <div class='container-login100-form-btn'>
                      <div class='wrap-login100-form-btn'>             
                          <input type='submit' value='Log In' name='Submit' id='Submit' class='login100-form-btn'>
                      </div>
                      </form>
                  <form action='index.php' method='post'>
                      <div class='wrap-login100-form-btn'>             
                          <input type='submit' value='Back' name='Submit' id='Submit' class='login100-form-btn'>
                      </div>
                  </form>
                  </div>
              
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

";
    }
  ?>
</div>
</center>

<br>
<br>
<br>
<br>

</body>
</html>
