<body onload="loadingScreen()">
<img src="img/taoanguna.png" id="loader">
<div style="display:none;" id="myDiv" class="animate-bottom">

<?php include 'misc/config.php';?>
<script src="misc/sorttable.js"></script>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/outstandingstyle.css">
  <link rel="stylesheet" type="text/css" href="css/darkmode.css">
   <link rel="stylesheet" type="text/css" href="css/fontStyle.css">
  </head>
<body>
	<?php
		if(checkGet('attempt')=="failed" && checkGet('ticket_id')){
			sendAlert("Error - ticket ".checkGet('ticket_id')." has already been assigned to a tech.");
		}
		else if(checkGet('attempt')=="success" && checkGet('ticket_id') && checkGet('op')=='update'){
			sendAlert("Ticket ".checkGet('ticket_id')." was successfully updated.");
		}
	?>
    <?php include 'ticketmodule.php';?>
</body>
</div>
<script></script>
</html>