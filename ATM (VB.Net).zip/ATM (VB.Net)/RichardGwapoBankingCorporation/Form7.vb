﻿Imports System.Data.OleDb

Public Class Form7
    Dim con As OleDbConnection
    Dim ds As New DataSet
    Dim da As New OleDbDataAdapter
    Dim sql As String
    Dim constring As String
    Dim path As String

    Private Sub Form7_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" &
                Application.StartupPath & "\dbCustomerAcct.mdb")

    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub


    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
       
        If String.IsNullOrEmpty(TextBox1.Text) Then

            MessageBox.Show("Please Fill up all The Forms before Register!", _
                "Important Note", _
                MessageBoxButtons.OK, _
                MessageBoxIcon.Exclamation, _
                MessageBoxDefaultButton.Button1)


        ElseIf String.IsNullOrEmpty(TextBox2.Text) Then
            MessageBox.Show("Please Fill up all The Forms before Register!", _
                       "Important Note", _
                       MessageBoxButtons.OK, _
                       MessageBoxIcon.Exclamation, _
                       MessageBoxDefaultButton.Button1)

        ElseIf String.IsNullOrEmpty(TextBox3.Text) Then
            MessageBox.Show("Please Fill up all The Forms before Register!", _
                           "Important Note", _
                           MessageBoxButtons.OK, _
                           MessageBoxIcon.Exclamation, _
                           MessageBoxDefaultButton.Button1)
        Else
            registerdata()
            MessageBox.Show("Your Account name is: " & TextBox3.Text & vbCrLf &
                            "Your Account number is: " & TextBox2.Text & vbCrLf & "and Your Pin number is: " & TextBox1.Text, _
    "You are now registered!")

        End If

    End Sub

    Private Sub registerdata()
        Try
            If con.State = ConnectionState.closed Then
                con.Open()

            End If


            If TextBox1.Text <> "" And TextBox2.Text <> "" And TextBox3.Text <> "" Then
                sql = "insert into tblCustomerInfo ([pinnum], [acctnum], [custname])" & "values(?,?,?)"

                Dim cmd As OleDbCommand = New OleDbCommand(sql, con)
                cmd.Parameters.Add(New OleDbParameter("pinnum", CType(TextBox1.Text, String)))
                cmd.Parameters.Add(New OleDbParameter("acctnum", CType(TextBox2.Text, String)))
                cmd.Parameters.Add(New OleDbParameter("custname", CType(TextBox3.Text, String)))

                Try
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    con.Close()
      
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                End Try

            End If


        Catch ex As Exception
            MessageBox.Show(ex.ToString)

        End Try
    End Sub

    Private Sub AcctnumTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Hide()
        Form8.Show()

    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub CustnameLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub AcctnumLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PinnumLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class