<?php include 'misc/config.php';?>
<?php
if(isset($_POST['Submit'])) {//checks if ticket was submitted
    //printPost();
    //input fields for ticket creation


    if(checkPost('employeenumber')){
        $employeenumber=mysqli_real_escape_string($conn,$_POST['employeenumber']);
    }
    else{
        $employeenumber="Not Applicable - JO"; 
    }
    $employeename=mysqli_real_escape_string($conn,$_POST['employeename']);
    $office=mysqli_real_escape_string($conn,$_POST['office']);
    $concern=mysqli_real_escape_string($conn,$_POST['concern']);
    $concern_details=mysqli_real_escape_string($conn,$_POST['concern_details']);
    //input fields for ticket creation

    $idQuery="SELECT MAX(RIGHT(LEFT(ticket_id, 10),3)) AS 'maxim' FROM tickets WHERE ticket_id LIKE '".date('ymd')."-%'";
    $idResult = mysqli_query($conn,$idQuery);
        if(!$idResult || mysqli_num_rows($idResult)==0) {//no appropriate records are extant
            toConsole('No records for the current day');
            $idQuery=date('ymd')."-001";
        }
        else{
            $idRes = mysqli_fetch_array($idResult);
            toConsole('Retrieved '.$idRes["maxim"]);
            $idQuery=date('ymd')."-".sprintf('%03d',(intval($idRes['maxim'])+1));
        }

        $queryString = 'INSERT INTO tickets (ticket_id,employee_number,client_name,office,concern,concern_details,approval_status,job_status) VALUES ("'.$idQuery.'","'.$employeenumber.'","'.$employeename.'","'.$office.'","'.$concern.'","'.$concern_details.'","Not Approved","Open");'; //query string to create entry in the ticket table - probs more efficient to just use joins for the extra details
           if (mysqli_query($conn, $queryString)) {
            //echo $qString;    
                $logString=mysqli_real_escape_string($conn,"Ticket created with the following parameters: ".$employeenumber.",".$employeename.",".$office.",".$concern." - ").$concern_details;
                logChange($employeename, $idQuery, $logString);
                redirect('ticketcreated.php?ticket='.$idQuery);
            } 
            else {    //report sql error
                echo mysqli_error($conn);
            }
}
else{
    redirect('index.php');
}
                  
?>

