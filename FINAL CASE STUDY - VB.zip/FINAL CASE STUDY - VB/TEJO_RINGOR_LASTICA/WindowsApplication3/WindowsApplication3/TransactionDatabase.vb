﻿Imports System.Data.OleDb

Public Class TransactionDatabaseForm
    Dim conn As OleDb.OleDbConnection
    Dim da As OleDb.OleDbDataAdapter
    Dim dt As DataTable
    Dim cmd As OleDbCommand
    Dim dbdata As OleDbDataReader
    Dim index As Integer


    ReadOnly CONNECTION_STRING As String = "Provider=microsoft.Jet.oledb.4.0; Data Source=" & _
                                    Application.StartupPath.Replace("\bin\Debug", String.Empty) & _
                                    "\Database2.mdb;"

    Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dbase()
        Dim sum As Integer
        Dim count As Integer = 0



      
        DataGridView1.Columns(1).Visible = False
        DataGridView1.Columns(0).Width = 50

        DataGridView1.Columns(2).Width = 150
        DataGridView1.Columns(3).Width = 120
        DataGridView1.Columns(5).Width = 120
        DataGridView1.Columns(6).Width = 120

        DataGridView1.Columns(7).Width = 70
        DataGridView1.Columns(8).Width = 80
        DataGridView1.Columns(9).Width = 170
        DataGridView1.Columns(10).Width = 110


        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""
        DateTimePicker1.Format = DateTimePickerFormat.Custom
        DateTimePicker1.CustomFormat = "MMMM dd, yyyy"

        DateTimePicker2.Format = DateTimePickerFormat.Custom
        DateTimePicker2.CustomFormat = "MMMM dd, yyyy"

        DateTimePicker1.Visible = False
        DateTimePicker2.Visible = False
        Me.WindowState = FormWindowState.Maximized

    End Sub

    Public Sub dbase()
        Dim conn As New OleDbConnection(CONNECTION_STRING)

        'dispData()
        conn.Open()
        Dim com As String = "Select * from OrderDatabase"
        Dim da As New OleDbDataAdapter(com, conn)
        Dim ds As New DataSet()
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)

    End Sub


    Public Sub dispData()
        Dim conn As New OleDbConnection("Provider=microsoft.Jet.oledb.4.0; Data Source=" & _
                                 Application.StartupPath & "\Database2.mdb;")

        conn.Open()
        cmd = New OleDbCommand
        cmd.Connection = conn
        cmd.CommandText = "INSERT INTO OrderDatabase(TransactionID , CustomersName, TotalAmount, TotalItems, TypeOfOrder, VatAmount, Money, Change) "


        cmd.ExecuteNonQuery()
        conn.Close()





    End Sub


    Private Sub DataGridView1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        index = e.RowIndex

        Dim selectedRow As DataGridViewRow

        If (e.RowIndex = -1) Then
            Return
        End If

        selectedRow = DataGridView1.Rows(index)
        TextBox8.Text = selectedRow.Cells(0).Value.ToString()
        TextBox2.Text = selectedRow.Cells(2).Value.ToString()
        TextBox4.Text = selectedRow.Cells(3).Value.ToString()
        TextBox11.Text = selectedRow.Cells(4).Value.ToString()
        ComboBox3.Text = selectedRow.Cells(5).Value.ToString()
        TextBox9.Text = selectedRow.Cells(6).Value.ToString()
        TextBox1.Text = selectedRow.Cells(7).Value.ToString()
        TextBox6.Text = selectedRow.Cells(8).Value.ToString()
        TextBox3.Text = selectedRow.Cells(9).Value.ToString()
        TextBox5.Text = selectedRow.Cells(10).Value.ToString()



    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        TransactionForm.Show()
        Me.Hide()

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Close()
    End Sub

    Private Sub DataGridView1_ColumnHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.ColumnHeaderMouseClick
    End Sub

    Private Sub ComboBox3_DrawItem(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles ComboBox3.DrawItem
        e.DrawBackground()
        Dim txt As String = ""
        If e.Index >= 0 Then txt = (e.Index).ToString
        TextRenderer.DrawText(e.Graphics, txt, e.Font, e.Bounds, e.ForeColor, TextFormatFlags.HorizontalCenter)
        e.DrawFocusRectangle()
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged

    End Sub
    Public Class CenteredComboBox
        Inherits ComboBox
        Sub New()
            Me.DrawMode = Windows.Forms.DrawMode.OwnerDrawFixed
            Me.DropDownStyle = ComboBoxStyle.DropDownList
        End Sub
    End Class

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub
    Function GetOrderByDate(ByVal fromDate As Date, ByVal toDate As Date) As DataTable
        Dim result As New DataTable
        Dim connectionString = "you connection string"
        Using cn As New OleDbConnection(CONNECTION_STRING)
            Dim sql As String = "SELECT * FROM OrderDatabase WHERE Date BETWEEN @toDate AND @fromDate"
            Using da As New OleDbDataAdapter(sql, cn)

                With da.SelectCommand.Parameters
                    .AddWithValue("@fromDate", DateTimePicker2.Text)
                    .AddWithValue("@toDate", DateTimePicker1.Text)
                End With
                da.Fill(result)
            End Using
        End Using
        Return result
    End Function

 
    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

        DataGridView1.ReadOnly = True
        If ComboBox1.SelectedIndex = 0 Then
            dbase()
            total()
        Return
        ElseIf ComboBox1.SelectedIndex = 1 Then

            DateTimePicker1.Value = Today
            DateTimePicker2.Value = DateTimePicker1.Value
            DataGridView1.DataSource = GetOrderByDate(CDate(DateTimePicker1.Value), CDate(DateTimePicker2.Value))
            total()

        ElseIf ComboBox1.SelectedIndex = 2 Then
            DateTimePicker1.Value = Today
            DateTimePicker2.Value = DateAdd(DateInterval.Weekday, -7, DateTimePicker1.Value)
            DataGridView1.DataSource = GetOrderByDate(CDate(DateTimePicker1.Value), CDate(DateTimePicker2.Value))
            total()
        ElseIf ComboBox1.SelectedIndex = 3 Then
            DateTimePicker1.Value = Today
            DateTimePicker2.Value = DateAdd(DateInterval.Weekday, -10, DateTimePicker1.Value)
            DataGridView1.DataSource = GetOrderByDate(CDate(DateTimePicker1.Value), CDate(DateTimePicker2.Value))
            total()
        End If
    End Sub
    Public Sub total()
        Dim sum As Integer
        Dim count As Integer = 0

        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""

    End Sub

    Private Sub DateTimePicker1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePicker1.ValueChanged
        '        Dim conn As New OleDbConnection(CONNECTION_STRING)
        '        Dim sdf As New OleDbDataAdapter("SELECT * FROM OrderDatabase WHERE Date BETWEEN '" + DateTimePicker1.Value.ToString() + "' and '" + DateTimePicker2.Value.ToString() + "'", conn)
        '        Dim sd As New DataTable
        '        sdf.Fill(sd)
        '        DataGridView1.DataSource = sd

    End Sub

    Private Sub TextBox7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox7.TextChanged
        If ComboBox2.SelectedIndex = 0 Then
            searchID()
        ElseIf ComboBox2.SelectedIndex = 1 Then
            searchCustomersName()
        ElseIf ComboBox2.SelectedIndex = 2 Then
            searchTotalAmount()
        ElseIf ComboBox2.SelectedIndex = 3 Then
            searchTotalItems()
        ElseIf ComboBox2.SelectedIndex = 4 Then
            searchTypeOfOrder()
        ElseIf ComboBox2.SelectedIndex = 5 Then
            searchVatAmount()
        ElseIf ComboBox2.SelectedIndex = 6 Then
            searchMoney()
        ElseIf ComboBox2.SelectedIndex = 7 Then
            searchChange()
        ElseIf ComboBox2.SelectedIndex = 8 Then
            searchDate()
        ElseIf ComboBox2.SelectedIndex = 9 Then
            searchTime()

        End If

    
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox2.SelectedIndexChanged
        If ComboBox2.SelectedIndex = 0 Then
        End If
    End Sub

    Public Sub searchID()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim ds As New DataSet
        Dim sum As Integer
        Dim count As Integer = 0

        'dispData()
        conn.Open()
        da = New OleDbDataAdapter("select * from orderdatabase where ID like '%" & TextBox7.Text & "%'", conn)
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""

    End Sub
    Public Sub searchCustomersName()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim ds As New DataSet
        Dim sum As Integer
        Dim count As Integer = 0

        'dispData()
        conn.Open()
        da = New OleDbDataAdapter("select * from orderdatabase where CustomersName like '%" & TextBox7.Text & "%'", conn)
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""

    End Sub
    Public Sub searchTotalAmount()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim ds As New DataSet
        Dim sum As Integer
        Dim count As Integer = 0
        conn.Open()
        da = New OleDbDataAdapter("select * from orderdatabase where TotalAmount like '%" & TextBox7.Text & "%'", conn)
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""
    End Sub

    Public Sub searchTotalItems()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim ds As New DataSet
        Dim sum As Integer
        Dim count As Integer = 0
        conn.Open()
        da = New OleDbDataAdapter("select * from orderdatabase where TotalItems like '%" & TextBox7.Text & "%'", conn)
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""
    End Sub

    Public Sub searchTypeOfOrder()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim ds As New DataSet
        Dim sum As Integer
        Dim count As Integer = 0
        conn.Open()
        da = New OleDbDataAdapter("select * from orderdatabase where TypeOfOrder like '%" & TextBox7.Text & "%'", conn)
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""
    End Sub
    Public Sub searchVatAmount()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim ds As New DataSet
        Dim sum As Integer
        Dim count As Integer = 0
        conn.Open()
        da = New OleDbDataAdapter("select * from orderdatabase where vatAmount like '%" & TextBox7.Text & "%'", conn)
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""
    End Sub

    Public Sub searchMoney()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim ds As New DataSet
        Dim sum As Integer
        Dim count As Integer = 0
        conn.Open()
        da = New OleDbDataAdapter("select * from orderdatabase where Money like '%" & TextBox7.Text & "%'", conn)
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""
    End Sub

    Public Sub searchChange()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim ds As New DataSet
        Dim sum As Integer
        Dim count As Integer = 0
        conn.Open()
        da = New OleDbDataAdapter("select * from orderdatabase where Change like '%" & TextBox7.Text & "%'", conn)
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""
    End Sub

    Public Sub searchDate()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim ds As New DataSet
        Dim sum As Integer
        Dim count As Integer = 0
        conn.Open()
        da = New OleDbDataAdapter("select * from orderdatabase where date like '%" & TextBox7.Text & "%'", conn)
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""
    End Sub

    Public Sub searchTime()
        Dim conn As New OleDbConnection(CONNECTION_STRING)
        Dim ds As New DataSet
        Dim sum As Integer
        Dim count As Integer = 0
        conn.Open()
        da = New OleDbDataAdapter("select * from orderdatabase where Time like '%" & TextBox7.Text & "%'", conn)
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView1.ReadOnly = True
        For i As Integer = 0 To DataGridView1.Rows.Count() - 1 Step +1
            sum = sum + DataGridView1.Rows(i).Cells(3).Value
        Next
        Label4.Text = "Total Amount: " + sum.ToString()

        count = DataGridView1.Rows.Count - 1
        Label5.Text = "Total Customer: " & count & ""
    End Sub

End Class