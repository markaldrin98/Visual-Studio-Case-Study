<?php
include_once("misc/config.php");  
echo "<br><br><br><br><br><br><br><br>";  

$ticketID = $_POST["ticket_id"];

$assessmentCheck = false;   //gate variable

if(isset($_POST['Submit']) && $_POST['Submit']!=''){//if clause checks to make sure user arrived on this page through the intended channel
    //below code block sets date_assessed in the 'tickets' table
    if(checkPost('job_description')){

    }
    $queryString = 'UPDATE tickets SET date_assessed=now(), job_description="'.checkPost("job_description").'", assessment="'.checkPost("assessment").'", job_details="'.checkPost("job_details").'" WHERE ticket_id="'.$ticketID.'"';  
                   if (mysqli_query($conn, $queryString)) { //query passes, gate is cleared
                        echo "<script>console.log('"."Gate check clear"."')</script>";
                        $assessmentCheck = true;
                    } 
                    else {    //report sql error
                        echo '<script>console.log("Check - '.mysqli_error($conn).'");</script>';
                        echo "<script>console.log('".$queryString."')</script>";
                    }
    //end of code block
    if($assessmentCheck){   //checks gate variable - if gate variable returns true, redirect to outstanding.php
        toConsole("Redirecting to outstanding");
        redirect('outstanding.php');
    }
    else{   //else do nothing
        toConsole("Doing nothing");
    }
}//end of if clause
else{//user /did not/ arrive on this page through the intended channel, redirect to ticket creation
    redirect("index.php");
}
?>

