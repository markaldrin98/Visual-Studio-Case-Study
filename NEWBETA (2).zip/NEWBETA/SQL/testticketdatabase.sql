-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2019 at 09:34 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `testticketdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `tech_credentials`
--

CREATE TABLE IF NOT EXISTS `tech_credentials` (
  `employee_name` text NOT NULL,
  `user_type` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `current_ticket` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tech_credentials`
--

INSERT INTO `tech_credentials` (`employee_name`, `user_type`, `username`, `password`, `current_ticket`) VALUES
('Rizza Joy Batuyong', 'admin', 'ririjoy', 'password', 0),
('tech1', 'tech', 'tech1username', 'password', 0),
('tech2', 'tech', 'tech2username', 'password', 0),
('tech3', 'tech', 'tech3username', 'password', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE IF NOT EXISTS `tickets` (
  `ticket_id` int(11) NOT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_accepted` datetime DEFAULT NULL,
  `date_fulfilled` datetime DEFAULT NULL,
  `office` text,
  `client_name` text,
  `employee_number` int(11) DEFAULT NULL,
  `concern` text,
  `job_description` text,
  `participation` text,
  `approval_status` text,
  `respondent` text,
  `job_status` text,
  `remarks` text,
  `time_elapsed` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`ticket_id`, `date_created`, `date_accepted`, `date_fulfilled`, `office`, `client_name`, `employee_number`, `concern`, `job_description`, `participation`, `approval_status`, `respondent`, `job_status`, `remarks`, `time_elapsed`) VALUES
(1, '2019-04-25 10:28:54', NULL, NULL, 'LVE', '', 445544, 'Burning Tower', NULL, NULL, 'Not Approved', NULL, NULL, NULL, NULL),
(2, '2019-04-25 14:50:10', NULL, NULL, 'MTHD', '', 4478, 'Random beeping noises coming from CPU', NULL, NULL, 'Not Approved', NULL, 'Open', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_changelog`
--

CREATE TABLE IF NOT EXISTS `ticket_changelog` (
  `log_number` int(11) NOT NULL,
  `date_time_logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin` text NOT NULL,
  `ticket` int(11) NOT NULL,
  `change_made` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket_changelog`
--

INSERT INTO `ticket_changelog` (`log_number`, `date_time_logged`, `admin`, `ticket`, `change_made`) VALUES
(1, '2019-04-25 07:18:33', 'Rizza Joy Batuyong', 1, 'Changed Office from LVEEE to LVE'),
(2, '2019-04-25 07:24:50', 'Rizza Joy Batuyong', 1, 'Changed Client Name from  to '),
(3, '2019-04-25 07:24:50', 'Rizza Joy Batuyong', 2, 'Changed Client Name from  to ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`), ADD KEY `ticket_id` (`ticket_id`), ADD KEY `ticket_id_2` (`ticket_id`), ADD KEY `ticket_id_3` (`ticket_id`);

--
-- Indexes for table `ticket_changelog`
--
ALTER TABLE `ticket_changelog`
  ADD PRIMARY KEY (`log_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `ticket_changelog`
--
ALTER TABLE `ticket_changelog`
  MODIFY `log_number` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
