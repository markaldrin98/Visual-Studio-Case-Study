
<?php 
error_reporting(0);
include "jscarousel.html";?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link href="images/DMU.jpg" rel="icon" type="image">
<link href="css/hotel.css" type="text/css" rel="stylesheet" />
<title>Home</title>
<script src="jscript/gen_validatorv4.js" type="text/javascript"></script>
</head>

<body>
<div id="head">
<table border="0" bgcolor="#FFFFFF"width="100%"><tr>
        <td><img src="images/logo1.jpg" height="100" width="910" alt="logo"/></td>
        <td><marquee><img src="images/GLOVE.jpg" height="100" width="910" alt="logo"/></marquee></td>
      </td>
</tr></table>
</div>
<div id="leftnavigation">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="adminindex.php">Admin</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="customer_reg.php">Customer</a>&nbsp;&nbsp;<a href="Advertize.php">Advertise</a>&nbsp;&nbsp;<a href="about.php">About Us</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="contact.php">Location</a>
</div>
