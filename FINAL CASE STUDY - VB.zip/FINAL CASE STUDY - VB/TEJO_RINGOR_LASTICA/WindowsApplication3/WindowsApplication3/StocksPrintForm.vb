﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Public Class StocksPrintForm

    Private Sub StocksPrintForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim rptDoc As ReportDocument

        rptDoc = New CrystalReport2
        Dim Report1 As New CrystalReport2

        CrystalReportViewer1.ReportSource = rptDoc
        CrystalReportViewer1.Refresh()

        Report1.SetParameterValue("Try", StocksForm.TextBox1.Text)
        Report1.SetParameterValue("Name", StocksForm.TextBox2.Text)
        Report1.SetParameterValue("Stocks", StocksForm.TextBox3.Text)



        CrystalReportViewer1.ReportSource = Report1
        CrystalReportViewer1.ParameterFieldInfo = Report1.ParameterFields

        Me.WindowState = FormWindowState.Maximized

    End Sub
End Class