<?php include 'misc/config.php';?>
<?php
if(checkPost('Submit')) {//checks if device_id is set
    $target = '';
    $field = '';
    $device_id = checkPost('device_id');
    $type = checkPost('type');
    $item = checkPost('item');
    $detail = checkPost('detail');
    $redirect = checkPost('trail');
    //printPost();

    if($type == 'Part'){
        $target = 'device_parts_table';
        $type = 'part';
    }
    else if($type == 'Spec'){
        $target = 'device_specs_table';
        $type = 'specification';
    }
    else{//'type' was not posted - something went very wrong
        redirect('index.php');
    }
    $deleteQuery = "DELETE FROM ".$target." WHERE (device_id = '$device_id' AND $type = '$item' AND details = '$detail')";
    echo $deleteQuery;
    echo "<br><br><br><br><br>";
    if(mysqli_query($conn, $deleteQuery)) {
        echo "Query successful";
        if($redirect){
            toConsole("Redirecting to : ".$redirect);
            $logString = "Deleted ".$type.": ".$item." - ".$detail;
            logDeviceChange(callUser(),$device_id,$logString);
            redirect($redirect."?device_id=".$device_id);
        }   
    } 
    else{
        echo "Query failure";
    }
}
else{
    toConsole("Form not submitted");
    //redirect('index.php');
}
                  
?>

