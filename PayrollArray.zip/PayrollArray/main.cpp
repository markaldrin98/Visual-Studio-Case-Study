#include <iostream>
using namespace std;
int main(){

	string Name, Address, Age, Position; 
	int rate, day, absent, overtime;
		
	cout<<"Welcome to Payroll System!";
	
	cout<<"\n\nEnter Employee's Name\t: ";
	getline(cin, Name);
	
	cout<<"\n\nEnter Employee's Address\t: ";
	getline(cin, Address);
	
	cout<<"\n\nEnter Employee's Age\t: ";
	getline(cin, Age);
	
	cout<<"Enter Employee's Position\t: ";
	getline(cin, Position);
	
	cout<<"Enter Employee's Salary per hour\t: ";
	cin>>rate;
	
	cout<<"Enter Employee's Working hours\t: ";
	cin>>day;
	
	cout<<"Enter Employee's Induction Gross due Overtime\t: ";
	cin>>overtime;
	
	cout<<"Enter Employee's Deduction due Absences\t: ";
	cin>>absent;
	
	cout<<"\n\n******* EMPLOYEE RECORD NUMBER ******* ";
	cout<<"\n\n";
	
	string str[4];
	str[0] = Name;
	str[1] = Address;
	str[2] = Age;
	str[3] = Position;
	
	int intgr[4];
	intgr[0] = ((overtime) + (rate*day) - (absent));
	intgr[1] = day;
	intgr[2] = absent;
	intgr[3] = overtime;
	
  for(int i = 0; i < 4; i++) {
    cout << str[i] << "\n";
  }
  
  for(int i = 0; i < 4; i++) {
    cout << intgr[i] << "\n";
  }
  	
	cout<<"\n\n\t------------------";
	
	return 0;
}
