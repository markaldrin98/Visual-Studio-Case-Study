﻿Imports System.Data.OleDb
Public Class Form5

    Dim conn As OleDbConnection
    Dim cmd As OleDbCommand
    Dim reader As OleDbDataReader
    Dim CurrentBalance As Double = 0
    Dim withdraw As Double = 0
    Dim NewBalance As Double = 0

    Private Sub Form5_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" &
                Application.StartupPath & "\dbCustomerAcct.mdb")
    End Sub

    Private Sub RadioButton1_Click(sender As System.Object, e As System.EventArgs) Handles RadioButton1.Click

        TextBox1.Enabled = False
        TextBox1.Text = 20000

    End Sub

    Private Sub RadioButton2_Click(sender As System.Object, e As System.EventArgs) Handles RadioButton2.Click

        TextBox1.Enabled = False
        TextBox1.Text = 15000

    End Sub

    Private Sub RadioButton3_Click(sender As System.Object, e As System.EventArgs) Handles RadioButton3.Click

        TextBox1.Enabled = False
        TextBox1.Text = 10000

    End Sub

    Private Sub RadioButton4_Click(sender As System.Object, e As System.EventArgs) Handles RadioButton4.Click

        TextBox1.Enabled = False
        TextBox1.Text = 5000

    End Sub

    Private Sub RadioButton5_Click(sender As System.Object, e As System.EventArgs) Handles RadioButton5.Click

        TextBox1.Clear()
        TextBox1.Enabled = True
        TextBox1.Focus()

    End Sub

    Private Sub TextBox1_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress

        If Char.IsDigit(e.KeyChar) = False And Char.IsControl(e.KeyChar) = False And e.KeyChar <> "." Then

            e.Handled = True

        Else

            If TextBox1.Text.Contains(".") Then

                If e.KeyChar = "." Then

                    e.Handled = True

                End If

            End If

        End If

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        If Double.Parse(TextBox1.Text) > 20000 Then

            MessageBox.Show("Maximum Amount To Be Withdrawn Is 20,000.00", "Withdrawal", MessageBoxButtons.OK, MessageBoxIcon.None)

        ElseIf Double.Parse(TextBox1.Text) < 100 Then

            MessageBox.Show("Minimum Amount To Be Withdrawn Is 100.00", "Withdrawal", MessageBoxButtons.OK, MessageBoxIcon.None)

        Else

            If (Double.Parse(TextBox1.Text) Mod 100 = 0) Then

                conn.Open()
                cmd = New OleDbCommand()
                cmd.Connection = conn
                cmd.CommandText = "Select * from tblCustomerInfo where acctnum = '" & Form2.acctnum & "'"

                reader = cmd.ExecuteReader()

                While (reader.Read())

                    CurrentBalance = Double.Parse(reader("balance").ToString())
                End While

                conn.Close()

                withdraw = Double.Parse(TextBox1.Text)

                If CurrentBalance < withdraw Then

                    MessageBox.Show("Insufficient Fund", "Withdrawal", MessageBoxButtons.OK, MessageBoxIcon.None)

                Else

                    NewBalance = CurrentBalance - withdraw

                    conn.Open()
                    cmd = New OleDbCommand()
                    cmd.Connection = conn
                    cmd.CommandText = "Update tblCustomerInfo Set balance = balance - " & withdraw & " where acctnum = '" & Form2.acctnum & "'"
                    cmd.ExecuteNonQuery()

                    MessageBox.Show("Account Number: " & Form2.acctnum & vbNewLine &
                    "Account Name: " & Form2.acctname & vbNewLine & "Withdrawn Amount: " &
                    withdraw.ToString("0,0.00") & vbNewLine & "Balance: " & NewBalance.ToString("0,0.00") & vbNewLine &
                    "Date/Time: " & DateTime.Now.ToString("MMMM dd, yyyy") & " / " & DateTime.Now.ToShortTimeString(),
                    "Withdrawal", MessageBoxButtons.OK, MessageBoxIcon.None)

                    conn.Close()

                    RadioButton1.Checked = False
                    RadioButton2.Checked = False
                    RadioButton3.Checked = False
                    RadioButton4.Checked = False
                    RadioButton5.Checked = False
                    TextBox1.Text = "0.00"
                    TextBox1.Enabled = False

                End If

            Else

                MessageBox.Show("Invalid Amount..." + vbNewLine + "Please Enter Amount Divisible By 100 Only",
                    "Withdrawal", MessageBoxButtons.OK, MessageBoxIcon.None)

            End If

        End If

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        Me.Close()
        Form3.Show()

    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click

        Me.Close()
        Form8.Show()

    End Sub

    Private Sub panel2_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs)

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Me.Close()
        Form1.Show()
    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class