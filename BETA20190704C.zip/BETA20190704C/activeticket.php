<body onload="loadingScreen()">
<img src="img/taoanguna.png" id="loader">
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>  
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/activeticket.css">
  <link rel="stylesheet" type="text/css" href="css/darkmode.css">
</head>

<body>
<div class="container" style="margin-top: 70px; max-width: 500px; display: none;" id="primary_display">
<?php
?>


<?php

global $res,$ticketID;
  $ticketID=0;
  $ticketCheck = false;
  $displayMainTable = "";
  $retrieveTicketQueryString = "SELECT * FROM tech_credentials WHERE employee_name = '".$_SESSION['client_name']."'";
              //echo '<script>console.log("'.$retrieveTicketQueryString.'");</script>';  
  $retrieveTicket = mysqli_query($conn, $retrieveTicketQueryString);
          if(!$retrieveTicket || mysqli_num_rows($retrieveTicket)==0) {//checks to make sure the user exists - if not, true, display redirect to outstanding.php
          }   
          else{//user exists       
            while($retrieveRes=mysqli_fetch_array($retrieveTicket)){           
              $ticketID=$retrieveRes['current_ticket'];
                if($retrieveRes['current_ticket']==null || $retrieveRes['current_ticket']==''){//user has no active ticket
                }
                else{//user has an active ticket
                  $ticketCheck = true;                  
                }
            }
          }  
          $resultQueryString = "SELECT * FROM tickets WHERE ticket_id = '".$ticketID."' ORDER BY date_created AND client_name DESC";//query to select user's active ticket from tickets table
          $result = mysqli_query($conn, $resultQueryString);
          if(!$result || mysqli_num_rows($result)==0) {//tech's active ticket doesn't exist - remove tech's active ticket
              $queryString = 'UPDATE tech_credentials SET current_ticket = NULL WHERE employee_name="'.$_SESSION["client_name"].'"';  
              if (mysqli_query($conn, $queryString)) {//user does not have an active ticket
                  $ticketCheck = false;
              }               
          }   
          else{//record exists
            $res=mysqli_fetch_array($result);
                        /*  Code block checks values of fields relevant to tech UI
                        echo "<script>console.log('".$resultQueryString."');</script>";
                        echo "<script>console.log('Office: ".$res['office']."');</script>";
                        echo "<script>console.log('Client Name: ".$res['client_name']."');</script>";
                        echo "<script>console.log('Employee Number: ".$res['employee_number']."');</script>";
                        echo "<script>console.log('Concern: ".$res['concern']."');</script>";
                        */
          }
?>
<div class="borderLine"> <!-- Start of Borderline for Details -->
  <legend class="headerStyle">Ticket Details</legend>
  <div class='ticket' style="<?php echo $displayMainTable;?>">
    <p><b>Ticket <?php echo $res['ticket_id'];?></b></p>
        <?php
        constructDisplay('Office',$res['office']);
        constructDisplay('Client Name',$res['client_name']);
        constructDisplay('Concern',$res['concern']);
        constructDisplay('Concern Details',$res['concern_details']);
        ?>
        <div class="form-group">
            <?php
            $isAssessed = false;

            if($res['date_assessed']=='' OR is_null($res['date_assessed'])){//executes this clause when ticket has NOT been assessed
              $queryString = "          
              SELECT TIMESTAMPDIFF(HOUR, (SELECT date_accepted FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_hours,
              TIMESTAMPDIFF(MINUTE, (SELECT date_accepted FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_minutes,
              TIMESTAMPDIFF(SECOND, (SELECT date_accepted FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_seconds
              ";          
              $timerString = "Assessment Time"; 
            }
            else if($res['date_assessed']!=''){//executes this clause when ticket has been assessed
              $queryString = "          
              SELECT TIMESTAMPDIFF(HOUR, (SELECT date_assessed FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_hours,
              TIMESTAMPDIFF(MINUTE, (SELECT date_assessed FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_minutes,
              TIMESTAMPDIFF(SECOND, (SELECT date_assessed FROM tickets WHERE ticket_id='".$ticketID."'), now()) AS time_elapsed_seconds
              "; 
              $timerString = "Job Time";     
              $isAssessed = true;            
            }
            echo '<label>'.$timerString.'</label>';
            //above query retrieves time between the acceptance of the ticket and now(which retrieves server time) on load //also splits the time difference into hours, minutes, and seconds
                                if ($timeResult=mysqli_query($conn, $queryString)) { 
                                  $timeRes=mysqli_fetch_array($timeResult);
                                } 
                                else{
                                  echo mysqli_error($conn);
                                  echo $queryString;
                                }
              echo "<div class='form-control bgDark'>";       //echoes base value of time elapsed - updated by JS every second (see persistentClock()
                  echo "<span id='hour_display'>".sprintf('%02d',$timeRes['time_elapsed_hours'])."</span>:";//hour value returned by sql is the current number of hours from stored value to now() //the query returns whole hours, so there's no need to mod (not sure if this would still apply if hours>24)
                  echo "<span id='minute_display'>".sprintf('%02d',($timeRes['time_elapsed_minutes']%60))."</span>:";//minute value returned by sql is the total number of minutes between now() and stored value - modding by 60 drops the full hours and leaves only the minutes short of an hour
                  echo "<span id='second_display'>".sprintf('%02d',($timeRes['time_elapsed_seconds']%60))."</span>";//as above, leaves only the seconds short of a minute
              echo "</div>";
            ?>
        </div>
      </div>
    </div> <!-- End of Borderline for Details -->
    <br>

<div class="borderLine"> <!--Start of Borderline for History-->
  <legend class="headerStyle">Ticket History</legend>
  <?php
    retrieveHistory($ticketID);
  ?>
</div>
<br>

<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MODAL CODE FOR SETTING A DEVICE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<div class="borderLine"> <!-- Start of Borderline for Assessment -->
<div class="ticket">
    <div class="modal fade" id="deviceRegistrationModal" style="color:black;">
        <div class="modal-dialog">
          <div class="modal-content">
            <ul class="nav nav-tabs" role="tablist">    
              <li class="nav-item">
                  <a class="nav-link active" data-toggle="tab" href="#home">Register New Device</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#menu1">Select Existing Device</a>
              </li>
            </ul>

            <div class="tab-content">
                <div id="home" class="container tab-pane active">  
                    <div class="modal-header"><!-- Modal Header -->
                        <h4 class="modal-title">Register New Device</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body"><!-- Modal body -->
                      <form id='registerDeviceForm' action='createdevice.php' method='post'><!--form used to register new device-->
                          <?php createHiddenInput('trail',basename($_SERVER['PHP_SELF']));?>
                          <?php echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";?>
                          <div class="form-group">
                              <label>Device Type</label>
                                <?php
                                  $valueArray = retrieveOptions('device_type',true);
                                  outputSelect('device_type','',$valueArray,true);
                                ?>
                          </div>
                          <div class="form-group">
                              <label>Owner:</label>
                              <input type='text' class="form-control" name='owner' id='owner' placeholder='Owner' required>
                          </div>
                          <div class="form-group">
                              <label>Office:</label>
                              <?php
                                $valueArray = retrieveOptions('office',true);
                                outputSelect('office',$res['office'],$valueArray,true);
                              ?>
                          </div>
                          <input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Register">
                      </form>
                  </div>  
                </div>

                <div id="menu1" class="container tab-pane fade">
                <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title centerText">Select Existing Device</h4><br><br>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>     
                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Device ID:</label>
                            <form id='setDeviceForm' action='setdevice.php' method='post'>
                                <input type='text' name='device_id' id='device_id' placeholder='Enter device ID...' list='deviceList' class="form-control">
                                <br>
                                <?php 
                                  retrieveDevices();
                                  //initializes combo box with list of all registered devices
                                ?>
                                <?php echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";?>
                                <input type='submit' class="btn btn-default buttonStyle" name='Submit' value='Set Device' id='toggleSetDevice'>
                            </form>
                        </div>
                    </div>
                </div>
              </div>  
          </div>
        </div>
      </div> 
  <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF MODAL CODE FOR SETTING A DEVICE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

  <!--BOUNDARY BETWEEN TICKET DETAILS & ASSESSMENT DETAILS-->
  <legend class="headerStyle">Assessment</legend>

<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO ASSESS TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
  <form id='finishAssessment' action='finishassessment.php' method='post'><!--form used to finish ticket assessment-->
    <div class="form-group">
        <label>Assessment:</label>
        <?php
          $valueArray = retrieveOptions('assessment',true);
          outputSelect('assessment',$res['assessment'],$valueArray,true);
        ?>
    </div>
    <div class="form-group">
        <label>Job Description:</label>
        <?php
          $valueArray = retrieveOptions('job_description',true);
          outputSelect('job_description',$res['job_description'],$valueArray,true);
          //echo "<input type='text' name='job_description_others' id='job_description_others'>";
            $valueArray = retrieveOptions('software',false);
            outputSelect('software','',$valueArray,false);
            echo "<input class='form-control' type='text' name='software_others' id='software_others' placeholder='Enter installed software...'>";
        ?> 
        <script>
        
          window.load=updateJobDescriptionInputs();
                document.getElementById('software_others').required = false;
                document.getElementById('software_others').style.display = 'none';

          document.getElementById('job_description').onchange=function(){
            updateJobDescriptionInputs();};
          document.getElementById('software').onchange=function(){
            updateJobDescriptionInputs();};

          function updateJobDescriptionInputs(){
            if(document.getElementById('job_description').value == 'Install'){
              document.getElementById('software').required = true;
              document.getElementById('software').style.display = 'block';
              if(document.getElementById('software').value == 'Others'){
                document.getElementById('software_others').required = true;
                document.getElementById('software_others').style.display = 'block';
              }
              else{
                document.getElementById('software_others').required = false;
                document.getElementById('software_others').style.display = 'none';
              }
            } 
            else{
              document.getElementById('software').required = false;
              document.getElementById('software').style.display = 'none';
            }
          }
        </script>

    </div>
    <div class="form-group">
        <label>Job Details:</label>
        <textarea id="job_details" name="job_details" class="form-control" required></textarea>
    </div>
    <input class="btn btn-default  buttonStyle" type="submit" name="Submit" value="Finish Assessment">
    <?php
      echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";
    ?>
  </form><!--form used to finish ticket assessment-->  
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF FORM USED TO ASSESS TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

  
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO FINISH TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<form id='finishTicket' action='finishactiveticket.php' method='post'><!--form used to finish ticket-->
              <div class="form-group">
                  <label>Assessment:</label>
                  <span id="concern" name="concern" class="form-control"><?php echo $res['assessment'];?></span>
              </div>
              <div class="form-group">
                  <label>Job Description:</label>
                  <span id="concern" name="concern" class="form-control"><?php echo $res['job_description'];?></span>                          
              </div>
              <div class="form-group">
                  <label>Job Details:</label>
                  <span id="concern" name="concern" class="form-control"><?php echo $res['job_details'];?></span>
              </div>

    <input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Finish Ticket">
    <input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Escalate Ticket">
    
    <?php
      //code block determines if user should be able to suspend a ticket
      $suspendedTicket = checkSuspendedTicket(callUsername());
      if(!$suspendedTicket){//user already has a suspended_ticket and cannot suspend another one
        echo '<input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Suspend Ticket">';
      }
      else{
        echo "<center><p>You have already suspended ticket $suspendedTicket and may not suspend this one.</p></center>";
      }
      echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";//hidden input to send ticket_id to finishactiveticket.php
      createHiddenInput('username',callUsername());//creates a hidden input named 'username' with a value equal to the username of the curretly logged-in user
    ?>
</form><!--form used to finish ticket-->

</div>
</div> <!-- End of Borderline for Assessment -->

<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF FORM USED TO FINISH TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<br>
<div class="borderLine">
  <div class="ticket">
    <legend>Device Changelog</legend>
      <?php
      getDeviceChangelog($res['device_id']);      
      ?>
  </div>
</div>
<br>
<div class="borderLine">
  <div class="ticket">
    <legend>Device Service History</legend>
      <?php
      getDeviceHistory($res['device_id']);      
      ?>
  </div>
</div>
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO SET/GET DEVICE INFORMATION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<br>

<div class="borderLine"> <!-- Start of Borderline for Device Details -->
<div class="ticket">
<?php
if(($res['device_id'])){  //device is set
  echo "<legend class='headerStyle'>Device Details</legend>";
}
else{  //no device set
  echo  "<legend class='headerStyle'>No Device Set</legend>";
  echo '<button type="button" class="btn btn-default buttonStyle" data-toggle="modal" data-target="#deviceRegistrationModal">Set Device</button><br>';
}
?>

<div id="device_info_container">
  <fieldset id="device_details">
     Device <?php echo $res['device_id'];?>
        
          <?php
            $deviceDetails = retrieveDetails($res['device_id']);
          ?>  
          <br><br>
          <div class="form-group">
              <label>Device Type</label>
              <span id="concern" name="concern" class="form-control"><?php echo $deviceDetails['device_type'];?></span>                          
          </div>
          <div class="form-group">
              <label>Device Owner</label>
              <span id="" name="concern" class="form-control"><?php echo $deviceDetails['owner'];?></span>
          </div>
          <div class="form-group">
              <label>Office</label>
              <span id="concern" name="concern" class="form-control"><?php echo $deviceDetails['office'];?></span>
          </div>
        
  </fieldset>
 
  <fieldset id="device_parts">
      <p>Device Parts</p>
        <li href="#showParts" class="list-group-item styleList pointerElements" data-toggle="collapse"><span>Show</span> Parts List</li>
          <div id="showParts" class="collapse">
            <ul class="list-group">
              <?php
                printArray(retrieveParts($res['device_id']));
              ?>
            </ul>
          </div>
          <hr class="borderGray">
      <li>Add New Peripheral
      <br><br>
        <form action="newpartspec.php" method="post"><!--form to add new peripheral to device-->
          <div class="form-group">
              <?php 
                createHiddenInput('device_id',$res['device_id']);
                createHiddenInput('trail',basename($_SERVER['PHP_SELF']));

                $optionArray=retrieveOptions('peripheral',true);
                outputFullSelect('new_value','',$optionArray,true,'Select a new peripheral...',true);
              ?>
            <input type="text" class="form-control" id="newPeripheral" name="new_item" placeholder="Please specify...">
            <br>        
            <input type="text" class="form-control" name="new_detail" placeholder="New Details..." required>
            <br>
            <input class="btn btn-default partStyle"  type="submit" name="Submit" value="Add Peripheral">
          </div>
        </form>
      </li>
  </fieldset>
  <hr class="borderGray">
  <fieldset id="device_specs">
      <p>Device Specifications</p>
          <li href="#showSpecs" class="list-group-item styleList" data-toggle="collapse"><span>Show</span> Specifications List</li>
          <div id="showSpecs" class="collapse">
              <ul class="list-group">
                <?php
                  printArray(retrieveSpecs($res['device_id']));
                ?>
              </ul>
          </div>
          <form action="newpartspec.php" method="post"><!--form to add new spec to device-->
            <div class="form-group">
              <?php 
                createHiddenInput('device_id',$res['device_id']);
                createHiddenInput('trail',basename($_SERVER['PHP_SELF']));

                $optionArray=retrieveOptions('specification',true);
                outputFullSelect('new_value','',$optionArray,true,'Select a new specification...',true);
              ?>
              <input type="text" class="form-control" id="newSpecification" name="new_item" placeholder="Please specify...">
              <br>
              <input type="text" name="new_detail" class="form-control" placeholder="New Details..." required>
              <br>
              <input class="btn btn-default specificationStyle" type="submit" name="Submit" value="Add Specification">
            </div>
          </form>
  </fieldset>

</div>
</div> <!-- End of Borderline for Device Details -->
</div>
</body>
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF FORM USED TO SET/GET DEVICE INFORMATION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->


<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MODULE SWITCHES BETWEEN TECH DISPLAY AND ADMIN DISPLAY~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<?php
if(($res['device_id'])){  
  echo "<script>document.getElementById('device_info_container').style.display='block';</script>";
  //echo "<script>document.getElementById('set_new_registry_container').style.display='none';</script>";
}
else{
  echo "<script>document.getElementById('device_info_container').style.display='none';</script>";
  //echo "<script>document.getElementById('set_new_registry_container').style.display='block';</script>";
}
if($isAssessed){//$isAssessed is /true/ when ticket has already been assessed  
    echo "<script>document.getElementById('finishAssessment').style.display='none';";///hides assessment form
    echo "document.getElementById('finishTicket').style.display='block';";//displays assessment values, button to close ticket
    echo "</script>";
}
else{
    echo "<script>document.getElementById('finishAssessment').style.display='block';";///shows assessment form
    echo "document.getElementById('finishTicket').style.display='none';";//hides assessment values, button to close ticket
    echo "</script>";
}
?>
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF MODULE THAT SWITCHES BETWEEN TECH DISPLAY AND ADMIN DISPLAY~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

</div><!--closes very large container-->

<?php
  echo'  <div class="container" id="redirect_display" style="display:none; margin-top: 80px;">
      <center>
        <img src="img/taoanguna.png" style="width: 20%;">
        <br><br><p class="whiteText">You do not have an active ticket!</p>
        <p class="whiteText">Click <a href="outstanding.php">here</a> to select a new ticket.</p>
      </center>
    </div>';
?>

<?php
  if(!$ticketCheck){//user has no current_ticket
    //show redirect_display
    //hide primary_display
    showElement('redirect_display');
  }
  else{
    //hide redirect_display
    //show primary_display    
    showElement('primary_display');
  }

?>

<br>
<br>
<br>
<br>
<br>
</div>

</body>
</html>

<!--css-->

<script>
  var hours_disp = document.getElementById('hour_display');       //reference to the hours display span to eliminate the need to query the DOM over and over again
  var minutes_disp = document.getElementById('minute_display');   //reference to minutes display
  var seconds_disp = document.getElementById('second_display');   //reference to seconds display

  persistentClock();

  document.addEventListener('DOMContentLoaded', function() {
    console.log('switch function : '+!!document.getElementById("no_ticket"));
    //console.log(!!document.getElementById("no_ticket"));
    if(!!document.getElementById("no_ticket")){
      hidePanels();
    }
  }, false);

  function clockTick(){ //function updates hours, minutes, seconds values
    var hours = parseInt(hours_disp.innerHTML);
    var minutes = parseInt(minutes_disp.innerHTML);
    var seconds = parseInt(seconds_disp.innerHTML);

    seconds++;
    if(seconds==60){
      minutes++;
      seconds=0;
    }
    if(minutes==60){
      hours++;
      minutes=0;
    }
    hours_disp.innerHTML=hours.pad(2);
    minutes_disp.innerHTML=minutes.pad(2);
    seconds_disp.innerHTML=seconds.pad(2);
  }

  function persistentClock(){ //calls the clock update function every second
    setInterval(clockTick, 1000);
  }

  function hidePanels(){//hides all panels with the class 'borderLine'
    console.log('No ticket set - hiding elements');
    var x = document.getElementsByClassName('borderLine');
    console.log(x.length);
    var i;
    for (i = 0; i < x.length; i++) {
      console.log('hiding: '+x[i].name);
      x[i].style.display='none';
    }    
  }


  document.getElementById("newPeripheral").style.display="none";
  document.getElementById("newSpecification").style.display="none";
  document.getElementsByName('new_value')[0].onchange=function(){
            othersSelected();};
  document.getElementsByName('new_value')[1].onchange=function(){
            othersSelected();};

  function othersSelected(){
    console.log("othersSelected called");
    if(document.getElementsByName('new_value')[0].value=="Others"){
      document.getElementById("newPeripheral").style.display="block";
      document.getElementById("newPeripheral").required=true;
      console.log(">others");
    }
    else{
      console.log(">not others");
      document.getElementById("newPeripheral").style.display="none";
      document.getElementById("newPeripheral").required=false;
    }
    
    if(document.getElementsByName('new_value')[1].value=="Others"){
      console.log(">others");
      document.getElementById("newSpecification").style.display="block";
      document.getElementById("newSpecification").required=true;
    }
    else{
      console.log(">not others");
      document.getElementById("newSpecification").style.display="none";
      document.getElementById("newSpecification").required=false;
    }
  }

</script>