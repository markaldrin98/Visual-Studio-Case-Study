<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>  
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/viewticket.css">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
</head>
<body>
<div id="primary_display" style="display:none;">
<?php
//code block to retrieve and then forward data to fields

$ticketID='';
if(checkGet('ticket_id')){
  $ticketID = checkGet('ticket_id');
}
else{
  redirect('index.php');
}
$resultQueryString = "SELECT * FROM tickets WHERE ticket_id = '".$ticketID."' ORDER BY date_created AND client_name DESC";//query to select user's active ticket from tickets table
          $result = mysqli_query($conn, $resultQueryString);
          if(!$result || mysqli_num_rows($result)==0) {//tech's active ticket doesn't exist - remove tech's active ticket
              $queryString = 'UPDATE tech_credentials SET current_ticket = NULL WHERE employee_name="'.$_SESSION["client_name"].'"';  
              if (mysqli_query($conn, $queryString)) {
                  $message = "<center>Ticket ".$ticketID." does not exist!";
                  $message .= "<br>Click <a href='outstanding.php'>here</a> to select a new ticket.</center>";
                  $displayMainTable = "display:none";
                  $displayNullMessage = "";
              }               
          }   
          else{//record exists
            $res=mysqli_fetch_array($result);
            $ticket_id = $res['ticket_id'];
            $date_created = $res['date_created'];
            $date_accepted = $res['date_accepted'];
            $date_assessed = $res['date_assessed'];
            $date_fulfilled = $res['date_fulfilled'];
            $office = $res['office'];
            $client_name = $res['client_name'];
            $employee_number = $res['employee_number'];
            $concern = $res['concern'];
            $concern_details = $res['concern_details'];
            $assessment = $res['assessment'];
            $job_description = $res['job_description'];
            $job_details = $res['job_details'];
            $participation = $res['participation'];
            $approval_status = $res['approval_status'];
            $respondent = $res['respondent'];
            $job_status = $res['job_status'];
            $remarks = $res['remarks'];
          }
?>
<div class="container" id="adminModule">
  <div class="lineBorder">
    <!--START OF MODULE FOR TICKET DISPLAY (ADMIN DISPLAY)-->
      <?php
        //echo "<b style='font-size:20;'>Ticket ".$ticket_id."</b><br><br>";
        outputTitle("Ticket ".$ticket_id);
        echo '<div class="form-group"><input type="hidden" name="ticket_id" value="'.$ticket_id.'"></div>';
      ?>
             <div class="form-group">
                  <label>Date/Time Created:</label>
                  <span id="date_created" name="date_created" class="form-control"><?php echo $date_created;?></span>
              </div>
              <div class="form-group">
                  <label>Date/Time Accepted:</label>
                  <span id="date_accepted" name="date_accepted" class="form-control"><?php echo $date_accepted;?></span>
              </div>
              <div class="form-group">
                  <label>Date/Time Assessed:</label>
                  <span id="date_assessed" name="date_assessed" class="form-control"><?php echo $date_assessed;?></span>
              </div>
              <div class="form-group">
                  <label>Date/Time Fulfilled:</label>
                  <span id="date_fulfilled" name="date_fulfilled" class="form-control"><?php echo $date_fulfilled;?></span>
              </div>
          </div><!--end of ticket panel-->
          <br>
          <div class="lineBorder"><!--start of client panel-->
              <?php outputTitle("Client");?>
              <!--<div class="form-group">
                  <label>Ticket ID:</label>
                  <span id="ticket_id_display" name="ticket_id_display" class="form-control"></span>
                  <input type="hidden" name="ticket_id" id="ticket_id" class="form-control"> 
              </div>-->
              <div class="form-group">
                  <label>Office:</label>                  
                  <span id="client_name" name="client_name" class="form-control"><?php echo $office;?></span>
              </div>
              <div class="form-group">
                  <label>Client Name:</label>
                  <!--<input type="text" class="form-control" id="client_name" name="client_name">-->
                  <span id="client_name" name="client_name" class="form-control"><?php echo $client_name;?></span>
              </div>
              <div class="form-group">
                  <label>Employee Number:</label>
                  <!--<input type="text" class="form-control" id="employee_number" name="employee_number">-->
                  <span id="employee_number" name="employee_number" class="form-control"><?php echo $employee_number;?></span>
              </div>
              <div class="form-group">
                  <label>Concern:</label>
                  <span id="concern" name="concern" class="form-control"><?php echo $concern;?></span>
              </div>
              <div class="form-group">
                  <label>Concern Details:</label>
                  <span id="concern_details" name="concern_details" class="form-control"><?php echo $concern_details;?></span>
              </div>
            </div><!--end of client panel-->
            <br>
            <div class="lineBorder"><!--start of assessment panel-->
              <?php outputTitle("Assessment");?>
            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO ASSESS TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                <?php
                  $isAssessed = isset($date_assessed);
                  if(!$isAssessed){
                    echo "<div id='notAssessed'>
                      <center><p>This ticket has not been assessed by a tech yet.</p></center>
                      </div>";
                  }
                ?>

                  <div id='editAssessment'>
                  <form id='finishAssessment' action='finishassessment.php' method='post'><!--form used to finish ticket assessment-->
                    <div class="form-group">
                        <label>Assessment:</label>
                        <?php
                          $valueArray = retrieveOptions('assessment',true);
                          outputSelect('assessment',$res['assessment'],$valueArray,true);
                        ?>
                    </div>
                    <div class="form-group">
                        <label>Job Description:</label>
                        <?php
                            $valueArray = retrieveOptions('job_description',true);
                            outputSelect('job_description',$res['job_description'],$valueArray,true);
                            //echo "<input type='text' name='job_description_others' id='job_description_others'>";
                              $valueArray = retrieveOptions('software',false);
                              outputSelect('software','',$valueArray,false);
                              echo "<input type='text' class='form-control' name='software_others' id='software_others' placeholder='Enter installed software...'>";

                              //below code block contains scripts that control secondary inputs (for when user selects 'others')
                              echo "<script>
                              
                                window.load=updateJobDescriptionInputs();
                                      document.getElementById('software_others').required = false;
                                      document.getElementById('software_others').style.display = 'none';

                                document.getElementById('job_description').onchange=function(){
                                  updateJobDescriptionInputs();};
                                document.getElementById('software').onchange=function(){
                                  updateJobDescriptionInputs();};

                                function updateJobDescriptionInputs(){
                                  if(document.getElementById('job_description').value == 'Install'){
                                    document.getElementById('software').required = true;
                                    document.getElementById('software').style.display = 'block';
                                    if(document.getElementById('software').value == 'Others'){
                                      document.getElementById('software_others').required = true;
                                      document.getElementById('software_others').style.display = 'block';
                                    }
                                    else{
                                      document.getElementById('software_others').required = false;
                                      document.getElementById('software_others').style.display = 'none';
                                    }
                                  } 
                                  else{
                                    document.getElementById('software').required = false;
                                    document.getElementById('software').style.display = 'none';
                                  }
                                }
                              </script>";
                              //end of code block
                        ?> 
                    </div>
                    <div class="form-group">
                        <label>Job Details:</label>
                          <?php
                            echo "<textarea id='job_details' name='job_details' class='form-control' required>$job_details</textarea>";
                          ?>
                    </div>
                    <?php
                      if($isAssessed){
                        //do nothing
                      }
                      else{//ticket has not been assessed
                        echo '<input class="saveStyle" style="color:white;" type="submit" name="Submit" value="Change Assessment">';
                      }
                      echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";
                    ?>
                    <?php 
                      toConsole("TRAIL : ".getUrl('FULL'));
                      createHiddenInput('trail',getUrl('FULL'));
                    ?>
                  </form><!--form used to finish ticket assessment--> 
                  </div> 

            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF FORM USED TO ASSESS TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
            </div><!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~end of assessment panel~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

            <br>

            <div class="lineBorder"><!--start of admin panel-->
              <?php outputTitle("Admin");?>              
              <form class="login100-form validate-form" action='updatetickets.php' id="adminForm" name="adminForm" method='post'>
              <div class="form-group">
                  <label>Participation:</label>
                  <?php
                    $valueArray = retrieveOptions('participation',true);
                    outputSelect('participation',$res['participation'],$valueArray,false);
                  ?>
              </div>
              <div class="form-group">
                  <label>Approval Status:</label>
                  <?php
                    outputSelect('approval_status',$res['approval_status'],array("Approved" => "","Not Approved" => ""),false);
                  ?>
              </div>
              <div class="form-group">
                  <label>Respondent:</label>
                  <?php
                    retrieveTechs(true);
                    if($res['respondent']!=''){
                      echo "<script>setSelectedOption('respondent', '".$res['respondent']."');</script>";
                      echo "<script>document.getElementById('respondent').disabled=true;</script>";
                    }
                  ?>
              </div>
              <div class="form-group">
                  <label>Status:</label>
                  <?php
                    $valueArray = retrieveOptions('status',true);
                    outputSelect('job_status',$res['job_status'],$valueArray,false);
                  ?>
              </div>
              <div class="form-group">
                  <label>Remarks:</label>
                  <div id="chatlog" name="chatlog">
                  </div>

                  <!--CODE BLOCK FOR REMARKS/CHAT LOG-->
                  <div class="form-group">
                    <!--<span class='login100-form-title p-b-48'>Chat Log</span>-->     
                        <div class="chat">   
                            <div class="chat-history">
                                <ul class="chat-ul">
                                <?php
                                  echo prepareChatlog($res['remarks']);
                                  //toConsole($res['remarks']);
                                ?>
                                </ul>
                            </div> <!-- end chat-history -->
                        </div> <!-- end chat -->
                    <div class="form-group">
                        <input type="text" class="form-control" id="remarks" name="remarks" placeholder="Type a message...">
                    </div><!-- /input-group -->              
                    </div>
                </div>
              <!--<div class="form-group">
                  <label>Time Elapsed:</label>
                  <span id="" name=""></span>
              </div>-->
              <input type="submit" value="Save Changes" name="Submit" class="saveStyle">
              <?php 
                echo '<input type="hidden" name="ticket_id" value="'.$ticket_id.'">';
                createHiddenInput('trail',getUrl('FULL'));
              ?>
              </form>
  <!--END OF MODULE FOR TICKET DISPLAY (ADMIN DISPLAY)-->
  
</div>
</div>

  <!--START OF MODULE FOR TECH DISPLAY-->
<div class="container" id="techModule">
<div class="lineBorder">
<form class="login100-form validate-form" action='acceptticket.php' id="techForm" name="adminForm" method='post'>
      <?php
        echo "<b style='font-size:20;'>Ticket ".$ticket_id."</b><br><br>";
        echo '<div class="form-group"><input type="hidden" name="ticket_id" value="'.$ticket_id.'"></div>';
      ?>
              <div class="form-group">
                  <label>Date/Time Created:</label>
                  <span id="date_created" name="date_created" class="form-control"><?php echo $date_created;?></span>
              </div>
              <div class="form-group">
                  <label>Office:</label>
                  <span id="date_created" name="date_created" class="form-control"><?php echo $office;?></span>
              </div>
              <div class="form-group">
                  <label>Client Name:</label>
                  <!--<input type="text" class="form-control" id="client_name" name="client_name">-->
                  <span id="client_name" name="client_name" class="form-control"><?php echo $client_name;?></span>
              </div>
              <div class="form-group">
                  <label>Employee Number:</label>
                  <!--<input type="text" class="form-control" id="employee_number" name="employee_number">-->
                  <span id="employee_number" name="employee_number" class="form-control"><?php echo $employee_number;?></span>
              </div>
              <div class="form-group">
                  <label>Concern:</label>
                  <span id="concern" name="concern" class="form-control"><?php echo $concern;?></span>
              </div>
              <div class="form-group">
                  <label>Concern Details:</label>
                  <span id="concern_details" name="concern_details" class="form-control"><?php echo $concern_details;?></span>
              </div>  
              <input type="submit" value="Accept Ticket" name="Submit" style="width: 100%; padding: 10px; background-color: darkorange; border-color: darkorange; font-size: 18px; font-weight: bold; border-radius: 10px;">
</form>
</div>
</div>  <!-- END OF MODULE FOR TECH DISPLAY-->

<!--MODAL FOR DELETE CONFIRMATION-->
  <div class="modal fade" id="deleteParts">
    <div class="modal-dialog">
      <div class="modal-content">
        <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">Confirm Deletion</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
        <!-- Modal body -->
        <form method="post" action="deletepartspec.php">
          <div class="modal-body">
            Are you sure you want to delete [<span id="toDelete"></span>]?
          </div>
          <!-- Modal footer -->
          <div class="modal-footer">
            <input type="submit" class="btn btn-primary mr-auto" style="width: 100%;" value="Yes">
            <button type="submit" class="btn btn-danger" data-dismiss="modal" style="width: 100%;">No</button>
          </div>
        </form>
      </div>
    </div>
  </div>
<!--END OF MODAL FOR DELETE CONFIRMATION-->

<!--MODULE TO SWITCH BETWEEN TECH DISPLAY AND ADMIN DISPLAY-->
<?php
  if(checkUserPrivilege()=='admin'){
    toConsole('User is an administrator');
  echo "<script>
    document.getElementById('techModule').style.display='none';
    document.getElementById('adminModule').style.display='block';
  </script>";
  }
  else if(checkUserPrivilege()=='tech'){
    toConsole('User is a tech');
  echo "<script>
    document.getElementById('techModule').style.display='block';
    document.getElementById('adminModule').style.display='none';
  </script>";
  }
  else if(!checkUserPrivilege()){
    toConsole('Redirecting to index');
    redirect('index.php');
  }
?>
<!--END OF MODULE TO SWITCH BETWEEN TECH DISPLAY AND ADMIN DISPLAY-->

</div>

<?php
  echo'  <div class="container" id="redirect_display" style="display:none;">
      <center>
        <img src="img/taoanguna.png" style="width: 30%;">
        <br><br><p style="color: white;">You already have an active ticket!</p>
        <p style="color: white;">Click <a href="activeticket.php">here</a> to view your active ticket.</p>
      </center>
    </div>';
?>

<?php
//MODULE DETERMINES IF USER SHOULD SEE INTERFACE//
  if(checkCurrentTicket()){
    //SHOW MAIN DISPLAY, HIDE REDIRECT DISPLAY
    showElement('primary_display');
  }
  else{
    //HIDE MAIN DISPLAY, SHOW REDIRECT DISPLAY
    showElement('redirect_display');
  }
  
?>

</body>

<script>
    function isNumberKey(evt){//checks whether the key pressed is a number - currently not in use
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
function textAreaAdjust(o) {
  o.style.height = "1px";
  o.style.height = (25+o.scrollHeight)+"px";
}

document.addEventListener('DOMContentLoaded', function() {//this function runs after the page has been completely loaded
  console.log(document.getElementById('notAssessed').id);
   if(document.getElementById('notAssessed')){
    document.getElementById('editAssessment').style.display='none';//hides the panel used to edit ticket assessment
   }
   else{
    document.getElementById('notAssessed').style.display='none';//hides the div that states that the ticket has not been assessed
   }
}, false);

</script>
</html>