<?php
include_once("misc/config.php");  
echo "<br><br><br><br><br><br><br><br>";  

printPost();
$ticketID = $_POST["ticket_id"];

$assessmentCheck = false;   //gate variable

if(isset($_POST['Submit']) && $_POST['Submit']!=''){//if clause checks to make sure user arrived on this page through the intended channel/s
    //below code block sets date_assessed in the 'tickets' table



    if(($job_description = checkPost('job_description')) && $job_description == "Install"){
        $software = checkPost('software');
        if($software == "Others"){
            $job_description = checkPost('job_description').": ".checkPost('software')." - ".checkPost('software_others');
        
        }     
    }
    else{
        $job_description = checkPost('job_description');
    }
    $queryString = 'UPDATE tickets SET date_assessed=now(), job_description="'.$job_description.'", assessment="'.checkPost("assessment").'", job_details="'.checkPost("job_details");
    $queryString .= '" WHERE ticket_id="'.$ticketID.'"';  
                print($queryString);
                   if (mysqli_query($conn, $queryString)) { //query passes, gate is cleared
                        echo "<script>console.log('"."Gate check clear"."')</script>";
                        $assessmentCheck = true;
                    } 
                    else {    //report sql error
                        echo '<script>console.log("Check - '.mysqli_error($conn).'");</script>';
                        echo "<script>console.log('".$queryString."')</script>";
                    }
    //end of code block
    if($assessmentCheck){   //checks gate variable - if gate variable returns true, redirect to outstanding.php
        toConsole("Redirecting");
        if($trail=checkPost('trail')){
            //redirect($trail);
        }
        else{
            //redirect('activeticket.php');
        }
    }
    else{   //else do nothing
        toConsole("Doing nothing");
    }
}//end of if clause
else{//user /did not/ arrive on this page through the intended channel, redirect to index
    redirect("index.php");
}
?>

