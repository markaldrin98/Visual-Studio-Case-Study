<?php
function checkSQLError(){ //prints most recent SQL error to console
        global $conn;
        echo '<script>console.log("Error - '.mysqli_error($conn).'");</script>';
}

//---------------------------------FUNCTION TO PREPARE -> EXECUTE UPDATE QUERY & LOG CHANGE-----------------//
function prepareUpdate($ticketID, $fieldName, $storedValue, $givenValue){
  global $conn;
  $givenValue = mysqli_real_escape_string ($conn,$givenValue);  //escapes $givenValue with respect to $conn
  $givenValue = str_replace(";","",$givenValue);  //primitive method to prevent sql injection - improve this
if($givenValue!=$storedValue){   
  $outString = "UPDATE tickets SET ".$fieldName." = '".$givenValue."' WHERE ticket_id='".$ticketID."'";//code block updates field if stored value does not equal given value
  if (mysqli_query($conn, $outString)) {
      } else {
          checkSQLError();
      }          
  //end of code block

    $logString = "Changed ".$fieldName." from "; //code block prepares string that logs what field was changed and what it was changed from and to
    if($storedValue==null){
        $storedValue= 'empty';
    }   
      $logString.=$storedValue;
      $logString.=" to ";
    if($givenValue==null){
        $givenValue= 'empty';
    }     
      $logString.=$givenValue;
      print($ticketID);
      print($logString);
      print($outString);
    logChange($_SESSION['client_name'],$ticketID,$logString);//logs change
    //end of code block
  }
}
//-----------------------------END OF FUNCTION TO PREPARE -> EXECUTE UPDATE QUERY & LOG CHANGE-----------------//


function redirect($url) //----function to redirect browser to specified $url
{
    if (!headers_sent())
    {    
        header('Location: '.$url);
        exit;
        }
    else
        {
        echo '<script type="text/javascript">';
        echo 'window.location.href="'.$url.'";';
        echo '</script>';
        echo '<noscript>';
        echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
        echo '</noscript>'; exit;
    }
}                       //----end of function to redirect browser to specified $url

//----------------------------FUNCTION TO LOG A CHANGE MADE TO A TICKET----------------------------//
function logChange($admin,$ticket,$change_made){ //function to log a change
    echo "<script>console.log('Logger called')</script>";
    global $conn;
    $logString = "INSERT INTO ticket_changelog(admin,ticket,change_made) VALUES('".$admin."','".$ticket."','".$change_made."')";
    if (mysqli_query($conn, $logString)) {
        echo "<script>console.log('Change log created')</script>";
        } else {
        echo "<script>console.log('Failed to create change log".mysqli_error($conn)."')</script>";
        }   

}                       //end of function to log a change
//-------------------------END OF FUNCTION TO LOG A CHANGE MADE TO A TICKET------------------------//

//----------------------------FUNCTION TO LOG A CHANGE MADE TO A DEVICE----------------------------//
function logChangeDevice($admin,$device,$change_made){ //function to log a change
    echo "<script>console.log('Logger called')</script>";
    global $conn;
    $logString = "INSERT INTO device_changelog(admin,device_id,change_made) VALUES('".$admin."','".$device."','".$change_made."')";
    if (mysqli_query($conn, $logString)) {
        echo "<script>console.log('Change log created')</script>";
        } else {
        echo "<script>console.log('Failed to create change log: ".mysqli_error($conn)."')</script>";
        }   

}                       //end of function to log a change
//-------------------------END OF FUNCTION TO LOG A CHANGE MADE TO A DEVICE------------------------//


//------------------------------------FUNCTION THAT PRINTS PARAMETER TO CONSOLE------------------------------------//
function toConsole($consoleString){  //function outputs parameter into browser console via script
    echo "<script>console.log('".$consoleString."');</script>";
}
//--------------------------------END OF FUNCTION THAT PRINTS PARAMETER TO CONSOLE------------------------------------//


//------------------------------------FUNCTION THAT CHECKS PRIVILEGE OF USER------------------------------------//
function checkUserPrivilege(){  //function checks userType of user in $_SESSION
    if(isset($_SESSION['userType']) && $_SESSION['userType']!=''){
      toConsole('True: '.$_SESSION['userType']);
      return($_SESSION['userType']);
    }
    else{
      toConsole('False: no user logged in');
      return(false);
    }
}
//--------------------------------END OF FUNCTION THAT CHECKS PRIVILEGE OF USER------------------------------------//



//---------------------------------------FUNCTION THAT CHECKS NAME OF USER-----------------------------------------//
function checkUser(){  //function checks userType of user in $_SESSION
    if(isset($_SESSION['client_name']) && $_SESSION['client_name']!=''){
      toConsole('True: '.$_SESSION['client_name']);
      return($_SESSION['client_name']);
    }
    else{
      toConsole('False: '.$_SESSION['client_name']);
      return false;
    }
}
//----------------------------------END OF FUNCTION THAT CHECKS NAME OF USER---------------------------------------//


//------------------------------------FUNCTION CHECKS IF PARAMETER IS PRESENT IN $_POST ARRAY----------------------------------------//
function checkPost($parameterToCheck){
    if(isset($_POST[$parameterToCheck]) && $_POST[$parameterToCheck]!=''){
      //toConsole($parameterToCheck.' present: '.$_POST[$parameterToCheck]);
      return($_POST[$parameterToCheck]);       //parameter is present, return value
    }
    else{
      //toConsole($parameterToCheck.' absent');
      return(false);                           //parameter is absent, return false
    }
}
//-------------------------------END OF FUNCTION TO CHECK IF PARAMETER IS PRESENT IN $_POST ARRAY-----------------------------------//


//------------------------------------FUNCTION CHECKS IF PARAMETER IS PRESENT IN $_GET ARRAY----------------------------------------//
function checkGet($parameterToCheck){
    if(isset($_GET[$parameterToCheck]) && $_GET[$parameterToCheck]!=''){
      //toConsole($parameterToCheck.' present: '.$_GET[$parameterToCheck]);
      return($_GET[$parameterToCheck]);       //parameter is present, return value
    }
    else{
      //toConsole($parameterToCheck.' absent');
      return(false);                           //parameter is absent, return false
    }
}
//-------------------------------END OF FUNCTION TO CHECK IF PARAMETER IS PRESENT IN $_GET ARRAY------------------------------------//

function printPost(){  
        foreach ($_POST as $key => $entry)
        {
             print $key . ": " . $entry . "<br>";
        }
}
//------------------------------END OF FUNCTION THAT CHECKS IF PARAMETER IS PRESENT IN $_POST ARRAY----------------------------------//

function callUser(){//returns name of current user
  if(isset($_SESSION["client_name"]) && $_SESSION["client_name"]!=''){
    return $_SESSION["client_name"];    
  }
  else{
    return false; 
  }
}

function checkArray($givenArray){//prints a list of all key-value pairs in givenArray to console(givenArray should be associative)
  foreach ($givenArray as $key => $value){
    toConsole($key." : ".$value);
  }
}

//------FUNCTION THAT RETURNS AN ARRAY CONTAINING THE FIELDS OF table PARAMETER------//
function retrieveFields($tableName){//receives table name and returns numbered array containing the names of its fields - if query fails (i.e. table specified doesn't exist), return false
  global $conn;
  $fieldQuery = "
    SELECT COLUMN_NAME
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = '".$tableName."'
    ORDER BY ORDINAL_POSITION
  "; 
  if($fieldResult = mysqli_query($conn,$fieldQuery)){
    $values = array();                                          //numeric array to contain field names
    while($fieldRes = mysqli_fetch_array($fieldResult)){
      array_push($values, $fieldRes['COLUMN_NAME']);            //push each column name into $values
    }
    return $values;
  }
  else{
    return false;
  }
}//---------------------------------end of retrieveFields--------------------------//


//------FUNCTION THAT RETURNS AN ARRAY CONTAINING THE OPTIONS FOR A SELECT CONTROL TAGGED <parameter>------//
function retrieveOptions($selectTag,$sortToggle){//receives select tag and sort toggle then returns an associative array containing a key-value pair with value(key)=>details(value) - if query fails (i.e. select tag specified doesn't exist), return false
  global $conn;
  $optionQuery = "
  SELECT * 
  FROM field_values 
  WHERE field = '".$selectTag."'
  "; 
  if($sortToggle){
    $optionQuery .= " ORDER BY value";
  }
  if($optionResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    while($optionRes = mysqli_fetch_array($optionResult)){
      $key=$optionRes['value'];
      $value=$optionRes['details'];
      $values[$key]=$value;
    }
    return $values;
  }
  else{
    return false;
  }
}//-------------------------------------------end of retrieveOptions---------------------------------------//


//------FUNCTION THAT RETURNS AN ASSOCIATIVE ARRAY CONTAINING THE PARTS AND DETAILS FOR A GIVEN device_id------//
function retrieveParts($device_id){//receives select tag and sort toggle then returns an associative array containing a key-value pair with value(key)=>details(value) - if query fails (i.e. select tag specified doesn't exist), return false
  global $conn;
  $optionQuery = "
  SELECT * 
  FROM device_parts_table 
  WHERE device_id = '".$device_id."'
  "; 
  if($specsResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    while($specsRes = mysqli_fetch_array($specsResult)){
      $key=$specsRes['part'];
      $value=$specsRes['details'];
      $values[$key]=$value;
    }
    return $values;
  }
  else{
    return false;
  }
}//-------------------------------------------end of retrieveParts---------------------------------------//


//------FUNCTION THAT RETURNS AN ARRAY CONTAINING THE SPECS FOR A GIVEN device_id------//
function retrieveSpecs($device_id){//queries given device_id against device_specs_table
  global $conn;
  $optionQuery = "
  SELECT * 
  FROM device_specs_table 
  WHERE device_id = '".$device_id."'
  "; 
  if($specsResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    while($specsRes = mysqli_fetch_array($specsResult)){
      $key=$specsRes['specification'];
      $value=$specsRes['details'];
      $values[$key]=$value;
    }
    return $values;//returns numeric array containing all given specs of device_id
  }
  else{
    return false;//query fails, return false
  }
}//-------------------------------------------end of retrieveSpecs---------------------------------------//


//------FUNCTION THAT RETURNS AN ARRAY OF DETAILS FOR A GIVEN device_id------//
function retrieveDetails($device_id){
  global $conn;
  $detailQuery = "
  SELECT * 
  FROM device_list 
  WHERE device_id = '".$device_id."'
  ";   
  if($specsResult = mysqli_query($conn,$detailQuery)){
    return mysqli_fetch_array($specsResult);
  }
  else{
    return false;
  }
}
//---END OF FUNCTION THAT RETURNS AN ARRAY OF DETAILS FOR A GIVEN device_id---//

//---FUNCTION THAT TAKES AN ASSOCIATIVE ARRAY AND ECHOES IT AS A COLLECTION OF LIST ITEMS <li>---//
function printArray($list){
  foreach($list as $key => $value){
    echo "<li class='list-group-item'>".$key." - ".$value."</li>";
  }
}
//---END OF FUNCTION THAT TAKES AN ASSOCIATIVE ARRAY AND ECHOES IT AS A COLLECTION OF LIST ITEMS <li>---//


function displayArrayValues($values){
  for($i=0;$i<count($values);$i++){
    echo $values[$i];
  }
}


//------FUNCTION THAT RETURNS AN ARRAY CONTAINING A LIST OF REGISTERED TECHS AND THEIR CURRENT ACTIVE TICKETS------//
function retrieveTechs($sortToggle){//retrieves list of techs - if parameter is true, sort array alphabetically
  global $conn;
  $optionQuery = "
  SELECT employee_name, current_ticket 
  FROM tech_credentials 
  WHERE user_type = 'admin' OR user_type = 'tech'
  "; 
  if($sortToggle){
    $optionQuery .= " ORDER BY employee_name";
  }
  if($optionResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    while($optionRes = mysqli_fetch_array($optionResult)){
      $key=$optionRes['employee_name'];
      $value=$optionRes['current_ticket'];
      $values[$key]=$value;
    }
    //return $values;//uncomment this 
  }
  /*else{
    return false;//and this if function should only return an associative array where (employee_name=>current_ticket)
  }*/

  //--------------------MODULE TO OUTPUT A SELECT--------------------//
    $selectString = '<select class="form-control" form="modalForm" name="respondent" id="respondent" ';
        $selectString.= '>';
        $selectString.= '<option value="">None</option>';
        foreach ($values as $key => $value){
              $selectString .='<option value="';                     //start of option
              $selectString .=$key.'" ';                             //value of option
              $selectString .='data-option-description="'.$value.'" ';//append option details as an extraneous property
              if($value!=""){
                $selectString .= "disabled";
              }
              if($key == ""){                                        //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
                  $selectString.='>none</option>';}                  //null-value fields are expressed as 'none'
                  //$selectString.='>No '.$fieldString.' selected</option>';}   //null-value fields are expressed as 'no xfield selected'
              else{
                  $selectString.='>'.$key.'</option>';}              //end of option      
        }
        $selectString.= '</select>';
        echo $selectString;
  //----------------END OF MODULE TO OUTPUT A SELECT-----------------//
}
//------FUNCTION THAT RETURNS AN ARRAY CONTAINING A LIST OF REGISTERED TECHS AND THEIR CURRENT ACTIVE TICKETS------//


//------FUNCTION THAT RETURNS A LIST OF REGISTERED DEVICES------//
function retrieveDevices(){//retrieves list of techs - if parameter is true, sort array alphabetically
  global $conn;
  $optionQuery = "
  SELECT device_id
  FROM device_list
  "; 
  $values = array();
  if($optionResult = mysqli_query($conn,$optionQuery)){
    while($optionRes = mysqli_fetch_array($optionResult)){
      array_push($values,$optionRes['device_id']);
    }
  }
  //--------------------MODULE TO OUTPUT A DATALIST--------------------//
    $selectString = "<datalist id='deviceList'>";                     //start of datalist
        for ($counter = 0 ; $counter < count($values) ; $counter++){
              $selectString .='<option value="';                      //start of option
              $selectString .=$values[$counter].'" ';                 //inserts value of option
              $selectString.='>'.$values[$counter].'</option>';       //end of option     
        }
        $selectString.= '</datalist>';                                //end of datalist
        echo $selectString;
  //----------------END OF MODULE TO OUTPUT A DATALIST-----------------//
}
//------END OF FUNCTION THAT RETURNS A LIST OF REGISTERED DEVICES------//


  //---------------------------------FUNCTION TO RENDER A TIMER--------------------------------------//
  function outputTimer($queryString,$ticketID){ //takes a $queryString formatted to retrieve a specific TIMESTAMPDIFF, and a ticket ID to identify the row it queries        
      global $conn;

      if ($timeResult=mysqli_query($conn, $queryString)) { //code block retrieves date values to check
        $timeRes=mysqli_fetch_array($timeResult);
      } 
      else{                                                //query fails, echo error
        echo mysqli_error($conn);
        echo $queryString;
      }
          $outHours = (int)$timeRes['time_elapsed_hours'];
          $outMins = (int)$timeRes['time_elapsed_minutes'];
          $outSecs = (int)$timeRes['time_elapsed_seconds'];
      echo "<td>";       //starts td that echoes base value of time elapsed - updated by JS every second (see persistentClock()
      echo "<span id='hour_display".$ticketID."'>".sprintf('%02d', ($outHours))."</span>:";//hour value returned by sql is the current number of hours from stored value to now() //the query returns whole hours, so there's no need to mod (not sure if this would still apply if hours>24)
      echo "<span id='minute_display".$ticketID."'>".sprintf('%02d', ($outMins%60))."</span>:";//minute value returned by sql is the total number of minutes between now() and stored value - modding by 60 drops the full hours and leaves only the minutes short of an hour
      echo "<span id='second_display".$ticketID."'>".sprintf('%02d', ($outSecs%60))."</span>";//as above, leaves only the seconds short of a minute
      echo "</td>";       //ends that echoes base value of time elapsed
      //toConsole(gettype($timeRes['time_elapsed_minutes']));
  }
  //-----------------------------END OF FUNCTION TO RENDER A TIMER-------------------------------------//

  //---------------------------------FUNCTION TO OUTPUT A SELECT CONTROL----------------------------------//
  function outputSelect($nameString,$storedValue,$valueArray,$isRequired){
    $selectString = '<select class="form-control" name="'.$nameString.'" id="'.$nameString.'" ';
          if($isRequired){                                       //if select should be <required>, append tag to select
            $selectString.= "required";
          }
    $selectString.= '>';
    $selectString.= "<option selected disabled value=''></option>";
    foreach ($valueArray as $key => $value){
          $selectString .='<option value="';                        //start of option
          $selectString .=$key.'" ';                                //value of option
          $selectString .='data-option-description="'.$value.'" ';  //append option details as an extraneous property
          if($storedValue == $key){                               //check for equality between option value and stored value
             $selectString.="selected";}                          //if equal, add 'selected' property to option
          if($key == ""){                                           //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
              $selectString.='>none</option>';}                     //null-value fields are expressed as 'none'
              //$selectString.='>No '.$fieldString.' selected</option>';}   //null-value fields are expressed as 'no xfield selected'
          else{
              $selectString.='>'.$key.'</option>';}                 //end of option      
    }
    $selectString.= '</select>';
    echo $selectString;
  }
  //----------------------------END OF FUNCTION TO OUTPUT A SELECT CONTROL-----------------------------//


  //---------------------------------FUNCTION TO OUTPUT A SPECIAL SELECT CONTROL (HAS AN ONCHANGE FUNCTION)----------------------------------//
  function outputSpecialSelect($nameString,$storedValue,$valueArray,$isRequired,$selectOnchange){
    $selectString = '<select class="form-control" required autocomplete="off" name="'.$nameString.'" id="'.$nameString.'" ';
          if($isRequired){                                          //if select should be <required>, append tag to select
            $selectString.= "required";
          }
    $selectString.= "onchange='".$selectOnchange."'";
    $selectString.= '>';
    $selectString.= "<option selected disabled value=''></option>";
    foreach ($valueArray as $key => $value){
          $selectString .='<option value="';                        //start of option
          $selectString .=$key.'" ';                                //value of option
          $selectString .='data-option-description="'.$value.'" ';  //append option details as an extraneous property
          if($storedValue == $key){                                 //check for equality between option value and stored value
             $selectString.="selected";}                            //if equal, add 'selected' property to option
          if($key == ""){                                           //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
              $selectString.='>none</option>';}                     //null-value fields are expressed as 'none'
              //$selectString.='>No '.$fieldString.' selected</option>';}   //null-value fields are expressed as 'no xfield selected'
          else{
              $selectString.='>'.$key.'</option>';}                 //end of option      
    }
    $selectString.= '</select>';
    echo $selectString;
  }
  //----------------------------END OF FUNCTION TO OUTPUT A SPECIAL SELECT CONTROL-----------------------------//


//------------------FUNCTION FORMATS CHATLOG AND RETURNS HTML CODE FOR A CHATLOG <ELEMENT>------------------//
/*
parameter should generally look like this:
sender1<02/05/1991 22:00:00>: message -:-
sender2<02/05/1991 22:02:00>: message2

every time user sends a new message, update the string, adding 
  -:- sender3<02/05/1991 22:05:00>: message3
*/
function prepareChatlog($chatlog){
  $chatlogOut="";
  $class="";
  $chatArray = explode('-:-',$chatlog);         //splits $chatlog input into an array of chatlog lines via the -:- delimiter
  //print_r($chatArray);
  if(count($chatArray)>1){                      //if chatArray (and by extension chatlog) is not null, true
    for($i=0;$i<count($chatArray);$i++){        //each chatArray[i] is a line in the chatlog with a distinct user, datetime, message
      if(empty($chatArray[$i])){                //code block checks if current item is empty - if it is, ignore current item
        continue;
      }
      $step1 = explode('<',$chatArray[$i],2);   //splits the current chat log row into <user name> and < datetime>:message >
      $user = $step1[0];                        //part of the step1 array that contains the name of the poster
      $step2 = explode('>:',$step1[1],2);       //separates the step1 array into
      $datetime = $step2[0];                    //part of the step2 array that contains the date and time comment was posted
      $message = $step2[1];                     //part of the step2 array that contains the message
        if($user == checkUser()){               //code block determines if the message was sent by the user - if it was, apply style within "userMessage" CSS class - else, apply style within "nonUserMessage" CSS class
          $class = "userMessage";
        }
        else{
          $class = "nonUserMessage";
        }
      $chatlogOut.="
      <li class='clearfix'>
        <div class='message'>".$message."
          <div class='message-details'>
            <p>".$user.", ".$datetime."</p>
          </div>
        </div>
      </li>
      ";
    } 
  }
  return $chatlogOut;
}
//-------------END OF FUNCTION THAT FORMATS CHATLOG AND RETURNS HTML CODE FOR A CHATLOG <DIV>-------------//

function escapeString($inputString){//escapes a given string with respect to $conn
  global $conn;
  $outputString = mysqli_real_escape_string ($conn,$inputString);
  return $outputString;
}

function constructDisplay($label, $displayValue){//creates a design-formatted output box
  echo "
  <div class='form-group'>
      <label>$label</label>
      <div class='form-control'>$displayValue</div>
  </div>
  ";
}

function createHiddenInput($name, $value){//creates a hidden input with a given name and value - mostly unnecessary but expedites the process
  echo "
  <input type='hidden' name='$name' value='$value'>
  ";
}

//------------------FUNCTION QUERIES TICKETS AND RETURNS ARRAY OF VALUES WITH A GIVEN STATUS------------------//
function getTickets($ticketStatus){
  global $conn;
  $ticketQuery = "
  SELECT ticket_id
  FROM tickets 
  WHERE job_status = '".$ticketStatus."'
  ";    
  if($ticketResult = mysqli_query($conn,$ticketQuery)){
    $values = array();
    while($ticketRes = mysqli_fetch_array($ticketResult)){
      array_push($values, $ticketRes['ticket_id']);
    }
    return $values;
  }
  else{
    return false;
  }
}
//-------------END OF FUNCTION THAT QUERIES TICKETS AND RETURNS ARRAY OF VALUES WITH A GIVEN STATUS-------------//

//----------------FUNCTION THAT PRINTS THE CONTENTS OF A NUMERIC ARRAY AS <LI> ELEMENTS----------------//
function printTickets($valueArray){  
        foreach ($valueArray as $value)
        {
             echo "<li><a href='viewticket.php?ticket_id=".$value."'>".$value."</a></li>";
        }
}
//-------------END OF FUNCTION THAT PRINTS THE CONTENTS OF A NUMERIC ARRAY AS <LI> ELEMENTS-------------//

//-------------FUNCTION CHECKS IF CURRENTLY LOGGED-IN USER HAS AN ACTIVE TICKET-------------//
function checkCurrentTicket(){
  global $conn;
  $retrieveTicketQueryString = "SELECT * FROM tech_credentials WHERE employee_name = '".$_SESSION['client_name']."'";
    $retrieveTicket = mysqli_query($conn, $retrieveTicketQueryString);
            if(!$retrieveTicket || mysqli_num_rows($retrieveTicket)==0) {//IF USER DOES NOT EXIST, EXECUTE THIS CLAUSE - THERE SHOULD NEVER BE ANY NEED TO RUN THIS CLAUSE -> IF THIS CLAUSE RUNS, THERE IS A MAJOR ERROR ELSEWHERE
              print "USER DOES NOT EXIST!";
            }
            else{//USER EXISTS, EXECUTE THIS CLAUSE
              while($retrieveRes=mysqli_fetch_array($retrieveTicket)){//RETRIEVE USER DATA       
                  if($retrieveRes['current_ticket']==null || $retrieveRes['current_ticket']==''){//user has no active ticket
                    return true;
                  }
                  else{//user has an active ticket
                    return false;
                  }
              }
            } 
}
//---------END OF FUNCTION THAT CHECKS IF CURRENTLY LOGGED-IN USER HAS AN ACTIVE TICKET--------//

//--------FUNCTION THAT USES ECHOED JAVASCRIPT TO HIDE AN HTML ELEMENT WITH THE GIVEN ID--------//
function hideElement($element_id){
  echo "<script>";
  echo "document.getElementById('".$element_id."').style.display='none';";
  echo "</script>";
}
//----END OF FUNCTION THAT USES ECHOED JAVASCRIPT TO HIDE AN HTML ELEMENT WITH THE GIVEN ID-----//

//--------FUNCTION THAT USES ECHOED JAVASCRIPT TO SHOW AN HTML ELEMENT WITH THE GIVEN ID--------//
function showElement($element_id){
  echo "<script>";
  echo "document.getElementById('".$element_id."').style.display='block';";
  echo "</script>";
}
//----END OF FUNCTION THAT USES ECHOED JAVASCRIPT TO SHOW AN HTML ELEMENT WITH THE GIVEN ID-----//

?>
