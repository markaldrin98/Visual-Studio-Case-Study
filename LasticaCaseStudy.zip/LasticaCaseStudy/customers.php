<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="design.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="jquery.js"></script>
</head>

<body>
<div id="sidebar">
<div class="toggle-btn">
<span></span>
<span></span>
<span></span>
</div>

<ul>

	<?php include_once('navigation/nav.php'); ?>
</ul>	
</div>
</body>
</html>

