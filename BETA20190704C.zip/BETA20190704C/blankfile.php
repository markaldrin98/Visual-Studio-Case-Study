<?php include 'misc/config.php';?>
<div style="color:white;">
<br><br><br><br><br><br><br><br><br><br>

</div>
<script>  
</script>