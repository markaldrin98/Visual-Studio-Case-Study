<?php 
//include "admin_auth.php";
session_start();
include "header_student.php";?>
<div id="cover">
<div id="content">
<h4>Hellow,&nbsp;<?php echo $_SESSION['SESS_NAME'] ;?><br /></h4>
<h3>Well come Fm international hotel<?php echo $_SESSION['SESS_NAME'] ;?> </h3>
<?php include "advert4.html";?>

        </div>
<?php include "footer.php";?>

</div>
</div>
