<?php
                    /*----------------DEPRECATED CODE BLOCK FOR OLD TICKET DISPLAY (ITERATES THROUGH EACH TICKET)--------------
                    echo "<td>".$res['date_created']."</td>";
                    echo "<td>".$res['date_accepted']."</td>";     
                    echo "<td>".$res['date_assessed']."</td>"; 
                    echo "<td>".$res['date_fulfilled']."</td>"; 
                    echo "<td>".$res['ticket_id']."</td>"; 
                    echo "<td>".$res['office']."</td>"; 
                    echo "<td>".$res['client_name']."</td>"; 
                    echo "<td>".$res['employee_number']."</td>"; 
                    echo "<td>".$res['concern']."</td>"; 
                    echo "<td>".$res['job_description']."</td>"; 
                    echo "<td>".$res['job_details']."</td>"; 
                    echo "<td>".$res['participation']."</td>"; 
                    echo "<td>".$res['approval_status']."</td>"; 
                    echo "<td>".$res['respondent']."</td>"; 
                    echo "<td>".$res['job_status']."</td>"; 
                    echo "<td>".$res['remarks']."</td>"; 
                    //echo "<td>".$res['time_elapsed']."</td>"; */
                    //echo "</tr>";

                    //!!!!!!!!!!!!!!!!!CODE BLOCK TO BE REMOVED FROM THE BIG TABLE - TRANSFER THIS TO MODAL DISPLAY!!!!!!!!!!!!!!!!//
                    //echo "<td>".$res['office']."</td>";           //editable, JS pending <- block will eventually consist of an array of selects
                    /* //COMMENTS OUT THE BIG CODE BLOCK
                    echo '<td><input form="mainForm" type="text" name="officeSelect'.$res["ticket_id"].'" value="'.$res["office"].'"></td>';
                                //$_POST['officeSelect1'] -> IT
                    //textbox control for 'office'

                    echo '<td><input form="mainForm" type="text" name="client_nameSelect'.$res["ticket_id"].'" value="'.$res["client_name"].'"></td>';
                    //textbox control for 'client_name'

                    echo '<td><input form="mainForm" type="text" name="employee_numberSelect'.$res["ticket_id"].'" value="'.$res["employee_number"].'"></td>';
                    //textbox control for 'employee_number'

                    echo "<td>".$res['concern']."</td>";            //client concern - static
                    //text display for 'concern'

                    outputSelect("job_description",$res["job_description"],$res["ticket_id"],array("","Service","Connection","Setup","Training","Install"));
                    //select control for 'job_description'

                    outputSelect("participation",$res["participation"],$res["ticket_id"],array("","Supervised","Performed"));
                    //select control for 'participation'

                    $selectString ='<td><select form="mainForm" style="height:20;" name="approval_statusSelect'.$res["ticket_id"].'">
                            <option value="Not Approved" ';
                    if($res["approval_status"] == "Not Approved"){
                        $selectString.="selected";
                    } 
                    $selectString.='>Not Approved</option>
                            <option value="Approved" ';                        
                    if($res["approval_status"] == "Approved"){
                        $selectString.="selected";
                    } 
                    $selectString.='>Approved</option>
                        </select></td>';                   
                    echo $selectString;

                    $selectString ='<td><select form="mainForm" style="height:20;" name="respondentSelect'.$res["ticket_id"].'">';//start of select for respondent
                    $arrayOptions = array("", "tech1", "tech2", "tech3");       //initialization of array for select options %% - have this retrieve tech names to pass to arrayOptions
                    foreach($arrayOptions as $value){                           //loop iterating through arrayOptions
                        $selectString .='<option value="';                      //start of option1
                        $selectString .=$value.'"';                             //value of option1 - can be empty, and thus can be saved to the db as empty
                            if($res["respondent"] == $value){                   //check for equality between option value and stored value
                                $selectString.="selected";}                     //if true, add 'selected' property to option
                        if($value == ""){                                       //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
                            $selectString.='>No respondent selected</option>';}   
                        else{
                            $selectString.='>'.$value.'</option>';}             //end of option
                    }
                    $selectString.='</select></td>';                            //end of select             
                    echo $selectString;                                         //outputs select to html

                   
                    outputSelect("job_status",$res["job_status"],$res['ticket_id'],array('Open','Accepted','Completed','Escalated','Not Serviced','Next Day')); //select control for 'job_status'
                    
                    echo '<td><textarea style="color:black;resize:none;" value="'.htmlspecialchars($res["remarks"]).'" name="remarksSelect'.$res["ticket_id"].'"></textarea></td>
                    ';//textarea control for 'remarks'

                    //----------------------------------LARGE CODE BLOCK FOR TIME_ELAPSED-------------------------------------//
                    // code block for <td>time_elapsed</td> should be a consequence of date_created and current time
                    //if date_fulfilled is not null, should return a fixed timespan
                    //code block to display static timespan for completed tickets
                        $queryString = "SELECT date_accepted, date_fulfilled FROM tickets WHERE ticket_id='".$res['ticket_id']."'"; //query retrieves date_fulfilled of current row to check if it has been accepted and if it has been completed
                            if ($dateResult=mysqli_query($conn, $queryString)) {    //above query runs
                              $dateCheck=mysqli_fetch_array($dateResult);           //assigns row array to $dateCheck
                            }
                            else{                                                   //query fails, echo error 
                              echo mysqli_error($conn);
                              echo $queryString;
                            }

                        //code block checks if ticket if ticket has been accepted -> completed
                        if(is_null($dateCheck['date_accepted'])) //if true, then date_accepted is null - ticket has not been accepted
                        {
                            //display nothing in the 'time_elapsed' column of the row
                            echo "<td></td>";
                        }
                        else if(is_null($dateCheck['date_fulfilled'])) //if true, date_fulfilled is null - ticket has been accepted but not completed
                        {
                            //display time difference between now() and date_accepted - should be updated every second
                            $queryString = "SELECT TIMESTAMPDIFF(HOUR, (SELECT date_accepted FROM tickets WHERE ticket_id='".$res['ticket_id']."'"."), now()) AS time_elapsed_hours, TIMESTAMPDIFF(MINUTE, (SELECT date_accepted FROM tickets WHERE ticket_id='".$res['ticket_id']."'"."), now()) AS time_elapsed_minutes, TIMESTAMPDIFF(SECOND, (SELECT date_accepted FROM tickets WHERE ticket_id='".$res['ticket_id']."'"."), now()) AS time_elapsed_seconds";
                            outputTimer($queryString, $res['ticket_id']);//calls function to render timer
                        }
                        else if(!is_null($dateCheck['date_fulfilled']) && !is_null($dateCheck['date_accepted']))//ticket has been accepted and completed
                        {
                            //display time difference between date_fulfilled and date_accepted - this will be static
                            $queryString = "SELECT TIMESTAMPDIFF(HOUR, date_accepted, date_fulfilled) AS time_elapsed_hours, TIMESTAMPDIFF(MINUTE, date_accepted, date_fulfilled) AS time_elapsed_minutes, TIMESTAMPDIFF(SECOND, date_accepted, date_fulfilled) AS time_elapsed_seconds FROM tickets WHERE ticket_id='".$res['ticket_id']."'";
                            outputTimer($queryString, $res['ticket_id']);//calls functionto render timer
                        }
                    //----------------------------------END OF LARGE CODE BLOCK FOR TIME_ELAPSED--------------------------------//
                    *///COMMENTS OUT THE BIG CODE BLOCK
                    //!!!!!!!END OF CODE BLOCK TO BE REMOVED FROM THE BIG TABLE - TRANSFER THIS TO MODAL DISPLAY!!!!!!!!!!//


  //------------------------FUNCTION TO OUTPUT A SELECT CONTROL-----------------------//!!!!!!!DEPRECATED
  /*function outputSelect($fieldString, $storedValue, $ticket_id, $arrayOptions){//!!!!!!!!!!!!!!!change form attribute to which this is bound!!!!!!!!!!!!!!!!!!!!
      $selectString ='<td><select form="mainForm" style="height:20;" name="'.$fieldString.'Select'.$ticket_id.'">';//start of select
      foreach($arrayOptions as $value){                           //loop iterating through arrayOptions - creates a new <option></option> for each iteration
          $selectString .='<option value="';                      //start of option
          $selectString .=$value.'"';                             //value of option
              if($storedValue == $value){                         //check for equality between option value and stored value
                  $selectString.="selected";}                     //if equal, add 'selected' property to option
          if($value == ""){                                       //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
              $selectString.='>none</option>';}                   //null-value fields are expressed as 'none'
              //$selectString.='>No '.$fieldString.' selected</option>';}   //null-value fields are expressed as 'no xfield selected'
          else{
              $selectString.='>'.$value.'</option>';}             //end of option
      }
      $selectString.='</select></td>';                            //end of select             
      echo $selectString;                                         //outputs select to html
  }*/                
  //--------------------END OF FUNCTION TO OUTPUT A SELECT CONTROL--------------------//!!!!!!!DEPRECATED


?>