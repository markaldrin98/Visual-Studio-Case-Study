﻿Imports System.Data.OleDb
Public Class Form6

    Dim conn As OleDbConnection
    Dim cmd As OleDbCommand
    Dim reader As OleDbDataReader
    Dim DepositAmount As Double = 0
    Dim NewBalance As Double = 0

    Private Sub Form6_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        conn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" &
                Application.StartupPath & "\dbCustomerAcct.mdb")

    End Sub

    Private Sub TextBox1_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress

        If Char.IsDigit(e.KeyChar) = False And Char.IsControl(e.KeyChar) And False Then

            e.Handled = True

        End If

    End Sub

    Private Sub TextBox1_Leave(sender As System.Object, e As System.EventArgs) Handles TextBox1.Leave

        If TextBox1.Text = "" Then

            TextBox1.Text = 0.0

        End If

    End Sub

    Private Sub TextBox1_Enter(sender As System.Object, e As System.EventArgs) Handles TextBox1.Enter

        If Double.Parse(TextBox1.Text) = 0 Then

            TextBox1.Text = ""

        End If

    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click

        DepositAmount = Double.Parse(TextBox1.Text)

        If DepositAmount < 100 Then

            MessageBox.Show("Invalid Amount..." & vbNewLine & "Deposited amount should be Php 100.00 and above", "Deposit", MessageBoxButtons.OK, MessageBoxIcon.None)

        Else

            conn.Open()
            cmd = New OleDbCommand()
            cmd.Connection = conn
            cmd.CommandText = "Update tblCustomerInfo set balance = balance + " & DepositAmount & " where acctnum = '" & Form2.acctnum & "'"
            cmd.ExecuteNonQuery()

            cmd = New OleDbCommand()
            cmd.Connection = conn
            cmd.CommandText = "Select * from tblCustomerInfo where acctnum = '" & Form2.acctnum & "'"
            reader = cmd.ExecuteReader()

            While (reader.Read())

                NewBalance = Double.Parse(reader("balance").ToString())
            End While

            MessageBox.Show("Account Number: " & Form2.acctnum & vbNewLine &
            "Account Name: " & Form2.acctname & vbNewLine & "Deposited Amount: " &
             Double.Parse(TextBox1.Text).ToString("0,0.00") & vbNewLine + "Balance: " & NewBalance.ToString("0,0.00") & vbNewLine &
            "Date/Time: " & DateTime.Now.ToString("MMMM dd, yyyy") & " / " & DateTime.Now.ToShortTimeString(),
            "Deposit", MessageBoxButtons.OK, MessageBoxIcon.None)

            TextBox1.Text = 0.0
            TextBox1.Focus()

            conn.Close()

        End If

    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click

        Me.Close()
        Form3.Show()

    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click

        Me.Close()
        Form8.Show()

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Me.Close()
        Form1.Show()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class