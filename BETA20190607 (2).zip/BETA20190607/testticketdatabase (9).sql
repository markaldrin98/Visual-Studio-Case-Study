-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2019 at 10:49 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `testticketdatabase`
--
CREATE DATABASE IF NOT EXISTS `testticketdatabase` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `testticketdatabase`;

-- --------------------------------------------------------

--
-- Table structure for table `device_changelog`
--

CREATE TABLE IF NOT EXISTS `device_changelog` (
  `log_number` int(11) NOT NULL,
  `date_time_logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `device_id` varchar(15) NOT NULL,
  `admin` text NOT NULL,
  `change_made` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `device_list`
--

CREATE TABLE IF NOT EXISTS `device_list` (
  `device_id` varchar(15) NOT NULL,
  `device_type` text NOT NULL,
  `owner` text NOT NULL,
  `office` text NOT NULL,
  `date_registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `device_parts_table`
--

CREATE TABLE IF NOT EXISTS `device_parts_table` (
  `device_id` varchar(15) NOT NULL,
  `part` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `device_service_history`
--

CREATE TABLE IF NOT EXISTS `device_service_history` (
  `device_id` varchar(15) NOT NULL,
  `ticket_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `device_specs_table`
--

CREATE TABLE IF NOT EXISTS `device_specs_table` (
  `device_id` varchar(15) NOT NULL,
  `specification` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `field_values`
--

CREATE TABLE IF NOT EXISTS `field_values` (
  `field` text NOT NULL,
  `value` text NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tech_credentials`
--

CREATE TABLE IF NOT EXISTS `tech_credentials` (
  `employee_name` text NOT NULL,
  `user_type` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `current_ticket` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `testcboxdata`
--

CREATE TABLE IF NOT EXISTS `testcboxdata` (
  `ticket_id` varchar(12) NOT NULL,
  `chat_log` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE IF NOT EXISTS `tickets` (
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_accepted` datetime DEFAULT NULL,
  `date_assessed` timestamp NULL DEFAULT NULL,
  `date_fulfilled` datetime DEFAULT NULL,
  `ticket_id` varchar(15) NOT NULL,
  `office` text,
  `client_name` text,
  `employee_number` text,
  `concern` text,
  `concern_details` text NOT NULL,
  `device_id` varchar(15) NOT NULL,
  `assessment` text NOT NULL,
  `job_description` text,
  `job_details` text NOT NULL,
  `participation` text,
  `approval_status` text,
  `respondent` text,
  `job_status` text,
  `remarks` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_changelog`
--

CREATE TABLE IF NOT EXISTS `ticket_changelog` (
  `log_number` int(11) NOT NULL,
  `date_time_logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin` text NOT NULL,
  `ticket` varchar(15) NOT NULL,
  `change_made` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `device_changelog`
--
ALTER TABLE `device_changelog`
  ADD PRIMARY KEY (`log_number`);

--
-- Indexes for table `device_list`
--
ALTER TABLE `device_list`
  ADD UNIQUE KEY `device_id` (`device_id`), ADD KEY `device_id_2` (`device_id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`), ADD KEY `ticket_id` (`ticket_id`), ADD KEY `ticket_id_2` (`ticket_id`), ADD KEY `ticket_id_3` (`ticket_id`);

--
-- Indexes for table `ticket_changelog`
--
ALTER TABLE `ticket_changelog`
  ADD PRIMARY KEY (`log_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `device_changelog`
--
ALTER TABLE `device_changelog`
  MODIFY `log_number` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ticket_changelog`
--
ALTER TABLE `ticket_changelog`
  MODIFY `log_number` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=64;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
