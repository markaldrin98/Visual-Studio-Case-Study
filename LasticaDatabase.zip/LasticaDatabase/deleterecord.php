<?php
include("config.php"); 
$id = $_GET['id'];
$result = mysqli_query($conn, "DELETE FROM student_info WHERE id='".$id."'");
 
header("Location:faceplate.php");
?>